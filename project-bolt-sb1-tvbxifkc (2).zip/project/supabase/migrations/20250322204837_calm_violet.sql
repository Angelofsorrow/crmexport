/*
  # Fix Calendar Contact Creation

  1. Changes
    - Add trigger function to create contacts from calendar event attendees
    - Update calendar event processing to handle new contacts
    - Add proper error handling and logging
*/

-- Create function to create contacts from calendar events
CREATE OR REPLACE FUNCTION create_contact_from_calendar_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_contact_id uuid;
  v_first_name text;
  v_last_name text;
  v_email text;
  attendee jsonb;
BEGIN
  -- Process attendees array
  IF NEW.attendees IS NOT NULL AND jsonb_array_length(NEW.attendees) > 0 THEN
    FOR attendee IN SELECT * FROM jsonb_array_elements(NEW.attendees)
    LOOP
      v_email := attendee->>'email';
      
      -- Skip if no email
      IF v_email IS NULL THEN
        CONTINUE;
      END IF;

      -- Check if contact exists
      IF NOT EXISTS (
        SELECT 1 FROM contacts WHERE email = v_email
      ) THEN
        -- Parse name if provided
        IF attendee->>'name' IS NOT NULL THEN
          v_first_name := split_part(attendee->>'name', ' ', 1);
          v_last_name := substring(attendee->>'name' from position(' ' in attendee->>'name') + 1);
        ELSE
          -- Use email prefix as first name
          v_first_name := split_part(v_email, '@', 1);
          v_last_name := '';
        END IF;

        -- Create new contact
        INSERT INTO contacts (
          first_name,
          last_name,
          email,
          owner_id,
          created_at,
          updated_at
        ) VALUES (
          v_first_name,
          v_last_name,
          v_email,
          NEW.owner_id,
          now(),
          now()
        ) RETURNING id INTO v_contact_id;

        -- Log contact creation
        INSERT INTO activities (
          type,
          title,
          description,
          owner_id,
          contact_id,
          created_at
        ) VALUES (
          'contact_created',
          'Contact Created from Calendar Event',
          format('Created contact for %s (%s)', 
            CASE 
              WHEN v_last_name = '' THEN v_first_name
              ELSE v_first_name || ' ' || v_last_name
            END,
            v_email
          ),
          NEW.owner_id,
          v_contact_id,
          now()
        );
      END IF;
    END LOOP;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'Calendar Event Contact Creation',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create trigger for contact creation from calendar events
DROP TRIGGER IF EXISTS calendar_event_contact_creator ON calendar_events;
CREATE TRIGGER calendar_event_contact_creator
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION create_contact_from_calendar_event();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX IF NOT EXISTS idx_contacts_owner_id ON contacts(owner_id);
CREATE INDEX IF NOT EXISTS idx_calendar_events_owner_id ON calendar_events(owner_id);