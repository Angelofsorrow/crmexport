/*
  # Fix Pipeline Stages RLS Policy

  1. Changes
    - Drop existing RLS policy
    - Create new policy that allows:
      - SELECT access for all authenticated users
      - INSERT/UPDATE/DELETE for owners and system stages
    - Add proper indexes for performance
*/

-- Drop existing policy
DROP POLICY IF EXISTS "Users can manage their pipeline stages" ON pipeline_stages;

-- Create new policies with proper access control
CREATE POLICY "Users can view all pipeline stages"
  ON pipeline_stages
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage their pipeline stages"
  ON pipeline_stages
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR 
    is_system = true OR 
    owner_id IS NULL
  )
  WITH CHECK (
    owner_id = auth.uid() OR 
    is_system = true
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_owner_id ON pipeline_stages(owner_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_is_system ON pipeline_stages(is_system);
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_order_number ON pipeline_stages(order_number);