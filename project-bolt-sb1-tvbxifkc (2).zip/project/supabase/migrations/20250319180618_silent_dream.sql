/*
  # Add Pipeline Stages Management

  1. New Tables
    - `pipeline_stages`
      - Stores customizable pipeline stages
      - Allows users to define their own stages
      - Includes order, color, and automation settings

  2. Changes
    - Add foreign key to deals table
    - Migrate existing stage data
    - Add RLS policies
*/

-- Create pipeline stages table
CREATE TABLE IF NOT EXISTS pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  color text NOT NULL DEFAULT 'bg-gray-600',
  order_number integer NOT NULL,
  owner_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tasks text[] DEFAULT '{}',
  automations text[] DEFAULT '{}',
  is_system boolean DEFAULT false,
  is_closed boolean DEFAULT false,
  is_won boolean DEFAULT false
);

-- Enable RLS
ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their pipeline stages" ON pipeline_stages;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Add RLS policy
CREATE POLICY "Users can manage their pipeline stages"
  ON pipeline_stages
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid() OR is_system = true)
  WITH CHECK (owner_id = auth.uid());

-- Add stage_id to deals table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'deals' AND column_name = 'stage_id'
  ) THEN
    ALTER TABLE deals ADD COLUMN stage_id uuid REFERENCES pipeline_stages(id);
  END IF;
END $$;

-- Insert default system stages and store their IDs
DO $$
DECLARE
  prospecting_id uuid;
  qualification_id uuid;
  proposal_id uuid;
  negotiation_id uuid;
  closed_won_id uuid;
  closed_lost_id uuid;
BEGIN
  -- Insert Prospecting stage and store ID
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Prospecting',
    'Initial contact and lead qualification',
    'bg-blue-600',
    1,
    true,
    ARRAY[
      'Research company background',
      'Identify key decision makers',
      'Initial contact attempt'
    ],
    ARRAY[
      'Send welcome email',
      'Create follow-up task',
      'LinkedIn connection request'
    ],
    false,
    false
  ) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO prospecting_id;

  -- Insert Qualification stage and store ID
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Qualification',
    'Assessing needs and budget',
    'bg-purple-600',
    2,
    true,
    ARRAY[
      'Assess budget and timeline',
      'Identify pain points',
      'Confirm decision-making process'
    ],
    ARRAY[
      'Schedule discovery call',
      'Send qualification survey',
      'Create opportunity'
    ],
    false,
    false
  ) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO qualification_id;

  -- Insert Proposal stage and store ID
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Proposal',
    'Proposal preparation and presentation',
    'bg-yellow-600',
    3,
    true,
    ARRAY[
      'Draft proposal document',
      'Internal pricing review',
      'Prepare presentation'
    ],
    ARRAY[
      'Generate proposal document',
      'Set internal review deadline',
      'Schedule presentation'
    ],
    false,
    false
  ) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO proposal_id;

  -- Insert Negotiation stage and store ID
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Negotiation',
    'Contract negotiation and review',
    'bg-orange-600',
    4,
    true,
    ARRAY[
      'Review contract terms',
      'Address objections',
      'Get stakeholder approval'
    ],
    ARRAY[
      'Send contract for review',
      'Schedule negotiation call',
      'Set follow-up reminder'
    ],
    false,
    false
  ) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO negotiation_id;

  -- Insert Closed Won stage and store ID
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Closed Won',
    'Deal successfully closed',
    'bg-green-600',
    5,
    true,
    ARRAY[
      'Send final contract',
      'Schedule kickoff meeting',
      'Set up account'
    ],
    ARRAY[
      'Generate welcome packet',
      'Notify implementation team',
      'Schedule onboarding'
    ],
    true,
    true
  ) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO closed_won_id;

  -- Insert Closed Lost stage and store ID
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Closed Lost',
    'Deal lost or abandoned',
    'bg-red-600',
    6,
    true,
    ARRAY[
      'Document loss reasons',
      'Schedule post-mortem',
      'Update CRM'
    ],
    ARRAY[
      'Send feedback survey',
      'Schedule follow-up in 6 months',
      'Archive documents'
    ],
    true,
    false
  ) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO closed_lost_id;

  -- Update existing deals with new stage IDs
  UPDATE deals SET stage_id = prospecting_id WHERE stage = 'prospecting';
  UPDATE deals SET stage_id = qualification_id WHERE stage = 'qualification';
  UPDATE deals SET stage_id = proposal_id WHERE stage = 'proposal';
  UPDATE deals SET stage_id = negotiation_id WHERE stage = 'negotiation';
  UPDATE deals SET stage_id = closed_won_id WHERE stage = 'closed_won';
  UPDATE deals SET stage_id = closed_lost_id WHERE stage = 'closed_lost';
END $$;