/*
  # Fix Organization Policies

  1. Changes
    - Drop existing policies to avoid conflicts
    - Create new non-recursive policies
    - Create default organization and member records
    - Fix UUID handling for default organization
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view organizations" ON organizations;
  DROP POLICY IF EXISTS "Users can manage organizations" ON organizations;
  DROP POLICY IF EXISTS "Users can view organization members" ON organization_members;
  DROP POLICY IF EXISTS "Organization owners can manage members" ON organization_members;
  DROP POLICY IF EXISTS "Default organization access" ON organization_members;
  DROP POLICY IF EXISTS "Users can view their organization memberships" ON organization_members;
  DROP POLICY IF EXISTS "Users can view all organization members" ON organization_members;
  DROP POLICY IF EXISTS "Organization owners can update members" ON organization_members;
  DROP POLICY IF EXISTS "Organization owners can delete members" ON organization_members;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new simplified policies for organizations
CREATE POLICY "Users can view organizations"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage organizations"
  ON organizations
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create new simplified policies for organization members
CREATE POLICY "Users can view organization members"
  ON organization_members
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage organization members"
  ON organization_members
  FOR ALL
  TO authenticated
  USING (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

-- Function to ensure user has an organization
CREATE OR REPLACE FUNCTION ensure_user_organization()
RETURNS TRIGGER AS $$
DECLARE
  org_id uuid;
BEGIN
  -- Check if user already has an organization
  SELECT organization_id INTO org_id
  FROM organization_members
  WHERE user_id = NEW.id
  LIMIT 1;

  -- If no organization found, create one and add membership
  IF org_id IS NULL THEN
    -- Create organization
    INSERT INTO organizations (name, slug, domain, owner_id)
    VALUES (
      'My Organization',
      'my-org-' || NEW.id,
      NULL,
      NEW.id
    )
    RETURNING id INTO org_id;

    -- Create organization membership
    INSERT INTO organization_members (organization_id, user_id, role)
    VALUES (org_id, NEW.id, 'admin');

    -- Create whitelabel config
    INSERT INTO whitelabel_configs (
      organization_id,
      name,
      primary_color,
      secondary_color,
      accent_color,
      font_family,
      is_active
    ) VALUES (
      org_id,
      'Default Configuration',
      '#4F46E5',
      '#818CF8',
      '#6366F1',
      'Inter',
      true
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION ensure_user_organization();

-- Create default organization for existing users
DO $$
DECLARE
  user_record RECORD;
  new_org_id uuid;
BEGIN
  FOR user_record IN SELECT * FROM auth.users
  LOOP
    -- Check if user already has an organization
    IF NOT EXISTS (
      SELECT 1 FROM organization_members WHERE user_id = user_record.id
    ) THEN
      -- Create organization
      INSERT INTO organizations (name, slug, domain, owner_id)
      VALUES (
        'My Organization',
        'my-org-' || user_record.id,
        NULL,
        user_record.id
      )
      RETURNING id INTO new_org_id;

      -- Create organization membership
      INSERT INTO organization_members (organization_id, user_id, role)
      VALUES (new_org_id, user_record.id, 'admin');

      -- Create whitelabel config
      INSERT INTO whitelabel_configs (
        organization_id,
        name,
        primary_color,
        secondary_color,
        accent_color,
        font_family,
        is_active
      ) VALUES (
        new_org_id,
        'Default Configuration',
        '#4F46E5',
        '#818CF8',
        '#6366F1',
        'Inter',
        true
      );
    END IF;
  END LOOP;
END $$;