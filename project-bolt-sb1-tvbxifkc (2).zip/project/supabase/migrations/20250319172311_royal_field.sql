/*
  # Add Location-Based Assistance Programs

  1. Changes
    - Add location fields to assistance_programs table
    - Add more detailed location-specific programs
    - Add AMI (Area Median Income) limits by location

  2. Security
    - Maintain existing RLS policies
*/

-- Add location fields to assistance_programs
ALTER TABLE assistance_programs
ADD COLUMN IF NOT EXISTS state text,
ADD COLUMN IF NOT EXISTS county text,
ADD COLUMN IF NOT EXISTS city text,
ADD COLUMN IF NOT EXISTS ami_limits jsonb,
ADD COLUMN IF NOT EXISTS property_value_limits jsonb;

-- Insert state-specific programs
INSERT INTO assistance_programs (
  name, type, description, provider,
  max_assistance_amount, income_limit_percentage,
  first_time_homebuyer_only, credit_score_min,
  dti_max, eligible_property_types, eligible_loan_types,
  requirements, state, county, city, ami_limits
) VALUES
  -- California Programs
  (
    'CalHFA MyHome Assistance Program',
    'down_payment',
    'Down payment assistance for California residents',
    'CalHFA',
    15000,
    120,
    true,
    660,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must complete homebuyer education',
      'Must be a California resident',
      'Property must be owner-occupied'
    ],
    'CA',
    NULL,
    NULL,
    '{"1": 98900, "2": 112900, "3": 127050, "4": 141150}'
  ),
  (
    'LA County First Home Mortgage Program',
    'down_payment',
    'Down payment assistance for LA County residents',
    'LA County Housing Authority',
    75000,
    150,
    true,
    620,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a Los Angeles County resident',
      'Must complete homebuyer education'
    ],
    'CA',
    'Los Angeles',
    NULL,
    '{"1": 66750, "2": 76250, "3": 85800, "4": 95300}'
  ),

  -- New York Programs
  (
    'SONYMA Down Payment Assistance',
    'down_payment',
    'Down payment assistance for New York residents',
    'SONYMA',
    20000,
    130,
    true,
    620,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    ARRAY['FHA', 'Conventional'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a New York State resident',
      'Must complete homebuyer education',
      'Property must be owner-occupied'
    ],
    'NY',
    NULL,
    NULL,
    '{"1": 105700, "2": 120800, "3": 135900, "4": 150900}'
  ),
  (
    'NYC HomeFirst Down Payment Assistance',
    'down_payment',
    'Down payment assistance for NYC residents',
    'NYC Housing Preservation & Development',
    100000,
    80,
    true,
    620,
    43,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional', 'VA'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a New York City resident',
      'Must complete homebuyer education',
      'Must live in the home for at least 10 years'
    ],
    'NY',
    NULL,
    'New York City',
    '{"1": 83200, "2": 95050, "3": 106950, "4": 118800}'
  ),

  -- Florida Programs
  (
    'Florida First Time Homebuyer Program',
    'down_payment',
    'Down payment assistance for Florida residents',
    'Florida Housing Finance Corporation',
    15000,
    140,
    true,
    640,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional', 'VA', 'USDA'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a Florida resident',
      'Must complete homebuyer education'
    ],
    'FL',
    NULL,
    NULL,
    '{"1": 89600, "2": 102400, "3": 115200, "4": 128000}'
  ),
  (
    'Miami-Dade First-Time Homebuyer Program',
    'down_payment',
    'Down payment assistance for Miami-Dade residents',
    'Miami-Dade County',
    25000,
    115,
    true,
    620,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a Miami-Dade County resident',
      'Must complete homebuyer education',
      'Property must be in Miami-Dade County'
    ],
    'FL',
    'Miami-Dade',
    NULL,
    '{"1": 95200, "2": 108800, "3": 122400, "4": 136000}'
  ),

  -- Texas Programs
  (
    'TDHCA My First Texas Home',
    'down_payment',
    'Down payment assistance for Texas residents',
    'Texas Department of Housing',
    17500,
    125,
    true,
    620,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional', 'VA', 'USDA'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a Texas resident',
      'Must complete homebuyer education',
      'Property must be in Texas'
    ],
    'TX',
    NULL,
    NULL,
    '{"1": 91300, "2": 104300, "3": 117350, "4": 130350}'
  ),
  (
    'Houston Homebuyer Assistance',
    'down_payment',
    'Down payment assistance for Houston residents',
    'City of Houston',
    30000,
    80,
    true,
    640,
    43,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must be a Houston resident',
      'Must complete homebuyer education',
      'Property must be in Houston city limits'
    ],
    'TX',
    'Harris',
    'Houston',
    '{"1": 75400, "2": 86150, "3": 96900, "4": 107650}'
  );

-- Add indexes for location-based queries
CREATE INDEX IF NOT EXISTS idx_assistance_programs_state ON assistance_programs(state);
CREATE INDEX IF NOT EXISTS idx_assistance_programs_county ON assistance_programs(county);
CREATE INDEX IF NOT EXISTS idx_assistance_programs_city ON assistance_programs(city);