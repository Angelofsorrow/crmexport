/*
  # Add Review System Triggers and Functions

  1. Changes
    - Drop existing triggers before recreating
    - Add proper error handling
    - Fix trigger naming conflicts
    
  2. Security
    - Maintain existing RLS policies
    - Add proper error handling
*/

-- Drop existing triggers and functions first
DO $$ 
BEGIN
  DROP TRIGGER IF EXISTS review_submission_handler ON reviews;
  DROP TRIGGER IF EXISTS review_status_change_handler ON reviews;
  DROP TRIGGER IF EXISTS review_response_handler ON review_responses;
  DROP TRIGGER IF EXISTS log_review_request_activity ON entity_tags;
  
  DROP FUNCTION IF EXISTS handle_review_submission();
  DROP FUNCTION IF EXISTS handle_review_status_change();
  DROP FUNCTION IF EXISTS handle_review_response();
  DROP FUNCTION IF EXISTS log_review_request();
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create function to handle review submissions
CREATE OR REPLACE FUNCTION handle_review_submission()
RETURNS TRIGGER AS $$
BEGIN
  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    contact_id,
    owner_id,
    created_at
  ) VALUES (
    'review',
    CASE
      WHEN NEW.rating < 5 THEN 'Review Needs Approval'
      ELSE 'Review Submitted'
    END,
    format('Review submitted by %s %s - Rating: %s/5', 
      (SELECT first_name FROM contacts WHERE id = NEW.contact_id),
      (SELECT last_name FROM contacts WHERE id = NEW.contact_id),
      NEW.rating
    ),
    NEW.contact_id,
    NEW.owner_id,
    now()
  );

  -- Auto-approve 5-star reviews
  IF NEW.rating = 5 THEN
    NEW.status := 'approved';
    NEW.is_published := true;
    NEW.reviewed_at := now();
    NEW.reviewed_by := NEW.owner_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to handle review status changes
CREATE OR REPLACE FUNCTION handle_review_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status != OLD.status THEN
    -- Create activity record
    INSERT INTO activities (
      type,
      title,
      description,
      contact_id,
      owner_id,
      created_at
    ) VALUES (
      'review_status',
      format('Review %s', NEW.status),
      format('Review %s by %s. Rating: %s/5', 
        NEW.status,
        (SELECT email FROM auth.users WHERE id = NEW.reviewed_by),
        NEW.rating
      ),
      NEW.contact_id,
      NEW.reviewed_by,
      now()
    );

    -- Send notification if approved
    IF NEW.status = 'approved' THEN
      INSERT INTO activities (
        type,
        title,
        description,
        contact_id,
        owner_id,
        created_at
      ) VALUES (
        'notification',
        'Review Published',
        format('Your review has been published. Thank you for your feedback!'),
        NEW.contact_id,
        NEW.owner_id,
        now()
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to log review requests
CREATE OR REPLACE FUNCTION log_review_request()
RETURNS TRIGGER AS $$
DECLARE
  v_tag_name text;
  v_contact_record RECORD;
BEGIN
  -- Get tag name
  SELECT name INTO v_tag_name
  FROM tags
  WHERE id = NEW.tag_id;

  -- Only process review request tags
  IF v_tag_name = 'Review Requested' THEN
    -- Get contact information
    SELECT first_name, last_name, email 
    INTO v_contact_record 
    FROM contacts 
    WHERE id = NEW.entity_id;

    -- Log the review request
    INSERT INTO activities (
      type,
      title,
      description,
      contact_id,
      owner_id,
      created_at
    ) VALUES (
      'review_request',
      'Review Request Sent',
      format('Review request sent to %s %s (%s)', 
        v_contact_record.first_name,
        v_contact_record.last_name,
        v_contact_record.email
      ),
      NEW.entity_id,
      auth.uid(),
      now()
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER review_submission_handler
  BEFORE INSERT ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION handle_review_submission();

CREATE TRIGGER review_status_change_handler
  AFTER UPDATE OF status ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION handle_review_status_change();

CREATE TRIGGER log_review_request
  AFTER INSERT ON entity_tags
  FOR EACH ROW
  EXECUTE FUNCTION log_review_request();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);
CREATE INDEX IF NOT EXISTS idx_reviews_status ON reviews(status);
CREATE INDEX IF NOT EXISTS idx_reviews_contact_id ON reviews(contact_id);
CREATE INDEX IF NOT EXISTS idx_reviews_submitted_at ON reviews(submitted_at);
CREATE INDEX IF NOT EXISTS idx_reviews_needs_approval ON reviews(needs_approval);
CREATE INDEX IF NOT EXISTS idx_review_responses_review_id ON review_responses(review_id);
CREATE INDEX IF NOT EXISTS idx_activities_review_requests ON activities(type) WHERE type = 'review_request';

-- Add trigger for updating timestamps
DO $$ 
BEGIN
  CREATE TRIGGER set_updated_at
    BEFORE UPDATE ON reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

  CREATE TRIGGER set_updated_at
    BEFORE UPDATE ON review_responses
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;