/*
  # Fix Deal Stage Changes

  1. Changes
    - Update RLS policies for deals table
    - Add policy for viewing all pipeline stages
    - Fix stage_id handling in deals table
    - Add indexes for better performance

  2. Security
    - Allow users to view all pipeline stages
    - Allow users to manage their own deals
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own deals" ON deals;
  DROP POLICY IF EXISTS "Users can manage deals through contacts" ON deals;
  DROP POLICY IF EXISTS "Users can manage their pipeline stages" ON pipeline_stages;
  DROP POLICY IF EXISTS "Users can view all pipeline stages" ON pipeline_stages;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for pipeline stages
CREATE POLICY "Users can view all pipeline stages"
  ON pipeline_stages
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage their pipeline stages"
  ON pipeline_stages
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR 
    is_system = true OR 
    owner_id IS NULL
  )
  WITH CHECK (
    owner_id = auth.uid()
  );

-- Create new policies for deals
CREATE POLICY "Users can manage their own deals"
  ON deals
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Add stage_id to deals if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'deals' AND column_name = 'stage_id'
  ) THEN
    ALTER TABLE deals ADD COLUMN stage_id uuid REFERENCES pipeline_stages(id);
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_deals_stage_id ON deals(stage_id);
CREATE INDEX IF NOT EXISTS idx_deals_owner_id ON deals(owner_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_order_number ON pipeline_stages(order_number);