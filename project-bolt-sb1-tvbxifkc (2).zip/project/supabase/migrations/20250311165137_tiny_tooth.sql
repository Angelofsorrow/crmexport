/*
  # Add storage policies for campaign files

  1. Changes
    - Create storage bucket for campaign files if it doesn't exist
    - Add storage policies to allow authenticated users to:
      - Upload files to their own campaign folders
      - Read files from campaigns they have access to
      - Delete files from their own campaigns
*/

-- Create the storage bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES ('campaign-files', 'campaign-files')
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Create a function to extract campaign ID from path
CREATE OR REPLACE FUNCTION storage.get_campaign_id_from_path(name text)
RETURNS uuid
LANGUAGE sql
AS $$
  SELECT CAST(SPLIT_PART(name, '/', 2) AS uuid);
$$;

-- Policy to allow authenticated users to upload files to their campaigns
CREATE POLICY "Users can upload campaign files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'campaign-files' AND
  SPLIT_PART(name, '/', 1) = 'voicemails' AND
  EXISTS (
    SELECT 1 FROM public.campaigns
    WHERE id = storage.get_campaign_id_from_path(name)
    AND owner_id = auth.uid()
  )
);

-- Policy to allow authenticated users to read campaign files
CREATE POLICY "Users can read campaign files"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'campaign-files' AND
  SPLIT_PART(name, '/', 1) = 'voicemails' AND
  EXISTS (
    SELECT 1 FROM public.campaigns
    WHERE id = storage.get_campaign_id_from_path(name)
    AND owner_id = auth.uid()
  )
);

-- Policy to allow authenticated users to delete their campaign files
CREATE POLICY "Users can delete their campaign files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'campaign-files' AND
  SPLIT_PART(name, '/', 1) = 'voicemails' AND
  EXISTS (
    SELECT 1 FROM public.campaigns
    WHERE id = storage.get_campaign_id_from_path(name)
    AND owner_id = auth.uid()
  )
);