/*
  # Add OpenAI Configuration Table

  1. New Tables
    - `openai_configs`: Stores OpenAI configuration and settings
    
  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create OpenAI configuration table
CREATE TABLE IF NOT EXISTS openai_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  api_key text NOT NULL,
  model text NOT NULL DEFAULT 'gpt-3.5-turbo',
  temperature numeric DEFAULT 0.7,
  max_tokens integer DEFAULT 500,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  is_active boolean DEFAULT true,
  usage_limits jsonb DEFAULT '{"daily": 1000, "monthly": 20000}',
  usage_stats jsonb DEFAULT '{"daily": 0, "monthly": 0, "last_reset": null}',
  UNIQUE(owner_id, name)
);

-- Enable RLS
ALTER TABLE openai_configs ENABLE ROW LEVEL SECURITY;

-- Add RLS policy
CREATE POLICY "Users can manage their OpenAI configurations"
  ON openai_configs
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_openai_configs_owner_id ON openai_configs(owner_id);
CREATE INDEX IF NOT EXISTS idx_openai_configs_is_active ON openai_configs(is_active);