/*
  # Fix Integrations RLS Policy

  1. Changes
    - Drop existing policy that references user_id
    - Create new policy using owner_id
    - Add missing indexes
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Users can manage their integrations" ON integrations;

-- Create new policy using owner_id
CREATE POLICY "Users can manage their integrations"
  ON integrations
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Add indexes for better performance if they don't exist
CREATE INDEX IF NOT EXISTS idx_integrations_owner_id 
  ON integrations(owner_id);