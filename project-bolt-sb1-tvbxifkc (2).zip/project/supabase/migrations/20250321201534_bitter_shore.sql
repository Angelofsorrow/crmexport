/*
  # Create Default User and Organization

  1. Changes
    - Create default user in auth.users
    - Create default organization
    - Create default whitelabel config
    - Create default organization member
    - Add RLS policies
*/

-- Create default user if it doesn't exist
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  role
) VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'admin@example.com',
  crypt('admin123', gen_salt('bf')),
  now(),
  now(),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{"name":"Admin User"}',
  true,
  'authenticated'
) ON CONFLICT (id) DO NOTHING;

-- Create default organization
INSERT INTO organizations (id, name, slug, domain, owner_id)
VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'Default Organization',
  'default-org',
  'localhost',
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9'
) ON CONFLICT DO NOTHING;

-- Create default whitelabel config
INSERT INTO whitelabel_configs (
  organization_id,
  name,
  primary_color,
  secondary_color,
  accent_color,
  font_family,
  is_active
) VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'Default Configuration',
  '#4F46E5',
  '#818CF8', 
  '#6366F1',
  'Inter',
  true
) ON CONFLICT DO NOTHING;

-- Create default organization member
INSERT INTO organization_members (
  organization_id,
  user_id,
  role
) VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'admin'
) ON CONFLICT DO NOTHING;

-- Update RLS policies to allow access to default organization
CREATE POLICY "Allow access to default organization"
  ON organizations
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow access to default whitelabel config"
  ON whitelabel_configs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow access to default organization members"
  ON organization_members
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);