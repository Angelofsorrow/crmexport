/*
  # Fix Database Schema and Relationships

  1. Changes
    - Add missing foreign key relationships
    - Add activities table with proper relationships
    - Add deal_id to documents table
    - Fix borrowers relationship with contacts
    - Add ON DELETE CASCADE where appropriate

  2. Security
    - Enable RLS on all tables
    - Update policies to handle cascading relationships
*/

-- Create activities table with proper relationships
CREATE TABLE IF NOT EXISTS activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  title text NOT NULL,
  description text,
  due_date timestamptz,
  completed_at timestamptz,
  company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS on activities
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;

-- Add policy for activities
CREATE POLICY "Users can manage their own activities"
  ON activities
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Add deal_id to documents if it doesn't exist
ALTER TABLE documents 
ADD COLUMN IF NOT EXISTS deal_id uuid REFERENCES deals(id) ON DELETE CASCADE;

-- Update borrowers table to properly reference contacts
ALTER TABLE borrowers
DROP CONSTRAINT IF EXISTS borrowers_contact_id_fkey,
ADD CONSTRAINT borrowers_contact_id_fkey 
  FOREIGN KEY (contact_id) 
  REFERENCES contacts(id) 
  ON DELETE CASCADE;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS activities_company_id_idx ON activities(company_id);
CREATE INDEX IF NOT EXISTS activities_contact_id_idx ON activities(contact_id);
CREATE INDEX IF NOT EXISTS activities_deal_id_idx ON activities(deal_id);
CREATE INDEX IF NOT EXISTS activities_owner_id_idx ON activities(owner_id);
CREATE INDEX IF NOT EXISTS documents_deal_id_idx ON documents(deal_id);