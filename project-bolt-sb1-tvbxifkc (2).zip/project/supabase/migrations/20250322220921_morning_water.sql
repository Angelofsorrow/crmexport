/*
  # Fix Contact Access Policies

  1. Changes
    - Drop existing contact policies
    - Create new policy that properly handles contact access
    - Add proper indexes for performance
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own contacts" ON contacts;
  DROP POLICY IF EXISTS "Users can manage contacts" ON contacts;
  DROP POLICY IF EXISTS "Default contact access" ON contacts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policy that properly handles contact access
CREATE POLICY "Users can manage their own contacts"
  ON contacts
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contacts_owner_id ON contacts(owner_id);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX IF NOT EXISTS idx_contacts_company_id ON contacts(company_id);
CREATE INDEX IF NOT EXISTS idx_contacts_last_contacted ON contacts(last_contacted);

-- Create full text search index
CREATE INDEX IF NOT EXISTS idx_contacts_full_text ON contacts 
USING gin(
  to_tsvector('english',
    coalesce(first_name, '') || ' ' ||
    coalesce(last_name, '') || ' ' ||
    coalesce(email, '') || ' ' ||
    coalesce(phone, '') || ' ' ||
    coalesce(job_title, '')
  )
);