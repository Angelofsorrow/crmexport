/*
  # Add Default Email Account and Fix RLS

  1. Changes
    - Create default email account for AI agent
    - Update RLS policies for email accounts
    - Add proper indexes and constraints
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their email accounts" ON email_accounts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Add unique constraint for email if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'email_accounts_email_owner_id_key'
  ) THEN
    ALTER TABLE email_accounts 
    ADD CONSTRAINT email_accounts_email_owner_id_key 
    UNIQUE (email, owner_id);
  END IF;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policy that allows public access to default account
CREATE POLICY "Users can manage email accounts"
  ON email_accounts
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR
    owner_id IS NULL
  )
  WITH CHECK (
    owner_id = auth.uid() OR
    owner_id IS NULL
  );

-- Create default email account if it doesn't exist
INSERT INTO email_accounts (
  email,
  display_name,
  imap_host,
  imap_port,
  smtp_host,
  smtp_port,
  username,
  password,
  is_active,
  provider,
  created_at,
  updated_at,
  owner_id
) VALUES (
  'ai-agent@example.com',
  'AI Assistant',
  'localhost',
  993,
  'localhost',
  587,
  'ai-agent',
  'default-password',
  true,
  'system',
  now(),
  now(),
  NULL
) ON CONFLICT (email, owner_id) DO UPDATE SET
  is_active = true,
  updated_at = now();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_email_accounts_provider ON email_accounts(provider);
CREATE INDEX IF NOT EXISTS idx_email_accounts_is_active ON email_accounts(is_active);
CREATE INDEX IF NOT EXISTS idx_email_accounts_email_owner_id ON email_accounts(email, owner_id);