/*
  # Fix Pipeline Stage Dragging

  1. Changes
    - Update RLS policies for deals and stages
    - Add missing indexes
    - Fix stage_id handling
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own deals" ON deals;
  DROP POLICY IF EXISTS "Users can manage deals through contacts" ON deals;
  DROP POLICY IF EXISTS "Users can manage their pipeline stages" ON pipeline_stages;
  DROP POLICY IF EXISTS "Users can view all pipeline stages" ON pipeline_stages;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for pipeline stages
CREATE POLICY "Users can view all pipeline stages"
  ON pipeline_stages
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage their pipeline stages"
  ON pipeline_stages
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR 
    is_system = true OR 
    owner_id IS NULL
  )
  WITH CHECK (
    owner_id = auth.uid()
  );

-- Create new policies for deals
CREATE POLICY "Users can manage their own deals"
  ON deals
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Add stage_id to deals if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'deals' AND column_name = 'stage_id'
  ) THEN
    ALTER TABLE deals ADD COLUMN stage_id uuid REFERENCES pipeline_stages(id);
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_deals_stage_id ON deals(stage_id);
CREATE INDEX IF NOT EXISTS idx_deals_owner_id ON deals(owner_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_order_number ON pipeline_stages(order_number);

-- Add trigger to update deal status based on stage
CREATE OR REPLACE FUNCTION update_deal_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Get stage information
  WITH stage_info AS (
    SELECT is_closed, is_won
    FROM pipeline_stages
    WHERE id = NEW.stage_id
  )
  -- Update deal status based on stage
  UPDATE deals SET
    status = CASE 
      WHEN (SELECT is_closed FROM stage_info) THEN
        CASE 
          WHEN (SELECT is_won FROM stage_info) THEN 'won'
          ELSE 'lost'
        END
      ELSE 'open'
    END
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS deal_stage_status_update ON deals;
CREATE TRIGGER deal_stage_status_update
  AFTER UPDATE OF stage_id ON deals
  FOR EACH ROW
  WHEN (OLD.stage_id IS DISTINCT FROM NEW.stage_id)
  EXECUTE FUNCTION update_deal_status();