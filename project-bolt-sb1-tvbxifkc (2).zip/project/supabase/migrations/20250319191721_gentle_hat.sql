/*
  # Fix Contacts-Companies Relationship

  1. Changes
    - Drop and recreate contacts table with proper foreign key constraint
    - Migrate existing data
    - Re-enable RLS and policies

  2. Security
    - Maintain existing RLS policies
    - Ensure data integrity during migration
*/

-- Create temporary table to store existing contacts
CREATE TABLE IF NOT EXISTS contacts_temp AS SELECT * FROM contacts;

-- Drop existing contacts table
DROP TABLE IF EXISTS contacts CASCADE;

-- Recreate contacts table with proper foreign key constraint
CREATE TABLE contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text,
  phone text,
  job_title text,
  company_id uuid REFERENCES companies(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  last_contacted timestamptz
);

-- Copy data from temp table
INSERT INTO contacts (
  id, first_name, last_name, email, phone, job_title,
  company_id, created_at, updated_at, owner_id, last_contacted
)
SELECT
  id, first_name, last_name, email, phone, job_title,
  company_id, created_at, updated_at, owner_id, last_contacted
FROM contacts_temp;

-- Drop temp table
DROP TABLE contacts_temp;

-- Enable RLS
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;

-- Recreate RLS policy
CREATE POLICY "Users can manage their own contacts"
  ON contacts
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS contacts_company_id_idx ON contacts(company_id);
CREATE INDEX IF NOT EXISTS contacts_owner_id_idx ON contacts(owner_id);
CREATE INDEX IF NOT EXISTS contacts_email_idx ON contacts(email);
CREATE INDEX IF NOT EXISTS contacts_phone_idx ON contacts(phone);