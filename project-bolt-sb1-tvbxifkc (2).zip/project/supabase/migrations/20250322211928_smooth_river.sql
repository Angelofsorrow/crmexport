/*
  # Fix Email Accounts Setup

  1. Changes
    - Drop and recreate email_accounts table
    - Add proper constraints and indexes
    - Create default system email account
    - Add RLS policies
*/

-- Drop existing table and policies
DROP TABLE IF EXISTS email_accounts CASCADE;

-- Create email_accounts table
CREATE TABLE email_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  display_name text,
  imap_host text NOT NULL,
  imap_port integer NOT NULL,
  smtp_host text NOT NULL,
  smtp_port integer NOT NULL,
  username text NOT NULL,
  password text NOT NULL,
  is_active boolean DEFAULT true,
  last_sync_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  provider text,
  access_token text,
  refresh_token text,
  token_expires_at timestamptz
);

-- Add unique constraint
ALTER TABLE email_accounts
ADD CONSTRAINT email_accounts_email_owner_id_key UNIQUE (email, owner_id);

-- Enable RLS
ALTER TABLE email_accounts ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Default email account access"
  ON email_accounts
  FOR ALL
  TO public
  USING (owner_id IS NULL);

CREATE POLICY "Users can manage their email accounts"
  ON email_accounts
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Insert default system account
INSERT INTO email_accounts (
  email,
  display_name,
  imap_host,
  imap_port,
  smtp_host,
  smtp_port,
  username,
  password,
  is_active,
  provider,
  owner_id
) VALUES (
  'ai-agent@example.com',
  'AI Assistant',
  'localhost',
  993,
  'localhost',
  587,
  'ai-agent',
  'default-password',
  true,
  'system',
  NULL
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_accounts_provider ON email_accounts(provider);
CREATE INDEX IF NOT EXISTS idx_email_accounts_is_active ON email_accounts(is_active);
CREATE INDEX IF NOT EXISTS idx_email_accounts_email_owner_id ON email_accounts(email, owner_id);
CREATE INDEX IF NOT EXISTS idx_email_accounts_token_expires ON email_accounts(token_expires_at);