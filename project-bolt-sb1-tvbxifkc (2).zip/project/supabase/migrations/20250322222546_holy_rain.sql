/*
  # Add Contact Lists Management

  1. New Tables
    - `contact_lists`: Stores list definitions
    - `contact_list_members`: Links contacts to lists
    
  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their contact lists" ON contact_lists;
  DROP POLICY IF EXISTS "Users can manage list members" ON contact_list_members;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create contact lists table if it doesn't exist
CREATE TABLE IF NOT EXISTS contact_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  type text NOT NULL CHECK (type IN ('static', 'dynamic')),
  filter_criteria jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Create contact list members table if it doesn't exist
CREATE TABLE IF NOT EXISTS contact_list_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  list_id uuid REFERENCES contact_lists(id) ON DELETE CASCADE,
  contact_id uuid REFERENCES contacts(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(list_id, contact_id)
);

-- Enable RLS
ALTER TABLE contact_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_list_members ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their contact lists"
  ON contact_lists
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage list members"
  ON contact_list_members
  FOR ALL
  TO authenticated
  USING (
    list_id IN (
      SELECT id FROM contact_lists WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    list_id IN (
      SELECT id FROM contact_lists WHERE owner_id = auth.uid()
    )
  );

-- Create indexes if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_contact_lists_owner_id'
  ) THEN
    CREATE INDEX idx_contact_lists_owner_id ON contact_lists(owner_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_contact_lists_type'
  ) THEN
    CREATE INDEX idx_contact_lists_type ON contact_lists(type);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_contact_list_members_list_id'
  ) THEN
    CREATE INDEX idx_contact_list_members_list_id ON contact_list_members(list_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_contact_list_members_contact_id'
  ) THEN
    CREATE INDEX idx_contact_list_members_contact_id ON contact_list_members(contact_id);
  END IF;
END $$;

-- Add trigger for updating timestamps if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'set_updated_at'
  ) THEN
    CREATE TRIGGER set_updated_at
      BEFORE UPDATE ON contact_lists
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;