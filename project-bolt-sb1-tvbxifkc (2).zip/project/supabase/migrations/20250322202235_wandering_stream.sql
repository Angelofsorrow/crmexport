/*
  # Fix Activities RLS Policy

  1. Changes
    - Drop existing activities RLS policy
    - Create new policy that allows AI agent and system activities
    - Add proper indexes for performance
*/

-- Drop existing policy
DROP POLICY IF EXISTS "Users can manage their own activities" ON activities;

-- Create new policy that allows AI agent activities
CREATE POLICY "Users can manage activities"
  ON activities
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR                -- User's own activities
    owner_id IS NULL OR                     -- System activities
    EXISTS (                                -- Activities related to user's contacts
      SELECT 1 FROM contacts 
      WHERE contacts.id = activities.contact_id 
      AND contacts.owner_id = auth.uid()
    ) OR
    EXISTS (                                -- Activities related to user's deals
      SELECT 1 FROM deals 
      WHERE deals.id = activities.deal_id 
      AND deals.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    owner_id = auth.uid() OR               -- User can create own activities
    owner_id IS NULL                       -- System can create activities
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_activities_owner_id 
  ON activities(owner_id);

CREATE INDEX IF NOT EXISTS idx_activities_contact_id 
  ON activities(contact_id);

CREATE INDEX IF NOT EXISTS idx_activities_deal_id 
  ON activities(deal_id);

CREATE INDEX IF NOT EXISTS idx_activities_type 
  ON activities(type);

CREATE INDEX IF NOT EXISTS idx_activities_due_date 
  ON activities(due_date);