/*
  # Add AI Assistant Triggers and Functions

  1. Changes
    - Add trigger functions for AI processing
    - Add triggers for message handling
    - Add sensor data processing
    
  2. Security
    - Drop existing policies before recreating
    - Maintain RLS security
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view sensor data" ON sensor_data;
  DROP POLICY IF EXISTS "Users can manage device commands" ON device_commands;
  DROP POLICY IF EXISTS "Users can view sensor logs" ON sensor_logs;
  DROP POLICY IF EXISTS "Users can view physical agent logs" ON physical_agent_logs;
  DROP POLICY IF EXISTS "Users can view physical agent errors" ON physical_agent_errors;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create tables for AI processing
CREATE TABLE IF NOT EXISTS sensor_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  value numeric NOT NULL,
  unit text NOT NULL,
  device_id text NOT NULL,
  location text NOT NULL,
  timestamp timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS device_commands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  command text NOT NULL,
  parameters jsonb NOT NULL,
  device_id text NOT NULL,
  status text NOT NULL,
  sent_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  result jsonb
);

CREATE TABLE IF NOT EXISTS sensor_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sensor_data jsonb NOT NULL,
  reasoning text,
  logged_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS physical_agent_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  action text NOT NULL,
  parameters jsonb NOT NULL,
  executed_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS physical_agent_errors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  context text NOT NULL,
  error text NOT NULL,
  stack text,
  occurred_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE sensor_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE device_commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE sensor_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE physical_agent_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE physical_agent_errors ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Users can view sensor data"
  ON sensor_data FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage device commands"
  ON device_commands FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can view sensor logs"
  ON sensor_logs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view physical agent logs"
  ON physical_agent_logs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view physical agent errors"
  ON physical_agent_errors FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_sensor_data_type ON sensor_data(type);
CREATE INDEX IF NOT EXISTS idx_sensor_data_device_id ON sensor_data(device_id);
CREATE INDEX IF NOT EXISTS idx_sensor_data_timestamp ON sensor_data("timestamp");
CREATE INDEX IF NOT EXISTS idx_device_commands_device_id ON device_commands(device_id);
CREATE INDEX IF NOT EXISTS idx_device_commands_status ON device_commands(status);
CREATE INDEX IF NOT EXISTS idx_physical_agent_logs_type ON physical_agent_logs(type);

-- Create trigger function for deal stage changes
CREATE OR REPLACE FUNCTION update_deal_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Get stage information
  WITH stage_info AS (
    SELECT is_closed, is_won
    FROM pipeline_stages
    WHERE id = NEW.stage_id
  )
  -- Update deal status based on stage
  UPDATE deals SET
    status = CASE 
      WHEN (SELECT is_closed FROM stage_info) THEN
        CASE 
          WHEN (SELECT is_won FROM stage_info) THEN 'won'
          ELSE 'lost'
        END
      ELSE 'open'
    END
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for deal stage changes
DROP TRIGGER IF EXISTS deal_stage_status_update ON deals;
CREATE TRIGGER deal_stage_status_update
  AFTER UPDATE OF stage_id ON deals
  FOR EACH ROW
  WHEN (OLD.stage_id IS DISTINCT FROM NEW.stage_id)
  EXECUTE FUNCTION update_deal_status();

-- Create trigger function for ensuring user organization
CREATE OR REPLACE FUNCTION ensure_user_organization()
RETURNS TRIGGER AS $$
DECLARE
  org_id uuid;
BEGIN
  -- Check if user already has an organization
  SELECT organization_id INTO org_id
  FROM organization_members
  WHERE user_id = NEW.id
  LIMIT 1;

  -- If no organization found, create one and add membership
  IF org_id IS NULL THEN
    -- Create organization
    INSERT INTO organizations (name, slug, domain, owner_id)
    VALUES (
      'My Organization',
      'my-org-' || NEW.id,
      NULL,
      NEW.id
    )
    RETURNING id INTO org_id;

    -- Create organization membership
    INSERT INTO organization_members (organization_id, user_id, role)
    VALUES (org_id, NEW.id, 'admin');

    -- Create whitelabel config
    INSERT INTO whitelabel_configs (
      organization_id,
      name,
      primary_color,
      secondary_color,
      accent_color,
      font_family,
      is_active
    ) VALUES (
      org_id,
      'Default Configuration',
      '#4F46E5',
      '#818CF8',
      '#6366F1',
      'Inter',
      true
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION ensure_user_organization();

-- Create trigger function for updating updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers to all relevant tables
DO $$ 
DECLARE
  t text;
BEGIN
  FOR t IN 
    SELECT table_name 
    FROM information_schema.columns 
    WHERE column_name = 'updated_at' 
    AND table_schema = 'public'
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS set_updated_at ON %I;
      CREATE TRIGGER set_updated_at
        BEFORE UPDATE ON %I
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    ', t, t);
  END LOOP;
END $$;