/*
  # Fix Organization Member Policies

  1. Changes
    - Drop existing policies that cause recursion
    - Create new non-recursive policies
    - Simplify access control logic
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view organizations" ON organizations;
  DROP POLICY IF EXISTS "Users can manage organizations" ON organizations;
  DROP POLICY IF EXISTS "Users can view organization members" ON organization_members;
  DROP POLICY IF EXISTS "Organization owners can manage members" ON organization_members;
  DROP POLICY IF EXISTS "Default organization access" ON organization_members;
  DROP POLICY IF EXISTS "Users can view their organization memberships" ON organization_members;
  DROP POLICY IF EXISTS "Allow access to default organization members" ON organization_members;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new simplified policies
CREATE POLICY "Users can view organizations"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (
    id = 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9' OR  -- Default org
    owner_id = auth.uid()                            -- Owned orgs
  );

CREATE POLICY "Users can manage organizations"
  ON organizations
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Simple, non-recursive policies for organization members
CREATE POLICY "Users can view all organization members"
  ON organization_members
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Organization owners can manage members"
  ON organization_members
  FOR INSERT
  TO authenticated
  WITH CHECK (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Organization owners can update members"
  ON organization_members
  FOR UPDATE
  TO authenticated
  USING (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Organization owners can delete members"
  ON organization_members
  FOR DELETE
  TO authenticated
  USING (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

-- Ensure default organization exists
INSERT INTO organizations (
  id,
  name,
  slug,
  domain
) VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'Default Organization',
  'default',
  'localhost'
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  slug = EXCLUDED.slug,
  domain = EXCLUDED.domain;

-- Ensure indexes exist
CREATE INDEX IF NOT EXISTS idx_organizations_owner_id ON organizations(owner_id);
CREATE INDEX IF NOT EXISTS idx_organization_members_user_id ON organization_members(user_id);
CREATE INDEX IF NOT EXISTS idx_organization_members_organization_id ON organization_members(organization_id);