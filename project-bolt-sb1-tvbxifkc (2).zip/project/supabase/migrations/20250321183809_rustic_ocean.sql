/*
  # Fix Storage and Configuration Setup

  1. Changes
    - Drop existing storage policies before recreating
    - Create storage buckets if they don't exist
    - Add OpenAI configuration
    - Fix API key policies
    
  2. Security
    - Properly handle existing policies
    - Ensure RLS is enabled
*/

-- Drop existing storage policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can upload documents" ON storage.objects;
  DROP POLICY IF EXISTS "Users can read their documents" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete their documents" ON storage.objects;
  DROP POLICY IF EXISTS "Users can manage their profile photos" ON storage.objects;
  DROP POLICY IF EXISTS "Users can manage their campaign files" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create storage buckets if they don't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES 
    ('documents', 'documents', false),
    ('profile-photos', 'profile-photos', false),
    ('campaign-files', 'campaign-files', false)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create new storage policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage' 
    AND policyname = 'Users can upload documents'
  ) THEN
    CREATE POLICY "Users can upload documents"
      ON storage.objects FOR INSERT TO authenticated
      WITH CHECK (
        bucket_id = 'documents' AND
        auth.uid()::text = (storage.foldername(name))[1]
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage' 
    AND policyname = 'Users can read their documents'
  ) THEN
    CREATE POLICY "Users can read their documents"
      ON storage.objects FOR SELECT TO authenticated
      USING (
        bucket_id = 'documents' AND
        auth.uid()::text = (storage.foldername(name))[1]
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage' 
    AND policyname = 'Users can delete their documents'
  ) THEN
    CREATE POLICY "Users can delete their documents"
      ON storage.objects FOR DELETE TO authenticated
      USING (
        bucket_id = 'documents' AND
        auth.uid()::text = (storage.foldername(name))[1]
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage' 
    AND policyname = 'Users can manage their profile photos'
  ) THEN
    CREATE POLICY "Users can manage their profile photos"
      ON storage.objects
      FOR ALL TO authenticated
      USING (
        bucket_id = 'profile-photos' AND
        auth.uid()::text = (storage.foldername(name))[1]
      )
      WITH CHECK (
        bucket_id = 'profile-photos' AND
        auth.uid()::text = (storage.foldername(name))[1]
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage' 
    AND policyname = 'Users can manage their campaign files'
  ) THEN
    CREATE POLICY "Users can manage their campaign files"
      ON storage.objects
      FOR ALL TO authenticated
      USING (
        bucket_id = 'campaign-files' AND
        auth.uid()::text = (storage.foldername(name))[1]
      )
      WITH CHECK (
        bucket_id = 'campaign-files' AND
        auth.uid()::text = (storage.foldername(name))[1]
      );
  END IF;
END $$;

-- Update API key policy
DROP POLICY IF EXISTS "Users can manage their API keys" ON api_keys;
CREATE POLICY "Users can manage API keys"
  ON api_keys
  FOR ALL TO authenticated
  USING (
    CASE 
      WHEN owner_id IS NULL THEN true
      ELSE owner_id = auth.uid()
    END
  )
  WITH CHECK (owner_id = auth.uid());

-- Add default OpenAI configuration table if it doesn't exist
CREATE TABLE IF NOT EXISTS openai_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  api_key text NOT NULL,
  model text NOT NULL DEFAULT 'gpt-3.5-turbo',
  temperature numeric DEFAULT 0.7,
  max_tokens integer DEFAULT 500,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  is_active boolean DEFAULT true,
  usage_limits jsonb DEFAULT '{"daily": 1000, "monthly": 20000}',
  usage_stats jsonb DEFAULT '{"daily": 0, "monthly": 0, "last_reset": null}',
  UNIQUE(owner_id, name)
);

-- Enable RLS on OpenAI configs if not already enabled
ALTER TABLE openai_configs ENABLE ROW LEVEL SECURITY;

-- Add RLS policy for OpenAI configs if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'openai_configs' 
    AND policyname = 'Users can manage their OpenAI configurations'
  ) THEN
    CREATE POLICY "Users can manage their OpenAI configurations"
      ON openai_configs
      FOR ALL TO authenticated
      USING (owner_id = auth.uid())
      WITH CHECK (owner_id = auth.uid());
  END IF;
END $$;

-- Create indexes for OpenAI configs if they don't exist
CREATE INDEX IF NOT EXISTS idx_openai_configs_owner_id ON openai_configs(owner_id);
CREATE INDEX IF NOT EXISTS idx_openai_configs_is_active ON openai_configs(is_active);

-- Add trigger for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add updated_at triggers to all relevant tables
DO $$ 
DECLARE
  t text;
BEGIN
  FOR t IN 
    SELECT table_name 
    FROM information_schema.columns 
    WHERE column_name = 'updated_at' 
    AND table_schema = 'public'
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS set_updated_at ON %I;
      CREATE TRIGGER set_updated_at
        BEFORE UPDATE ON %I
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    ', t, t);
  END LOOP;
END $$;