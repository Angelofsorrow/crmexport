/*
  # Fix Calendar Event Triggers and Functions

  1. Changes
    - Drop existing triggers and functions
    - Recreate functions with proper error handling
    - Add triggers in correct order
    - Fix function dependencies
*/

-- Drop existing triggers and functions
DO $$ 
BEGIN
  DROP TRIGGER IF EXISTS calendar_event_logger ON calendar_events;
  DROP TRIGGER IF EXISTS calendar_event_processor ON calendar_events;
  DROP TRIGGER IF EXISTS calendar_sync_trigger ON calendar_events;
  DROP TRIGGER IF EXISTS ai_calendar_event_processor ON calendar_events;
  DROP TRIGGER IF EXISTS user_input_trigger ON calendar_events;
  
  DROP FUNCTION IF EXISTS log_calendar_activity();
  DROP FUNCTION IF EXISTS process_calendar_event();
  DROP FUNCTION IF EXISTS sync_calendar_event();
  DROP FUNCTION IF EXISTS process_ai_calendar_request();
  DROP FUNCTION IF EXISTS handle_user_input();
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create function to log calendar activities
CREATE OR REPLACE FUNCTION log_calendar_activity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'calendar_log',
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'Event Created'
      WHEN TG_OP = 'UPDATE' THEN 'Event Updated'
      WHEN TG_OP = 'DELETE' THEN 'Event Deleted'
      ELSE 'Event Modified'
    END,
    jsonb_build_object(
      'event_id', COALESCE(NEW.id, OLD.id),
      'title', COALESCE(NEW.title, OLD.title),
      'operation', TG_OP,
      'timestamp', now()
    )::text,
    COALESCE(NEW.owner_id, OLD.owner_id),
    now()
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

-- Create function to process calendar events
CREATE OR REPLACE FUNCTION process_calendar_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_activity_id uuid;
BEGIN
  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    due_date,
    contact_id,
    deal_id,
    owner_id,
    created_at
  ) VALUES (
    'calendar_event',
    NEW.title,
    COALESCE(NEW.description, 'Calendar event'),
    NEW.start,
    NEW.contact_id,
    NEW.deal_id,
    NEW.owner_id,
    now()
  ) RETURNING id INTO v_activity_id;

  -- Update AI context if it's an AI-generated event
  IF NEW.source = 'ai_agent' THEN
    INSERT INTO ai_context (
      user_id,
      entity_type,
      entity_id,
      context_data,
      created_at
    ) VALUES (
      NEW.owner_id,
      'calendar_event',
      NEW.id,
      jsonb_build_object(
        'event_type', 'calendar',
        'title', NEW.title,
        'description', NEW.description,
        'start_time', NEW.start,
        'end_time', NEW."end",
        'location', NEW.location,
        'attendees', NEW.attendees,
        'activity_id', v_activity_id
      ),
      now()
    ) ON CONFLICT (user_id, entity_type, entity_id) 
    DO UPDATE SET
      context_data = EXCLUDED.context_data,
      updated_at = now();
  END IF;

  -- Notify attendees if present
  IF NEW.attendees IS NOT NULL AND jsonb_array_length(NEW.attendees) > 0 THEN
    FOR i IN 0..jsonb_array_length(NEW.attendees) - 1 LOOP
      INSERT INTO activities (
        type,
        title,
        description,
        due_date,
        contact_id,
        owner_id,
        created_at
      ) VALUES (
        'event_notification',
        'Calendar Invitation: ' || NEW.title,
        COALESCE(NEW.description, 'You have been invited to an event'),
        NEW.start,
        -- Try to find contact by email
        (
          SELECT id 
          FROM contacts 
          WHERE email = (NEW.attendees->i->>'email')
          LIMIT 1
        ),
        NEW.owner_id,
        now()
      );
    END LOOP;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'Calendar Event Processing',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create function to sync calendar events
CREATE OR REPLACE FUNCTION sync_calendar_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Log sync attempt
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'calendar_sync',
    'Calendar Sync Attempted',
    'Attempting to sync event: ' || NEW.title,
    NEW.owner_id,
    now()
  );

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'Calendar Event Sync',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create function to process AI calendar requests
CREATE OR REPLACE FUNCTION process_ai_calendar_request()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_interaction_id uuid;
BEGIN
  -- Create AI interaction record
  INSERT INTO ai_interactions (
    user_id,
    request_type,
    request_data,
    status,
    created_at
  ) VALUES (
    NEW.owner_id,
    'calendar_event',
    jsonb_build_object(
      'event_id', NEW.id,
      'title', NEW.title,
      'description', NEW.description,
      'start_time', NEW.start,
      'end_time', NEW."end",
      'location', NEW.location,
      'attendees', NEW.attendees
    ),
    'completed',
    now()
  ) RETURNING id INTO v_interaction_id;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'AI Calendar Request Processing',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create function to handle user input
CREATE OR REPLACE FUNCTION handle_user_input()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Log user input
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'user_input',
    'Calendar Event Created',
    'User created calendar event: ' || NEW.title,
    NEW.owner_id,
    now()
  );

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'User Input Processing',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create triggers in correct order
CREATE TRIGGER calendar_event_logger
  AFTER INSERT OR DELETE OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION log_calendar_activity();

CREATE TRIGGER calendar_event_processor
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION process_calendar_event();

CREATE TRIGGER calendar_sync_trigger
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION sync_calendar_event();

CREATE TRIGGER ai_calendar_event_processor
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  WHEN (NEW.source = 'ai_agent')
  EXECUTE FUNCTION process_ai_calendar_request();

CREATE TRIGGER user_input_trigger
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_input();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_events_source 
  ON calendar_events(source);

CREATE INDEX IF NOT EXISTS idx_calendar_events_owner_id 
  ON calendar_events(owner_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_contact_id 
  ON calendar_events(contact_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_deal_id 
  ON calendar_events(deal_id);