-- Drop existing campaign policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own campaigns" ON campaigns;
  DROP POLICY IF EXISTS "Users can manage steps for their campaigns" ON campaign_steps;
  DROP POLICY IF EXISTS "Users can manage contacts for their campaigns" ON campaign_contacts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies with proper owner_id handling
CREATE POLICY "Users can manage their own campaigns"
  ON campaigns
  FOR ALL
  TO authenticated
  USING (
    CASE 
      WHEN owner_id IS NULL THEN true  -- Allow creation of new campaigns
      ELSE owner_id = auth.uid()       -- Only allow access to owned campaigns
    END
  )
  WITH CHECK (
    CASE
      WHEN owner_id IS NULL THEN true  -- Allow creation of new campaigns
      ELSE owner_id = auth.uid()       -- Only allow modifications to owned campaigns
    END
  );

-- Update campaign steps policy
CREATE POLICY "Users can manage steps for their campaigns"
  ON campaign_steps
  FOR ALL
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM campaigns WHERE owner_id = auth.uid() OR owner_id IS NULL
    )
  )
  WITH CHECK (
    campaign_id IN (
      SELECT id FROM campaigns WHERE owner_id = auth.uid() OR owner_id IS NULL
    )
  );

-- Update campaign contacts policy
CREATE POLICY "Users can manage contacts for their campaigns"
  ON campaign_contacts
  FOR ALL
  TO authenticated
  USING (
    campaign_id IN (
      SELECT id FROM campaigns WHERE owner_id = auth.uid() OR owner_id IS NULL
    )
  )
  WITH CHECK (
    campaign_id IN (
      SELECT id FROM campaigns WHERE owner_id = auth.uid() OR owner_id IS NULL
    )
  );