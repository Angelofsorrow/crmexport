-- Update pipeline stages for mortgage loan process
UPDATE pipeline_stages SET
  name = 'Pre-Qualification',
  description = 'Initial borrower assessment and pre-qualification',
  color = 'bg-blue-600',
  icon = 'ClipboardCheck',
  probability = 30,
  tasks = ARRAY[
    'Review credit report',
    'Calculate debt-to-income ratio',
    'Verify employment status',
    'Estimate loan amount',
    'Check eligibility for loan programs'
  ],
  automations = ARRAY[
    'Pull credit report',
    'Send pre-qualification letter',
    'Schedule initial consultation',
    'Create loan estimate',
    'Send program recommendations'
  ]
WHERE order_number = 1;

UPDATE pipeline_stages SET
  name = 'Application',
  description = 'Formal loan application and document collection',
  color = 'bg-purple-600',
  icon = 'FileText',
  probability = 45,
  tasks = ARRAY[
    'Complete loan application',
    'Collect required documents',
    'Review income documentation',
    'Verify assets and liabilities',
    'Order property appraisal'
  ],
  automations = ARRAY[
    'Send document checklist',
    'Schedule application review',
    'Order credit report',
    'Create loan file',
    'Send application confirmation'
  ]
WHERE order_number = 2;

UPDATE pipeline_stages SET
  name = 'Processing',
  description = 'Loan processing and document verification',
  color = 'bg-indigo-600',
  icon = 'FileSearch',
  probability = 60,
  tasks = ARRAY[
    'Verify employment',
    'Review bank statements',
    'Check tax returns',
    'Analyze credit report',
    'Prepare file for underwriting'
  ],
  automations = ARRAY[
    'Send VOE requests',
    'Order title search',
    'Schedule processing review',
    'Generate processing checklist',
    'Update loan status'
  ]
WHERE order_number = 3;

UPDATE pipeline_stages SET
  name = 'Underwriting',
  description = 'Loan underwriting and risk assessment',
  color = 'bg-yellow-600',
  icon = 'Scale',
  probability = 75,
  tasks = ARRAY[
    'Review appraisal report',
    'Analyze debt ratios',
    'Verify assets',
    'Check employment history',
    'Evaluate risk factors'
  ],
  automations = ARRAY[
    'Generate underwriting report',
    'Send conditions list',
    'Schedule underwriting review',
    'Update loan status',
    'Send approval notification'
  ]
WHERE order_number = 4;

UPDATE pipeline_stages SET
  name = 'Conditions',
  description = 'Clearing conditions and final approval',
  color = 'bg-orange-600',
  icon = 'CheckSquare',
  probability = 85,
  tasks = ARRAY[
    'Review conditions list',
    'Collect missing documents',
    'Verify condition clearance',
    'Update loan file',
    'Prepare for closing'
  ],
  automations = ARRAY[
    'Send conditions reminder',
    'Track condition status',
    'Schedule final review',
    'Generate closing checklist',
    'Update loan status'
  ]
WHERE order_number = 5;

UPDATE pipeline_stages SET
  name = 'Closing',
  description = 'Final closing preparation and documentation',
  color = 'bg-pink-600',
  icon = 'FileSignature',
  probability = 95,
  tasks = ARRAY[
    'Prepare closing documents',
    'Schedule closing date',
    'Review final figures',
    'Coordinate with title company',
    'Arrange final walkthrough'
  ],
  automations = ARRAY[
    'Generate closing disclosure',
    'Send closing instructions',
    'Schedule closing appointment',
    'Order wire transfer',
    'Send closing reminders'
  ]
WHERE order_number = 6;

UPDATE pipeline_stages SET
  name = 'Funded',
  description = 'Loan successfully funded and closed',
  color = 'bg-green-600',
  icon = 'BadgeCheck',
  probability = 100,
  tasks = ARRAY[
    'Confirm wire transfer',
    'Record final documents',
    'Send welcome package',
    'Set up servicing',
    'Archive loan file'
  ],
  automations = ARRAY[
    'Send funding confirmation',
    'Generate welcome letter',
    'Schedule follow-up call',
    'Update loan status',
    'Create servicing record'
  ]
WHERE order_number = 7;

UPDATE pipeline_stages SET
  name = 'Declined',
  description = 'Loan application declined or withdrawn',
  color = 'bg-red-600',
  icon = 'XCircle',
  probability = 0,
  tasks = ARRAY[
    'Document decline reasons',
    'Send adverse action notice',
    'Record decision details',
    'Archive application',
    'Plan follow-up strategy'
  ],
  automations = ARRAY[
    'Generate adverse action letter',
    'Send decline notification',
    'Schedule follow-up in 6 months',
    'Update loan status',
    'Archive documents'
  ]
WHERE order_number = 8;