/*
  # Add Assistance Programs and Enhanced Loan Products

  1. Changes
    - Add assistance_programs table for down payment and other assistance
    - Add more detailed qualification criteria to loan_products
    - Add relationships between programs and loan products
    
  2. Security
    - Enable RLS on new table
    - Add policies for authenticated users
*/

-- Create assistance programs table
CREATE TABLE IF NOT EXISTS assistance_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  description text,
  provider text NOT NULL,
  max_assistance_amount numeric,
  income_limit_percentage numeric,
  area_median_income_required boolean DEFAULT true,
  first_time_homebuyer_only boolean DEFAULT false,
  credit_score_min integer,
  dti_max numeric,
  eligible_property_types text[],
  eligible_loan_types text[],
  repayment_terms text,
  forgiveness_terms text,
  state_restrictions text[],
  requirements text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE assistance_programs ENABLE ROW LEVEL SECURITY;

-- Add policy if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'assistance_programs' 
    AND policyname = 'Users can view assistance programs'
  ) THEN
    CREATE POLICY "Users can view assistance programs"
      ON assistance_programs FOR SELECT
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Insert common assistance programs
INSERT INTO assistance_programs (
  name, type, description, provider, max_assistance_amount,
  income_limit_percentage, first_time_homebuyer_only,
  credit_score_min, dti_max, eligible_property_types,
  eligible_loan_types, requirements, state_restrictions
) VALUES
  (
    'FHA Down Payment Assistance',
    'down_payment',
    'Down payment assistance for FHA loans',
    'HUD',
    10000,
    115,
    true,
    580,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    ARRAY['FHA'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must complete homebuyer education course',
      'Must occupy as primary residence'
    ],
    NULL
  ),
  (
    'HomeReady Down Payment Assistance',
    'down_payment',
    'Fannie Mae''s low down payment program',
    'Fannie Mae',
    15000,
    80,
    false,
    620,
    50,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['Conventional'],
    ARRAY[
      'Income must not exceed 80% of AMI',
      'Must complete homebuyer education if all borrowers are first-time homebuyers',
      'At least one borrower must occupy the property'
    ],
    NULL
  ),
  (
    'VA Grant Program',
    'grant',
    'Grant for disabled veterans',
    'VA',
    25000,
    NULL,
    false,
    580,
    60,
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    ARRAY['VA'],
    ARRAY[
      'Must be a disabled veteran',
      'Must occupy as primary residence',
      'Must meet VA eligibility requirements'
    ],
    NULL
  ),
  (
    'Good Neighbor Next Door',
    'discount',
    '50% discount on HUD homes for public servants',
    'HUD',
    NULL,
    NULL,
    false,
    580,
    45,
    ARRAY['Single Family'],
    ARRAY['FHA', 'Conventional'],
    ARRAY[
      'Must be a teacher, firefighter, EMT, or law enforcement officer',
      'Must serve in program-designated area',
      'Must commit to 36-month occupancy'
    ],
    NULL
  ),
  (
    'State Bond Program',
    'bond',
    'Below-market interest rate financing',
    'State Housing Agency',
    NULL,
    120,
    true,
    640,
    45,
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    ARRAY['FHA', 'Conventional', 'VA', 'USDA'],
    ARRAY[
      'Must be a first-time homebuyer',
      'Must meet income limits',
      'Must complete homebuyer education'
    ],
    NULL
  ),
  (
    'USDA Rural Grant',
    'grant',
    'Grant for rural home purchase or repair',
    'USDA',
    7500,
    80,
    false,
    640,
    41,
    ARRAY['Single Family'],
    ARRAY['USDA'],
    ARRAY[
      'Property must be in eligible rural area',
      'Must be unable to obtain credit elsewhere',
      'Must meet income requirements'
    ],
    NULL
  );

-- Add new fields to loan_products
ALTER TABLE loan_products
ADD COLUMN IF NOT EXISTS eligible_property_types text[],
ADD COLUMN IF NOT EXISTS income_limits jsonb,
ADD COLUMN IF NOT EXISTS eligible_assistance_programs uuid[],
ADD COLUMN IF NOT EXISTS dti_limits jsonb,
ADD COLUMN IF NOT EXISTS credit_score_ranges jsonb;

-- Update existing loan products with new fields
UPDATE loan_products SET
  eligible_property_types = ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
  income_limits = '{"single": 150000, "joint": 250000}',
  dti_limits = '{"front": 28, "back": 36}',
  credit_score_ranges = '[
    {"min": 740, "max": 850, "rate_adjustment": -0.5},
    {"min": 720, "max": 739, "rate_adjustment": -0.25},
    {"min": 700, "max": 719, "rate_adjustment": 0},
    {"min": 680, "max": 699, "rate_adjustment": 0.25},
    {"min": 660, "max": 679, "rate_adjustment": 0.5},
    {"min": 640, "max": 659, "rate_adjustment": 0.75},
    {"min": 620, "max": 639, "rate_adjustment": 1}
  ]'::jsonb
WHERE type = 'Conventional';

UPDATE loan_products SET
  eligible_property_types = ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
  income_limits = NULL,
  dti_limits = '{"front": 31, "back": 43}',
  credit_score_ranges = '[
    {"min": 580, "max": 850, "rate_adjustment": 0},
    {"min": 500, "max": 579, "rate_adjustment": 0.5}
  ]'::jsonb
WHERE type = 'FHA';

UPDATE loan_products SET
  eligible_property_types = ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
  income_limits = NULL,
  dti_limits = '{"front": 41, "back": 41}',
  credit_score_ranges = '[
    {"min": 580, "max": 850, "rate_adjustment": 0}
  ]'::jsonb
WHERE type = 'VA';

UPDATE loan_products SET
  eligible_property_types = ARRAY['Single Family'],
  income_limits = '{"percentage_ami": 115}',
  dti_limits = '{"front": 29, "back": 41}',
  credit_score_ranges = '[
    {"min": 640, "max": 850, "rate_adjustment": 0}
  ]'::jsonb
WHERE type = 'USDA';