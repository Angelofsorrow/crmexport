/*
  # Fix Documents Storage Configuration

  1. Changes
    - Create storage bucket for documents if it doesn't exist
    - Drop existing policies if they exist
    - Create new policies for file management
    - Enable RLS on storage.objects table

  2. Security
    - Enable row level security
    - Add policies for authenticated users to:
      - Upload files to their documents
      - Read document files
      - Delete their document files
*/

-- Create the storage bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('documents', 'documents', true)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Drop existing policies if they exist
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can upload documents" ON storage.objects;
  DROP POLICY IF EXISTS "Users can read documents" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete their documents" ON storage.objects;
END $$;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy to allow authenticated users to upload files
CREATE POLICY "Users can upload documents"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'documents' AND
  auth.uid() IS NOT NULL
);

-- Policy to allow authenticated users to read files
CREATE POLICY "Users can read documents"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'documents'
);

-- Policy to allow authenticated users to delete their files
CREATE POLICY "Users can delete their documents"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'documents' AND
  auth.uid() IS NOT NULL
);