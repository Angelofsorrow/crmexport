-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own contacts" ON contacts;
  DROP POLICY IF EXISTS "Users can manage contacts" ON contacts;
  DROP POLICY IF EXISTS "Default contact access" ON contacts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policy that allows public access for system operations
CREATE POLICY "Default contact access"
  ON contacts
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX IF NOT EXISTS idx_contacts_owner_id ON contacts(owner_id);
CREATE INDEX IF NOT EXISTS idx_contacts_company_id ON contacts(company_id);
CREATE INDEX IF NOT EXISTS idx_contacts_last_contacted ON contacts(last_contacted);

-- Create full text search index
CREATE INDEX IF NOT EXISTS idx_contacts_full_text ON contacts 
USING gin(
  to_tsvector('english',
    coalesce(first_name, '') || ' ' ||
    coalesce(last_name, '') || ' ' ||
    coalesce(email, '') || ' ' ||
    coalesce(phone, '') || ' ' ||
    coalesce(job_title, '') || ' ' ||
    coalesce(notes, '') || ' ' ||
    coalesce(agent_notes, '')
  )
);