-- Insert some test reviews
INSERT INTO reviews (
  contact_id,
  rating,
  content,
  status,
  is_published,
  submitted_at,
  owner_id
) 
SELECT 
  contacts.id,
  reviews.rating,
  reviews.content,
  reviews.status,
  reviews.is_published,
  reviews.submitted_at,
  contacts.owner_id
FROM (
  VALUES 
    (
      5,
      'Excellent service! The team was incredibly helpful throughout the entire process. They made getting a mortgage so much easier than I expected.',
      'approved',
      true,
      now() - interval '2 days'
    ),
    (
      4,
      'Very good experience overall. The process was smooth and the staff was knowledgeable. Would recommend to others looking for a mortgage.',
      'approved',
      true,
      now() - interval '5 days'
    ),
    (
      3,
      'Decent service but took longer than expected. Communication could have been better during the process.',
      'pending',
      false,
      now() - interval '1 day'
    ),
    (
      2,
      'Frustrated with the lengthy approval process and lack of clear updates. Expected better service.',
      'pending',
      false,
      now() - interval '3 days'
    ),
    (
      5,
      'Outstanding experience from start to finish! The team went above and beyond to help us secure our dream home.',
      'approved',
      true,
      now() - interval '7 days'
    )
) AS reviews(rating, content, status, is_published, submitted_at)
CROSS JOIN (
  SELECT id, owner_id 
  FROM contacts 
  ORDER BY created_at DESC 
  LIMIT 5
) AS contacts;

-- Add some review responses
INSERT INTO review_responses (
  review_id,
  content,
  is_public,
  owner_id
)
SELECT
  reviews.id,
  'Thank you for your feedback! We really appreciate you taking the time to share your experience.',
  true,
  reviews.owner_id
FROM reviews
WHERE status = 'approved'
AND rating >= 4;

INSERT INTO review_responses (
  review_id,
  content,
  is_public,
  owner_id
)
SELECT
  reviews.id,
  'We apologize for any inconvenience. A member of our team will reach out to discuss your concerns.',
  false,
  reviews.owner_id
FROM reviews
WHERE status = 'pending'
AND rating <= 3;