-- Create default user if it doesn't exist
DO $$
DECLARE
  default_user_id uuid := 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9';
  default_org_id uuid := 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9';
BEGIN
  -- First check if the user exists
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE id = default_user_id
  ) THEN
    -- Create the default user
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      role_id
    ) VALUES (
      default_user_id,
      '00000000-0000-0000-0000-000000000000'::uuid,
      'admin@example.com',
      crypt('admin123', gen_salt('bf')),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"name":"Admin User"}'::jsonb,
      true,
      (SELECT id FROM auth.roles WHERE name = 'authenticated' LIMIT 1)
    );

    -- Create default organization
    INSERT INTO organizations (id, name, slug, domain, owner_id)
    VALUES (
      default_org_id,
      'Default Organization',
      'default-org',
      'localhost',
      default_user_id
    );

    -- Create default whitelabel config
    INSERT INTO whitelabel_configs (
      organization_id,
      name,
      primary_color,
      secondary_color,
      accent_color,
      font_family,
      is_active
    ) VALUES (
      default_org_id,
      'Default Configuration',
      '#4F46E5',
      '#818CF8', 
      '#6366F1',
      'Inter',
      true
    );

    -- Create default organization member
    INSERT INTO organization_members (
      organization_id,
      user_id,
      role
    ) VALUES (
      default_org_id,
      default_user_id,
      'admin'
    );
  END IF;
END $$;