import { supabase } from './supabase';
import { sendSMS } from './twilio';
import { generateEmailResponse } from './openai';

interface CampaignContact {
  id: string;
  campaign_id: string;
  contact_id: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  current_step: number;
  started_at: string | null;
  completed_at: string | null;
}

interface CampaignStep {
  id: string;
  campaign_id: string;
  type: 'email' | 'sms' | 'voicemail';
  delay_hours: number;
  subject?: string;
  content: string;
  order_number: number;
}

interface Contact {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  company?: {
    name: string;
  };
}

class CampaignEngine {
  private checkInterval: number = 60000; // Check every minute
  private intervalId: NodeJS.Timeout | null = null;

  async start() {
    console.log('Starting campaign engine...');
    this.intervalId = setInterval(() => this.processQueue(), this.checkInterval);
    await this.processQueue(); // Run immediately on start
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    console.log('Campaign engine stopped');
  }

  private async processQueue() {
    try {
      // Get all active campaigns
      const { data: campaigns, error: campaignError } = await supabase
        .from('campaigns')
        .select('id')
        .eq('status', 'active');

      if (campaignError) throw campaignError;

      // Process each active campaign
      for (const campaign of campaigns || []) {
        await this.processCampaign(campaign.id);
      }
    } catch (error) {
      console.error('Error processing campaign queue:', error);
    }
  }

  private async processCampaign(campaignId: string) {
    try {
      // Get campaign contacts that need processing
      const { data: contacts, error: contactsError } = await supabase
        .from('campaign_contacts')
        .select(`
          *,
          contact:contacts(
            id,
            first_name,
            last_name,
            email,
            phone,
            company:companies(name)
          )
        `)
        .eq('campaign_id', campaignId)
        .in('status', ['pending', 'in_progress'])
        .order('created_at');

      if (contactsError) throw contactsError;

      // Get campaign steps
      const { data: steps, error: stepsError } = await supabase
        .from('campaign_steps')
        .select('*')
        .eq('campaign_id', campaignId)
        .order('order_number');

      if (stepsError) throw stepsError;

      // Process each contact
      for (const campaignContact of contacts || []) {
        await this.processContact(campaignContact, steps);
      }
    } catch (error) {
      console.error(`Error processing campaign ${campaignId}:`, error);
    }
  }

  private async processContact(
    campaignContact: CampaignContact & { contact: Contact },
    steps: CampaignStep[]
  ) {
    try {
      const currentStep = steps[campaignContact.current_step];
      if (!currentStep) {
        // No more steps, mark as completed
        await this.updateCampaignContact(campaignContact.id, {
          status: 'completed',
          completed_at: new Date().toISOString()
        });
        return;
      }

      // Check if it's time to execute the step
      const startedAt = new Date(campaignContact.started_at || campaignContact.created_at);
      const executeAt = new Date(startedAt.getTime() + (currentStep.delay_hours * 60 * 60 * 1000));
      
      if (new Date() >= executeAt) {
        // Execute the step
        await this.executeStep(currentStep, campaignContact.contact);

        // Update campaign contact
        const isLastStep = campaignContact.current_step === steps.length - 1;
        await this.updateCampaignContact(campaignContact.id, {
          current_step: campaignContact.current_step + 1,
          status: isLastStep ? 'completed' : 'in_progress',
          completed_at: isLastStep ? new Date().toISOString() : null
        });

        // Log activity
        await this.logActivity(campaignContact, currentStep);
      }
    } catch (error) {
      console.error(`Error processing contact ${campaignContact.id}:`, error);
      await this.updateCampaignContact(campaignContact.id, {
        status: 'failed'
      });
    }
  }

  private async executeStep(step: CampaignStep, contact: Contact) {
    switch (step.type) {
      case 'email':
        // In a real application, you would integrate with your email service here
        console.log('Sending email:', {
          to: contact.email,
          subject: step.subject,
          content: step.content
        });
        break;

      case 'sms':
        if (contact.phone) {
          await sendSMS(contact.phone, step.content);
        }
        break;

      case 'voicemail':
        if (contact.phone) {
          // In a real application, you would integrate with your voicemail service here
          console.log('Sending voicemail:', {
            to: contact.phone,
            content: step.content
          });
        }
        break;
    }
  }

  private async updateCampaignContact(id: string, updates: Partial<CampaignContact>) {
    const { error } = await supabase
      .from('campaign_contacts')
      .update(updates)
      .eq('id', id);

    if (error) throw error;
  }

  private async logActivity(
    campaignContact: CampaignContact & { contact: Contact },
    step: CampaignStep
  ) {
    const { error } = await supabase
      .from('activities')
      .insert([{
        type: step.type,
        title: `Campaign ${step.type} sent`,
        description: step.content,
        contact_id: campaignContact.contact.id,
        owner_id: null, // System-generated activity
        due_date: new Date().toISOString(),
        completed_at: new Date().toISOString()
      }]);

    if (error) throw error;
  }
}

// Create and export a singleton instance
export const campaignEngine = new CampaignEngine();