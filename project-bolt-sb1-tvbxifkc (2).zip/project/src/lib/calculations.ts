import Decimal from 'decimal.js';

export function calculateMonthlyPayment(
  loanAmount: number,
  annualInterestRate: number,
  termYears: number
): number {
  // Convert annual rate to monthly rate
  const monthlyRate = new Decimal(annualInterestRate).div(100).div(12);
  const numberOfPayments = new Decimal(termYears * 12);
  
  // Calculate monthly payment using the formula: P * (r(1+r)^n)/((1+r)^n-1)
  const payment = new Decimal(loanAmount).mul(
    monthlyRate.mul(
      (new Decimal(1).plus(monthlyRate)).pow(numberOfPayments)
    ).div(
      (new Decimal(1).plus(monthlyRate)).pow(numberOfPayments).minus(1)
    )
  );

  return payment.toDecimalPlaces(2).toNumber();
}

export function calculateLTV(loanAmount: number, propertyValue: number): number {
  return new Decimal(loanAmount)
    .div(propertyValue)
    .mul(100)
    .toDecimalPlaces(2)
    .toNumber();
}

export function calculateDTI(monthlyDebts: number, monthlyIncome: number): number {
  return new Decimal(monthlyDebts)
    .div(monthlyIncome)
    .mul(100)
    .toDecimalPlaces(2)
    .toNumber();
}

export function calculateFEDTI(
  monthlyMortgagePayment: number,
  monthlyIncome: number
): number {
  return new Decimal(monthlyMortgagePayment)
    .div(monthlyIncome)
    .mul(100)
    .toDecimalPlaces(2)
    .toNumber();
}

export function calculateRequiredReserves(
  monthlyPayment: number,
  loanType: string
): number {
  // Different loan types require different numbers of months in reserves
  const reserveMonths = {
    Conventional: 2,
    FHA: 1,
    VA: 0,
    USDA: 0,
    Jumbo: 6
  }[loanType] || 2;

  return new Decimal(monthlyPayment)
    .mul(reserveMonths)
    .toDecimalPlaces(2)
    .toNumber();
}

export function calculateAPR(
  loanAmount: number,
  annualInterestRate: number,
  termYears: number,
  closingCosts: number
): number {
  // Simple APR calculation including closing costs
  const totalInterest = new Decimal(calculateMonthlyPayment(loanAmount, annualInterestRate, termYears))
    .mul(termYears * 12)
    .minus(loanAmount);
  
  const apr = new Decimal(totalInterest.plus(closingCosts))
    .div(loanAmount)
    .div(termYears)
    .mul(100);

  return apr.toDecimalPlaces(3).toNumber();
}

export function amortizationSchedule(
  loanAmount: number,
  annualInterestRate: number,
  termYears: number
): Array<{
  paymentNumber: number;
  payment: number;
  principal: number;
  interest: number;
  remainingBalance: number;
}> {
  const monthlyRate = new Decimal(annualInterestRate).div(100).div(12);
  const numberOfPayments = termYears * 12;
  const monthlyPayment = calculateMonthlyPayment(loanAmount, annualInterestRate, termYears);
  const schedule = [];
  
  let balance = new Decimal(loanAmount);
  
  for (let i = 1; i <= numberOfPayments; i++) {
    const interestPayment = balance.mul(monthlyRate);
    const principalPayment = new Decimal(monthlyPayment).minus(interestPayment);
    balance = balance.minus(principalPayment);
    
    schedule.push({
      paymentNumber: i,
      payment: monthlyPayment,
      principal: principalPayment.toDecimalPlaces(2).toNumber(),
      interest: interestPayment.toDecimalPlaces(2).toNumber(),
      remainingBalance: balance.toDecimalPlaces(2).toNumber()
    });
  }
  
  return schedule;
}