import { supabase } from './supabase';
import { sendEmail } from './email';
import { openai } from './openai';
import type { Deal } from './types';

interface AutomationContext {
  deal: Deal;
  stage: {
    name: string;
    tasks: string[];
    automations: string[];
  };
  user: {
    id: string;
    email: string;
  };
}

export async function runStageAutomations(context: AutomationContext) {
  const { deal, stage, user } = context;

  // Get email account for notifications
  const { data: emailAccount } = await supabase
    .from('email_accounts')
    .select('*')
    .eq('owner_id', user.id)
    .eq('is_active', true)
    .single();

  // Run each automation in sequence
  for (const automation of stage.automations) {
    try {
      switch (automation) {
        // Email Automations
        case 'Send welcome email':
          await sendWelcomeEmail(deal, emailAccount);
          break;
        case 'Send qualification survey':
          await sendQualificationSurvey(deal, emailAccount);
          break;
        case 'Send feedback survey':
          await sendFeedbackSurvey(deal, emailAccount);
          break;
        case 'Send contract for review':
          await sendContractForReview(deal, emailAccount);
          break;
        case 'Send closing instructions':
          await sendClosingInstructions(deal, emailAccount);
          break;
        case 'Send funding confirmation':
          await sendFundingConfirmation(deal, emailAccount);
          break;
        case 'Generate welcome packet':
          await generateWelcomePacket(deal);
          break;
        case 'Generate adverse action letter':
          await generateAdverseActionLetter(deal);
          break;

        // Task Automations
        case 'Create follow-up task':
          await createFollowUpTask(deal, '2 days');
          break;
        case 'Schedule discovery call':
          await scheduleDiscoveryCall(deal);
          break;
        case 'Set internal review deadline':
          await setInternalReviewDeadline(deal);
          break;
        case 'Schedule negotiation call':
          await scheduleNegotiationCall(deal);
          break;
        case 'Schedule closing appointment':
          await scheduleClosingAppointment(deal);
          break;
        case 'Schedule follow-up in 6 months':
          await createFollowUpTask(deal, '6 months');
          break;

        // Document Automations
        case 'Generate proposal document':
          await generateProposalDocument(deal);
          break;
        case 'Generate contract draft':
          await generateContractDraft(deal);
          break;
        case 'Generate closing disclosure':
          await generateClosingDisclosure(deal);
          break;

        // Notification Automations
        case 'Notify implementation team':
          await notifyImplementationTeam(deal);
          break;
        case 'Alert legal team':
          await alertLegalTeam(deal);
          break;
        case 'Update loan status':
          await updateLoanStatus(deal);
          break;
        case 'Update forecasting':
          await updateForecasting(deal);
          break;

        // Integration Automations
        case 'LinkedIn connection request':
          await sendLinkedInRequest(deal);
          break;
        case 'Create evaluation account':
          await createEvaluationAccount(deal);
          break;
        case 'Set up servicing record':
          await setupServicingRecord(deal);
          break;
      }

      // Log successful automation
      await supabase.from('activities').insert([{
        type: 'automation',
        title: `Automation: ${automation}`,
        description: `Successfully ran automation for deal ${deal.title}`,
        deal_id: deal.id,
        completed_at: new Date().toISOString(),
        owner_id: user.id
      }]);

    } catch (error) {
      console.error(`Error running automation ${automation}:`, error);
      
      // Log failed automation
      await supabase.from('activities').insert([{
        type: 'automation',
        title: `Failed Automation: ${automation}`,
        description: `Failed to run automation for deal ${deal.title}: ${error.message}`,
        deal_id: deal.id,
        owner_id: user.id
      }]);
    }
  }
}

// Email Automation Functions
async function sendWelcomeEmail(deal: Deal, emailAccount: any) {
  const subject = `Welcome to ${deal.title}`;
  const body = await generateEmailContent('welcome', deal);
  
  await sendEmail(emailAccount, {
    to: [deal.contact?.email],
    subject,
    body
  });
}

async function sendQualificationSurvey(deal: Deal, emailAccount: any) {
  const subject = `Qualification Survey - ${deal.title}`;
  const surveyUrl = `https://example.com/survey/${deal.id}`;
  const body = `Please complete our qualification survey: ${surveyUrl}`;
  
  await sendEmail(emailAccount, {
    to: [deal.contact?.email],
    subject,
    body
  });
}

async function sendFeedbackSurvey(deal: Deal, emailAccount: any) {
  const subject = `We Value Your Feedback - ${deal.title}`;
  const surveyUrl = `https://example.com/feedback/${deal.id}`;
  const body = `Please share your feedback with us: ${surveyUrl}`;
  
  await sendEmail(emailAccount, {
    to: [deal.contact?.email],
    subject,
    body
  });
}

async function sendContractForReview(deal: Deal, emailAccount: any) {
  // Get latest contract document
  const { data: contract } = await supabase
    .from('documents')
    .select('*')
    .eq('deal_id', deal.id)
    .eq('type', 'contract')
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  const subject = `Contract Review - ${deal.title}`;
  const body = `Please review the attached contract for ${deal.title}`;
  
  await sendEmail(emailAccount, {
    to: [deal.contact?.email],
    subject,
    body,
    attachments: [{
      filename: contract.name,
      path: contract.file_path
    }]
  });
}

async function sendClosingInstructions(deal: Deal, emailAccount: any) {
  const subject = `Closing Instructions - ${deal.title}`;
  const body = await generateEmailContent('closing-instructions', deal);
  
  await sendEmail(emailAccount, {
    to: [deal.contact?.email],
    subject,
    body
  });
}

async function sendFundingConfirmation(deal: Deal, emailAccount: any) {
  const subject = `Funding Confirmation - ${deal.title}`;
  const body = await generateEmailContent('funding-confirmation', deal);
  
  await sendEmail(emailAccount, {
    to: [deal.contact?.email],
    subject,
    body
  });
}

// Task Automation Functions
async function createFollowUpTask(deal: Deal, delay: string) {
  const dueDate = new Date();
  if (delay === '6 months') {
    dueDate.setMonth(dueDate.getMonth() + 6);
  } else {
    dueDate.setDate(dueDate.getDate() + 2); // 2 days
  }

  await supabase.from('activities').insert([{
    type: 'task',
    title: `Follow up - ${deal.title}`,
    description: 'Schedule follow-up call to discuss next steps',
    due_date: dueDate.toISOString(),
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function scheduleDiscoveryCall(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'meeting',
    title: `Discovery Call - ${deal.title}`,
    description: 'Initial discovery call to understand requirements',
    due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 1 week
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function setInternalReviewDeadline(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'deadline',
    title: `Internal Review - ${deal.title}`,
    description: 'Complete internal review of proposal/contract',
    due_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function scheduleNegotiationCall(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'meeting',
    title: `Negotiation Call - ${deal.title}`,
    description: 'Discuss contract terms and negotiate final details',
    due_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function scheduleClosingAppointment(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'meeting',
    title: `Closing Appointment - ${deal.title}`,
    description: 'Final closing and document signing',
    due_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(), // 2 weeks
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

// Document Automation Functions
async function generateProposalDocument(deal: Deal) {
  const content = await generateDocumentContent('proposal', deal);
  
  await supabase.from('documents').insert([{
    name: `${deal.title} - Proposal.docx`,
    file_path: content.path,
    file_type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function generateContractDraft(deal: Deal) {
  const content = await generateDocumentContent('contract', deal);
  
  await supabase.from('documents').insert([{
    name: `${deal.title} - Contract.docx`,
    file_path: content.path,
    file_type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function generateClosingDisclosure(deal: Deal) {
  const content = await generateDocumentContent('closing-disclosure', deal);
  
  await supabase.from('documents').insert([{
    name: `${deal.title} - Closing Disclosure.pdf`,
    file_path: content.path,
    file_type: 'application/pdf',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function generateWelcomePacket(deal: Deal) {
  const content = await generateDocumentContent('welcome-packet', deal);
  
  await supabase.from('documents').insert([{
    name: `${deal.title} - Welcome Packet.pdf`,
    file_path: content.path,
    file_type: 'application/pdf',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function generateAdverseActionLetter(deal: Deal) {
  const content = await generateDocumentContent('adverse-action', deal);
  
  await supabase.from('documents').insert([{
    name: `${deal.title} - Adverse Action Notice.pdf`,
    file_path: content.path,
    file_type: 'application/pdf',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

// Notification Functions
async function notifyImplementationTeam(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'notification',
    title: `Implementation Required - ${deal.title}`,
    description: 'New deal ready for implementation setup',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function alertLegalTeam(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'notification',
    title: `Legal Review Required - ${deal.title}`,
    description: 'Contract needs legal team review',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function updateLoanStatus(deal: Deal) {
  await supabase
    .from('loan_applications')
    .update({ status: deal.status })
    .eq('deal_id', deal.id);
}

async function updateForecasting(deal: Deal) {
  // Update deal probability based on stage
  await supabase
    .from('deals')
    .update({ 
      probability: deal.stage.probability,
      forecast_amount: deal.amount * (deal.stage.probability / 100)
    })
    .eq('id', deal.id);
}

// Integration Functions
async function sendLinkedInRequest(deal: Deal) {
  // Log the intended action since we can't actually send LinkedIn requests
  await supabase.from('activities').insert([{
    type: 'social',
    title: `LinkedIn Connection - ${deal.title}`,
    description: 'LinkedIn connection request would be sent here',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function createEvaluationAccount(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'system',
    title: `Evaluation Account - ${deal.title}`,
    description: 'Created evaluation account for customer testing',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

async function setupServicingRecord(deal: Deal) {
  await supabase.from('activities').insert([{
    type: 'system',
    title: `Servicing Setup - ${deal.title}`,
    description: 'Created servicing record for funded loan',
    deal_id: deal.id,
    owner_id: deal.owner_id
  }]);
}

// Helper Functions
async function generateEmailContent(template: string, deal: Deal) {
  const prompt = `Generate a professional ${template} email for a mortgage deal with the following details:
    Deal: ${deal.title}
    Amount: ${deal.amount}
    Stage: ${deal.stage}
    Contact: ${deal.contact?.first_name} ${deal.contact?.last_name}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      { role: "system", content: "You are a professional mortgage loan officer writing an email." },
      { role: "user", content: prompt }
    ]
  });

  return completion.choices[0].message.content;
}

async function generateDocumentContent(template: string, deal: Deal) {
  // In a real implementation, this would use a document generation service
  // For now, we'll create a simple text file
  const content = `${template.toUpperCase()} for ${deal.title}
Generated on ${new Date().toISOString()}
Deal Amount: ${deal.amount}
Stage: ${deal.stage}
Contact: ${deal.contact?.first_name} ${deal.contact?.last_name}`;

  return {
    path: `/tmp/${deal.id}-${template}.txt`,
    content
  };
}