import { supabase } from './supabase';
import { runStageAutomations } from './automations';
import { openai } from './openai';

interface AutomationRequest {
  type: string;
  data?: any;
  eventDetails?: {
    title: string;
    startTime: string;
    endTime?: string;
    description?: string;
    location?: string;
    attendees?: Array<{
      email: string;
      name?: string;
    }>;
  };
}

export async function triggerAutomation(request: AutomationRequest) {
  try {
    // Get current session
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (sessionError) {
      console.error('Session error:', sessionError);
      throw new Error('Failed to get authentication session');
    }
    
    if (!session) {
      throw new Error('No authenticated session found');
    }

    // Validate request
    if (!request.type) {
      throw new Error('Automation type is required');
    }

    if (!request.data && !request.eventDetails) {
      throw new Error('Either data or eventDetails must be provided');
    }

    // For calendar events, validate eventDetails
    if (request.type === 'create_calendar_event') {
      if (!request.eventDetails) {
        throw new Error('Event details are required for calendar events');
      }
      
      const { title, startTime, attendees } = request.eventDetails;
      
      if (!title) {
        throw new Error('Event title is required');
      }
      if (!startTime) {
        throw new Error('Event start time is required');
      }
      
      // Validate dates
      const startDate = new Date(startTime);
      if (isNaN(startDate.getTime())) {
        throw new Error('Invalid start time format');
      }

      if (request.eventDetails.endTime) {
        const endDate = new Date(request.eventDetails.endTime);
        if (isNaN(endDate.getTime())) {
          throw new Error('Invalid end time format');
        }
        if (endDate < startDate) {
          throw new Error('End time cannot be before start time');
        }
      }

      // Ensure attendees is an array
      if (!attendees) {
        request.eventDetails.attendees = [];
      }

      try {
        // Create calendar event
        const { error: eventError } = await supabase
          .from('calendar_events')
          .insert([{
            title: request.eventDetails.title,
            description: request.eventDetails.description,
            start: request.eventDetails.startTime,
            end: request.eventDetails.endTime || request.eventDetails.startTime,
            location: request.eventDetails.location,
            source: 'ai_agent',
            owner_id: session.user.id,
            all_day: false,
            status: 'confirmed',
            attendees: request.eventDetails.attendees
          }]);

        if (eventError) {
          console.error('Error creating calendar event:', eventError);
          throw new Error('Failed to create calendar event');
        }

        // Create activity record
        const { error: activityError } = await supabase
          .from('activities')
          .insert([{
            type: 'calendar_event',
            title: request.eventDetails.title,
            description: request.eventDetails.description,
            due_date: request.eventDetails.startTime,
            owner_id: session.user.id,
            created_at: new Date().toISOString()
          }]);

        if (activityError) {
          console.error('Error creating activity record:', activityError);
          throw new Error('Failed to create activity record');
        }

        return new Response(JSON.stringify({ success: true }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      } catch (error) {
        console.error('Error in calendar event creation:', error);
        throw error;
      }
    }

    // Send request to AI agent through Vite proxy
    const response = await fetch('/api/process', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({
        type: request.type,
        data: request.data,
        eventDetails: request.eventDetails,
        user: {
          id: session.user.id,
          email: session.user.email
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorMessage = 'Failed to trigger automation';
      
      try {
        const errorJson = JSON.parse(errorText);
        errorMessage = errorJson.error || errorJson.message || errorMessage;
      } catch (e) {
        errorMessage = errorText || errorMessage;
      }
      
      throw new Error(errorMessage);
    }

    return response;
  } catch (error) {
    console.error('Error in triggerAutomation:', error);
    throw error;
  }
}

export async function checkAgentHealth() {
  try {
    const response = await fetch('/api/health');
    if (!response.ok) {
      throw new Error(`Health check failed: ${response.statusText}`);
    }
    return true;
  } catch (error) {
    console.error('Error checking agent health:', error);
    return false;
  }
}

export async function handleCRMAction(action: string, data: any, user: any) {
  try {
    // Validate input parameters
    if (!action) {
      throw new Error('Action type is required');
    }

    if (!user?.id) {
      throw new Error('User information is required');
    }

    // Route to appropriate handler
    switch (action) {
      case 'create_calendar_event':
        return await createCalendarEvent(data.eventDetails || data, user);
      case 'send_email':
        return await sendEmailToContact(data, user);
      case 'create_task':
        return await createTask(data, user);
      case 'create_note':
        return await createNote(data, user);
      case 'research_contact':
        return await researchContact(data, user);
      default:
        throw new Error(`Unknown action type: ${action}`);
    }
  } catch (error) {
    console.error('Error in handleCRMAction:', error);
    throw error;
  }
}

async function createCalendarEvent(eventDetails: any, user: any) {
  try {
    // Create calendar event
    const { error: eventError } = await supabase
      .from('calendar_events')
      .insert([{
        title: eventDetails.title,
        description: eventDetails.description,
        start: eventDetails.startTime,
        end: eventDetails.endTime || eventDetails.startTime,
        location: eventDetails.location,
        source: 'ai_agent',
        owner_id: user.id,
        all_day: false,
        status: 'confirmed',
        attendees: eventDetails.attendees || []
      }]);

    if (eventError) {
      console.error('Error creating calendar event:', eventError);
      throw new Error('Failed to create calendar event');
    }

    // Create activity record
    const { error: activityError } = await supabase
      .from('activities')
      .insert([{
        type: 'calendar_event',
        title: eventDetails.title,
        description: eventDetails.description,
        due_date: eventDetails.startTime,
        owner_id: user.id,
        created_at: new Date().toISOString()
      }]);

    if (activityError) {
      console.error('Error creating activity record:', activityError);
      throw new Error('Failed to create activity record');
    }

    return { success: true, message: 'Calendar event created successfully' };
  } catch (error) {
    console.error('Error in createCalendarEvent:', error);
    throw error;
  }
}

async function sendEmailToContact(data: any, user: any) {
  try {
    const { to, subject, content } = data;
    if (!to || !subject || !content) {
      throw new Error('Missing required email fields');
    }

    // Get user's email account
    const { data: emailAccount } = await supabase
      .from('email_accounts')
      .select('*')
      .eq('owner_id', user.id)
      .eq('is_active', true)
      .single();

    // If no user email account, try to use their auth email
    if (!emailAccount) {
      // Create email account using user's auth email
      const { error: createError } = await supabase
        .from('email_accounts')
        .insert([{
          email: user.email,
          display_name: user.email.split('@')[0],
          imap_host: 'localhost', // Default values for now
          imap_port: 993,
          smtp_host: 'localhost',
          smtp_port: 587,
          username: user.email,
          password: 'default-password', // This should be properly handled in production
          is_active: true,
          owner_id: user.id,
          provider: 'system'
        }]);

      if (createError) throw createError;
    }

    // Create activity record
    const { error: activityError } = await supabase
      .from('activities')
      .insert([{
        type: 'email',
        title: `Email: ${subject}`,
        description: content,
        owner_id: user.id,
        completed_at: new Date().toISOString()
      }]);

    if (activityError) throw activityError;

    return { success: true, message: 'Email sent successfully' };
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
}

async function createTask(data: any, user: any) {
  try {
    // Validate required fields
    if (!data.title) {
      throw new Error('Task title is required');
    }
    if (!data.due_date) {
      throw new Error('Task due date is required');
    }

    // Validate due date format
    const dueDate = new Date(data.due_date);
    if (isNaN(dueDate.getTime())) {
      throw new Error('Invalid due date format');
    }

    // Create task record
    const { error } = await supabase
      .from('activities')
      .insert([{
        type: 'task',
        title: data.title,
        description: data.description,
        due_date: data.due_date,
        contact_id: data.contact_id || null,
        deal_id: data.deal_id || null,
        owner_id: user.id
      }]);

    if (error) throw error;

    return { success: true, message: 'Task created successfully' };
  } catch (error) {
    console.error('Error creating task:', error);
    throw error;
  }
}

async function createNote(data: any, user: any) {
  try {
    const { title, content, contact_id, deal_id } = data;
    if (!title || !content) {
      throw new Error('Missing required note fields');
    }

    const { error } = await supabase
      .from('activities')
      .insert([{
        type: 'note',
        title,
        description: content,
        contact_id: contact_id || null,
        deal_id: deal_id || null,
        owner_id: user.id,
        completed_at: new Date().toISOString()
      }]);

    if (error) throw error;

    return { success: true, message: 'Note created successfully' };
  } catch (error) {
    console.error('Error creating note:', error);
    throw error;
  }
}

async function researchContact(data: any, user: any) {
  try {
    const { contact_id, email } = data;
    if (!contact_id && !email) {
      throw new Error('Either contact_id or email is required');
    }

    // Create activity to track research request
    const { error: activityError } = await supabase
      .from('activities')
      .insert([{
        type: 'research',
        title: 'Contact Research Requested',
        description: 'AI assistant is researching contact information',
        contact_id: contact_id || null,
        owner_id: user.id,
        created_at: new Date().toISOString()
      }]);

    if (activityError) throw activityError;

    // In a real implementation, this would integrate with external APIs
    // For now, we'll just return a success message
    return { 
      success: true, 
      message: 'Contact research initiated',
      data: {
        status: 'pending',
        message: 'Research request received and being processed'
      }
    };
  } catch (error) {
    console.error('Error researching contact:', error);
    throw error;
  }
}