import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { getOpenAIInstance } from './openai';
import * as pdfjsLib from 'pdfjs-dist';
import * as mammoth from 'mammoth';

interface ParsedDocument {
  content: string;
  type: string;
  name: string;
}

export async function parseDocument(file: File): Promise<ParsedDocument> {
  const fileType = file.name.split('.').pop()?.toLowerCase();
  let content = '';

  try {
    if (fileType === 'csv') {
      const text = await file.text();
      const result = Papa.parse(text, { header: true });
      content = result.data.map(row => Object.values(row).join(' ')).join('\n');
    } else if (fileType === 'xlsx' || fileType === 'xls') {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(worksheet);
      content = data.map(row => Object.values(row).join(' ')).join('\n');
    } else if (fileType === 'txt' || fileType === 'md') {
      content = await file.text();
    } else if (fileType === 'docx') {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.extractRawText({ arrayBuffer });
      content = result.value;
    } else if (fileType === 'pdf') {
      // Use pdf.js instead of pdf-parse for browser environment
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const maxPages = pdf.numPages;
      const textContent = [];
      
      for (let pageNum = 1; pageNum <= maxPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const text = await page.getTextContent();
        const pageText = text.items
          .map((item: any) => item.str)
          .join(' ');
        textContent.push(pageText);
      }
      
      content = textContent.join('\n');
    } else {
      throw new Error('Unsupported file type. Please use CSV, Excel, Word, PDF, TXT, or MD files.');
    }

    // Clean up the content
    content = content
      .replace(/\s+/g, ' ')  // Replace multiple spaces with single space
      .replace(/[^\x20-\x7E\n]/g, '') // Remove non-printable characters
      .trim();

    return {
      content,
      type: fileType || 'txt',
      name: file.name
    };
  } catch (error) {
    console.error('Error parsing document:', error);
    throw new Error(`Failed to parse ${fileType?.toUpperCase()} file: ${error.message}`);
  }
}

export async function generateCampaignSteps(content: string): Promise<Array<{
  type: 'email' | 'sms';
  subject?: string;
  content: string;
  delay_hours: number;
}>> {
  try {
    const openai = await getOpenAIInstance();
    if (!openai) {
      throw new Error('OpenAI not configured');
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are an expert at creating email and SMS marketing campaigns. 
          Analyze the provided content and create a sequence of messages that form an effective campaign.
          Focus on key points and create a natural progression of messages.
          For emails, include engaging subject lines.
          For SMS, keep messages concise (under 160 characters).
          Add appropriate delays between messages.
          
          Guidelines:
          - Start with a welcome email
          - Mix email and SMS for better engagement
          - Space messages appropriately (24-72 hours apart)
          - Include clear calls to action
          - Personalize messages with placeholders
          - End with a strong follow-up`
        },
        {
          role: "user",
          content: `Create a campaign sequence from this content: ${content}`
        }
      ],
      functions: [
        {
          name: "createCampaignSteps",
          description: "Create a sequence of email and SMS messages for a campaign",
          parameters: {
            type: "object",
            properties: {
              steps: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    type: {
                      type: "string",
                      enum: ["email", "sms"]
                    },
                    subject: {
                      type: "string",
                      description: "Subject line for email messages"
                    },
                    content: {
                      type: "string",
                      description: "Message content"
                    },
                    delay_hours: {
                      type: "number",
                      description: "Delay in hours before sending this message"
                    }
                  },
                  required: ["type", "content", "delay_hours"]
                }
              }
            },
            required: ["steps"]
          }
        }
      ],
      function_call: { name: "createCampaignSteps" }
    });

    const result = completion.choices[0].message.function_call?.arguments;
    if (!result) throw new Error('Failed to generate campaign steps');

    return JSON.parse(result).steps;
  } catch (error) {
    console.error('Error generating campaign steps:', error);
    throw error;
  }
}