import { supabase } from './supabase';

interface EmailAccount {
  id: string;
  email: string;
  display_name: string;
  imap_host: string;
  imap_port: number;
  smtp_host: string;
  smtp_port: number;
  username: string;
  password: string;
}

const API_URL = 'http://localhost:3000/api';

export async function sendEmail(
  account: EmailAccount,
  { to, cc, bcc, subject, body, attachments }: {
    to: string[];
    cc?: string[];
    bcc?: string[];
    subject: string;
    body: string;
    attachments?: Array<{ filename: string; path: string; contentType: string }>;
  }
) {
  const response = await fetch(`${API_URL}/email/send`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      account,
      to,
      cc,
      bcc,
      subject,
      body,
      attachments,
    }),
  });

  if (!response.ok) {
    throw new Error('Failed to send email');
  }

  const result = await response.json();

  // Store sent message in database
  await supabase.from('messages').insert([{
    type: 'email',
    direction: 'outbound',
    status: 'sent',
    subject,
    body,
    from_email: account.email,
    from_name: account.display_name,
    to_email: to,
    cc_email: cc,
    bcc_email: bcc,
    sent_at: new Date().toISOString(),
    email_account_id: account.id,
  }]);

  return result;
}

export async function syncEmails(account: EmailAccount) {
  const response = await fetch(`${API_URL}/email/sync`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ account }),
  });

  if (!response.ok) {
    throw new Error('Failed to sync emails');
  }

  return response.json();
}