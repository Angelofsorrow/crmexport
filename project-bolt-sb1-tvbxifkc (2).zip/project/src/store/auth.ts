import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';
import type { Organization, WhitelabelConfig } from '../lib/types';

interface AuthState {
  user: User | null;
  loading: boolean;
  organization: Organization | null;
  whitelabelConfig: WhitelabelConfig | null;
  setUser: (user: User | null) => void;
  setOrganization: (org: Organization | null) => void;
  setWhitelabelConfig: (config: WhitelabelConfig | null) => void;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  loadOrganization: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  loading: true,
  organization: null,
  whitelabelConfig: null,
  setUser: (user) => {
    set({ user, loading: false });
    if (user) {
      get().loadOrganization();
    }
  },
  setOrganization: (organization) => set({ organization }),
  setWhitelabelConfig: (whitelabelConfig) => set({ whitelabelConfig }),
  
  signIn: async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
        options: {
          redirectTo: window.location.origin
        }
      });

      if (error) throw error;

      if (data?.user) {
        set({ user: data.user });
        await get().loadOrganization();
      }
    } catch (error: any) {
      console.error('Sign in error:', error);
      throw new Error(error.message || 'Failed to sign in');
    }
  },

  signUp: async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin
        }
      });

      if (error) throw error;

      if (data?.user) {
        set({ user: data.user });
      }
    } catch (error: any) {
      console.error('Sign up error:', error);
      throw new Error(error.message || 'Failed to sign up');
    }
  },

  signOut: async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      set({ user: null, organization: null, whitelabelConfig: null });
    } catch (error: any) {
      console.error('Sign out error:', error);
      throw new Error(error.message || 'Failed to sign out');
    }
  },

  loadOrganization: async () => {
    try {
      const userId = get().user?.id;
      if (!userId) {
        console.error('User ID is not available');
        return;
      }

      // First try to get user's organization membership
      const { data: memberData, error: memberError } = await supabase
        .from('organization_members')
        .select('organization_id')
        .eq('user_id', userId)
        .maybeSingle();

      if (memberError && memberError.code !== 'PGRST116') {
        console.error('Error loading organization membership:', memberError);
        return;
      }

      // If no membership found, use default organization
      const organizationId = memberData?.organization_id || 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9';

      // Load organization details
      const { data: orgData, error: orgError } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', organizationId)
        .single();

      if (orgError) {
        console.error('Error loading organization:', orgError);
        return;
      }

      set({ organization: orgData });

      // Load whitelabel config
      const { data: configData, error: configError } = await supabase
        .from('whitelabel_configs')
        .select('*')
        .eq('organization_id', orgData.id)
        .eq('is_active', true)
        .single();

      if (configError && configError.code !== 'PGRST116') {
        console.error('Error loading whitelabel config:', configError);
        return;
      }

      set({ whitelabelConfig: configData });
    } catch (error) {
      console.error('Error loading organization:', error);
    }
  }
}));