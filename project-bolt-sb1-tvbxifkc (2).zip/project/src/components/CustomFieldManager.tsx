import React, { useState } from 'react';
import { Plus, X, ChevronUp, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { CustomField } from '../lib/types';

interface CustomFieldManagerProps {
  entityType: 'contact' | 'deal' | 'company';
  onClose: () => void;
  onFieldsChange: () => void;
}

const FIELD_TYPES = [
  { value: 'text', label: 'Text' },
  { value: 'number', label: 'Number' },
  { value: 'date', label: 'Date' },
  { value: 'select', label: 'Select' },
  { value: 'multiselect', label: 'Multi-Select' },
  { value: 'checkbox', label: 'Checkbox' },
  { value: 'textarea', label: 'Text Area' },
  { value: 'url', label: 'URL' },
  { value: 'email', label: 'Email' },
  { value: 'phone', label: 'Phone' }
];

export default function CustomFieldManager({ entityType, onClose, onFieldsChange }: CustomFieldManagerProps) {
  const [fields, setFields] = useState<CustomField[]>([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    label: '',
    type: 'text',
    options: '',
    default_value: '',
    is_required: false,
    is_searchable: false
  });

  React.useEffect(() => {
    fetchFields();
  }, []);

  async function fetchFields() {
    try {
      const { data, error } = await supabase
        .from('custom_fields')
        .select('*')
        .eq('entity_type', entityType)
        .order('display_order');

      if (error) throw error;
      setFields(data || []);
    } catch (error) {
      console.error('Error fetching custom fields:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    try {
      const fieldData = {
        ...formData,
        entity_type: entityType,
        options: formData.type === 'select' || formData.type === 'multiselect'
          ? formData.options.split(',').map(o => o.trim())
          : null,
        display_order: fields.length + 1
      };

      const { error } = await supabase
        .from('custom_fields')
        .insert([fieldData]);

      if (error) throw error;

      fetchFields();
      onFieldsChange();
      setFormData({
        name: '',
        label: '',
        type: 'text',
        options: '',
        default_value: '',
        is_required: false,
        is_searchable: false
      });
    } catch (error) {
      console.error('Error creating custom field:', error);
    }
  }

  async function handleDeleteField(id: string) {
    if (!window.confirm('Are you sure you want to delete this field? All values will be lost.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('custom_fields')
        .delete()
        .eq('id', id);

      if (error) throw error;

      fetchFields();
      onFieldsChange();
    } catch (error) {
      console.error('Error deleting custom field:', error);
    }
  }

  async function handleReorderField(id: string, direction: 'up' | 'down') {
    const currentIndex = fields.findIndex(f => f.id === id);
    if (currentIndex === -1) return;

    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (newIndex < 0 || newIndex >= fields.length) return;

    const newFields = [...fields];
    const temp = newFields[currentIndex];
    newFields[currentIndex] = newFields[newIndex];
    newFields[newIndex] = temp;

    try {
      await Promise.all([
        supabase
          .from('custom_fields')
          .update({ display_order: newIndex + 1 })
          .eq('id', temp.id),
        supabase
          .from('custom_fields')
          .update({ display_order: currentIndex + 1 })
          .eq('id', newFields[currentIndex].id)
      ]);

      setFields(newFields);
    } catch (error) {
      console.error('Error reordering fields:', error);
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg w-full max-w-2xl my-8">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Manage Custom Fields</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <form onSubmit={handleSubmit} className="mb-8">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Field Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="e.g., linkedin_url"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Display Label</label>
                <input
                  type="text"
                  value={formData.label}
                  onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="e.g., LinkedIn URL"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Field Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  {FIELD_TYPES.map(type => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Default Value</label>
                <input
                  type="text"
                  value={formData.default_value}
                  onChange={(e) => setFormData({ ...formData, default_value: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              {(formData.type === 'select' || formData.type === 'multiselect') && (
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700">Options (comma-separated)</label>
                  <input
                    type="text"
                    value={formData.options}
                    onChange={(e) => setFormData({ ...formData, options: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="Option 1, Option 2, Option 3"
                    required
                  />
                </div>
              )}
              <div className="col-span-2 flex items-center gap-6">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.is_required}
                    onChange={(e) => setFormData({ ...formData, is_required: e.target.checked })}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm text-gray-700">Required field</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.is_searchable}
                    onChange={(e) => setFormData({ ...formData, is_searchable: e.target.checked })}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm text-gray-700">Searchable</span>
                </label>
              </div>
            </div>
            <div className="mt-4">
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Field
              </button>
            </div>
          </form>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Existing Fields</h3>
            {loading ? (
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              </div>
            ) : (
              <div className="space-y-2">
                {fields.map((field, index) => (
                  <div
                    key={field.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <div className="font-medium">{field.label}</div>
                      <div className="text-sm text-gray-500">
                        {field.name} • {FIELD_TYPES.find(t => t.value === field.type)?.label}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleReorderField(field.id!, 'up')}
                        disabled={index === 0}
                        className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
                      >
                        <ChevronUp className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleReorderField(field.id!, 'down')}
                        disabled={index === fields.length - 1}
                        className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
                      >
                        <ChevronDown className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteField(field.id!)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}