import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { Mail, Phone, Building2, Calendar, FileText, MessageSquare, Star, X, Edit2, Trash2, ChevronDown, ChevronUp, Clock, CheckCircle2, Send } from 'lucide-react';
import CommunicationModal from './CommunicationModal';
import CustomFieldManager from './CustomFieldManager';
import TagManager from './TagManager';

interface ContactProfileProps {
  contact: {
    id: string;
    first_name: string;
    last_name: string;
    email?: string;
    phone?: string;
    job_title?: string;
    company?: {
      name: string;
    };
    last_contacted?: string;
    custom_fields?: Record<string, any>;
    tags?: string[];
  };
  onClose: () => void;
  onUpdate: () => void;
}

interface Activity {
  id: string;
  type: string;
  title: string;
  description: string;
  due_date?: string;
  completed_at?: string;
  created_at: string;
}

interface Message {
  id: string;
  type: 'email' | 'text' | 'call';
  direction: 'inbound' | 'outbound';
  subject?: string;
  body: string;
  from_email?: string;
  from_name?: string;
  from_phone?: string;
  to_email?: string[];
  to_phone?: string;
  sent_at?: string;
  received_at: string;
}

export default function ContactProfile({ contact, onClose, onUpdate }: ContactProfileProps) {
  const [showCommunicationModal, setShowCommunicationModal] = useState(false);
  const [showCustomFieldManager, setShowCustomFieldManager] = useState(false);
  const [showTagManager, setShowTagManager] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'activity' | 'messages'>('overview');
  const [expandedMessage, setExpandedMessage] = useState<string | null>(null);

  useEffect(() => {
    fetchActivities();
    fetchMessages();
  }, [contact.id]);

  async function fetchActivities() {
    try {
      const { data, error } = await supabase
        .from('activities')
        .select('*')
        .eq('contact_id', contact.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    }
  }

  async function fetchMessages() {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('contact_id', contact.id)
        .order('received_at', { ascending: false });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  }

  async function handleDelete() {
    if (!window.confirm('Are you sure you want to delete this contact?')) {
      return;
    }

    try {
      setLoading(true);
      const { error } = await supabase
        .from('contacts')
        .delete()
        .eq('id', contact.id);

      if (error) throw error;
      onClose();
      onUpdate();
    } catch (error) {
      console.error('Error deleting contact:', error);
    } finally {
      setLoading(false);
    }
  }

  function getActivityIcon(type: string) {
    switch (type) {
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'call':
        return <Phone className="h-4 w-4" />;
      case 'meeting':
        return <Calendar className="h-4 w-4" />;
      case 'task':
        return <CheckCircle2 className="h-4 w-4" />;
      case 'note':
        return <FileText className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  }

  function getMessageIcon(type: string, direction: string) {
    switch (type) {
      case 'email':
        return <Mail className={`h-4 w-4 ${direction === 'outbound' ? 'text-blue-500' : 'text-gray-500'}`} />;
      case 'text':
        return <MessageSquare className={`h-4 w-4 ${direction === 'outbound' ? 'text-green-500' : 'text-gray-500'}`} />;
      case 'call':
        return <Phone className={`h-4 w-4 ${direction === 'outbound' ? 'text-purple-500' : 'text-gray-500'}`} />;
      default:
        return <Send className="h-4 w-4 text-gray-500" />;
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg w-full max-w-4xl my-8">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {contact.first_name} {contact.last_name}
              </h2>
              {contact.job_title && (
                <p className="mt-1 text-sm text-gray-500">{contact.job_title}</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowTagManager(true)}
                className="p-2 text-gray-400 hover:text-gray-600"
                title="Manage tags"
              >
                <Star className="h-5 w-5" />
              </button>
              <button
                onClick={() => setShowCustomFieldManager(true)}
                className="p-2 text-gray-400 hover:text-gray-600"
                title="Manage custom fields"
              >
                <Edit2 className="h-5 w-5" />
              </button>
              <button
                onClick={handleDelete}
                className="p-2 text-red-400 hover:text-red-600"
                title="Delete contact"
                disabled={loading}
              >
                <Trash2 className="h-5 w-5" />
              </button>
              <button
                onClick={onClose}
                className="p-2 text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex space-x-4 mt-6">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-2 text-sm font-medium rounded-md ${
                activeTab === 'overview'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('activity')}
              className={`px-3 py-2 text-sm font-medium rounded-md ${
                activeTab === 'activity'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Activity
            </button>
            <button
              onClick={() => setActiveTab('messages')}
              className={`px-3 py-2 text-sm font-medium rounded-md ${
                activeTab === 'messages'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Messages
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="space-y-2">
                {contact.email && (
                  <div className="flex items-center text-sm">
                    <Mail className="h-4 w-4 text-gray-400 mr-2" />
                    <button
                      onClick={() => setShowCommunicationModal(true)}
                      className="text-gray-900 hover:text-indigo-600"
                    >
                      {contact.email}
                    </button>
                  </div>
                )}
                {contact.phone && (
                  <div className="flex items-center text-sm">
                    <Phone className="h-4 w-4 text-gray-400 mr-2" />
                    <button
                      onClick={() => setShowCommunicationModal(true)}
                      className="text-gray-900 hover:text-indigo-600"
                    >
                      {contact.phone}
                    </button>
                  </div>
                )}
                {contact.company?.name && (
                  <div className="flex items-center text-sm">
                    <Building2 className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-gray-900">{contact.company.name}</span>
                  </div>
                )}
                {contact.last_contacted && (
                  <div className="flex items-center text-sm">
                    <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-gray-500">
                      Last contacted: {format(new Date(contact.last_contacted), 'MMM d, yyyy')}
                    </span>
                  </div>
                )}
              </div>

              {/* Custom Fields */}
              {contact.custom_fields && Object.keys(contact.custom_fields).length > 0 && (
                <div className="border-t pt-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Additional Information</h3>
                  <div className="space-y-2">
                    {Object.entries(contact.custom_fields).map(([field, value]) => (
                      <div key={field} className="flex items-start text-sm">
                        <span className="text-gray-500 min-w-[120px]">{field}:</span>
                        <span className="text-gray-900">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tags */}
              {contact.tags && contact.tags.length > 0 && (
                <div className="border-t pt-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {contact.tags.map(tag => (
                      <span
                        key={tag}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Recent Activity */}
              <div className="border-t pt-4">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {activities.slice(0, 5).map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className="flex-shrink-0 mt-1">
                        {getActivityIcon(activity.type)}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                        <p className="text-sm text-gray-500">{activity.description}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {format(new Date(activity.created_at), 'MMM d, yyyy h:mm a')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Messages */}
              <div className="border-t pt-4">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Recent Messages</h3>
                <div className="space-y-4">
                  {messages.slice(0, 5).map((message) => (
                    <div key={message.id} className="flex items-start gap-3">
                      <div className="flex-shrink-0 mt-1">
                        {getMessageIcon(message.type, message.direction)}
                      </div>
                      <div>
                        {message.subject && (
                          <p className="text-sm font-medium text-gray-900">{message.subject}</p>
                        )}
                        <p className="text-sm text-gray-500 line-clamp-2">{message.body}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {format(new Date(message.received_at), 'MMM d, yyyy h:mm a')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'activity' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Activity History</h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowCommunicationModal(true)}
                    className="px-3 py-1 text-sm text-indigo-600 bg-indigo-50 rounded-md hover:bg-indigo-100"
                  >
                    Log Activity
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {activities.map((activity) => (
                  <div key={activity.id} className="bg-white rounded-lg border p-4">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 mt-1">
                        {getActivityIcon(activity.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                          <p className="text-xs text-gray-400">
                            {format(new Date(activity.created_at), 'MMM d, yyyy h:mm a')}
                          </p>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">{activity.description}</p>
                        {activity.due_date && (
                          <p className="text-xs text-gray-400 mt-2">
                            Due: {format(new Date(activity.due_date), 'MMM d, yyyy')}
                          </p>
                        )}
                        {activity.completed_at && (
                          <p className="text-xs text-green-500 mt-2">
                            Completed: {format(new Date(activity.completed_at), 'MMM d, yyyy')}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'messages' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Message History</h3>
                <button
                  onClick={() => setShowCommunicationModal(true)}
                  className="px-3 py-1 text-sm text-indigo-600 bg-indigo-50 rounded-md hover:bg-indigo-100"
                >
                  Send Message
                </button>
              </div>

              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className="bg-white rounded-lg border p-4">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 mt-1">
                        {getMessageIcon(message.type, message.direction)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {message.direction === 'inbound' ? 'From: ' : 'To: '}
                              {message.direction === 'inbound' 
                                ? (message.from_name || message.from_email || message.from_phone)
                                : (message.to_email?.join(', ') || message.to_phone)
                              }
                            </p>
                            {message.subject && (
                              <p className="text-sm text-gray-700 mt-1">{message.subject}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <p className="text-xs text-gray-400">
                              {format(new Date(message.sent_at || message.received_at), 'MMM d, yyyy h:mm a')}
                            </p>
                            <button
                              onClick={() => setExpandedMessage(
                                expandedMessage === message.id ? null : message.id
                              )}
                              className="text-gray-400 hover:text-gray-600"
                            >
                              {expandedMessage === message.id ? (
                                <ChevronUp className="h-4 w-4" />
                              ) : (
                                <ChevronDown className="h-4 w-4" />
                              )}
                            </button>
                          </div>
                        </div>
                        <div className={`mt-2 text-sm text-gray-500 ${
                          expandedMessage === message.id ? '' : 'line-clamp-2'
                        }`}>
                          {message.body}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="mt-6 flex justify-end gap-3">
            <button
              onClick={() => setShowCommunicationModal(true)}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 flex items-center gap-2"
            >
              <MessageSquare className="h-4 w-4" />
              Send Message
            </button>
          </div>
        </div>
      </div>

      {/* Communication Modal */}
      {showCommunicationModal && (
        <CommunicationModal
          isOpen={showCommunicationModal}
          onClose={() => setShowCommunicationModal(false)}
          contact={contact}
        />
      )}

      {/* Custom Field Manager */}
      {showCustomFieldManager && (
        <CustomFieldManager
          entityType="contact"
          onClose={() => setShowCustomFieldManager(false)}
          onFieldsChange={onUpdate}
        />
      )}

      {/* Tag Manager */}
      {showTagManager && (
        <TagManager
          entityType="contact"
          onClose={() => setShowTagManager(false)}
          onTagsChange={onUpdate}
        />
      )}
    </div>
  );
}