import React, { useState } from 'react';
import { Upload, X, Loader2, FileText } from 'lucide-react';
import { parseDocument, generateCampaignSteps } from '../lib/documentParser';
import { supabase } from '../lib/supabase';

interface DocumentCampaignBuilderProps {
  onClose: () => void;
  onCampaignCreated: () => void;
}

export default function DocumentCampaignBuilder({ onClose, onCampaignCreated }: DocumentCampaignBuilderProps) {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [campaignName, setCampaignName] = useState('');
  const [progress, setProgress] = useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  async function handleFileSelect(event: React.ChangeEvent<HTMLInputElement>) {
    const selectedFile = event.target.files?.[0];
    if (!selectedFile) return;
    setFile(selectedFile);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !campaignName) return;

    setLoading(true);
    setError(null);

    try {
      // Parse the document
      setProgress('Parsing document...');
      const parsedDoc = await parseDocument(file);

      // Generate campaign steps
      setProgress('Generating campaign steps...');
      const steps = await generateCampaignSteps(parsedDoc.content);

      // Create campaign
      setProgress('Creating campaign...');
      const { data: campaign, error: campaignError } = await supabase
        .from('campaigns')
        .insert([{
          name: campaignName,
          description: `Generated from ${file.name}`,
          status: 'draft'
        }])
        .select()
        .single();

      if (campaignError) throw campaignError;

      // Create campaign steps
      setProgress('Adding campaign steps...');
      const { error: stepsError } = await supabase
        .from('campaign_steps')
        .insert(
          steps.map((step, index) => ({
            campaign_id: campaign.id,
            type: step.type,
            delay_hours: step.delay_hours,
            subject: step.subject,
            content: step.content,
            order_number: index + 1
          }))
        );

      if (stepsError) throw stepsError;

      onCampaignCreated();
      onClose();
    } catch (error) {
      console.error('Error creating campaign:', error);
      setError(error.message);
    } finally {
      setLoading(false);
      setProgress(null);
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Create Campaign from Document</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Campaign Name</label>
            <input
              type="text"
              value={campaignName}
              onChange={(e) => setCampaignName(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              accept=".csv,.xlsx,.xls,.txt,.md,.docx,.pdf"
              className="hidden"
            />
            
            {file ? (
              <div className="p-4 border-2 border-indigo-200 rounded-lg">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-indigo-600" />
                  <span className="flex-1 truncate">{file.name}</span>
                  <button
                    type="button"
                    onClick={() => setFile(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full p-4 border-2 border-gray-300 border-dashed rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 flex items-center justify-center gap-2"
              >
                <Upload className="h-5 w-5" />
                Upload Document
              </button>
            )}
            <p className="mt-2 text-sm text-gray-500">
              Supported formats: CSV, Excel, Word, PDF, TXT, MD
            </p>
          </div>

          {progress && (
            <div className="p-4 bg-indigo-50 text-indigo-700 rounded-lg text-sm flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              {progress}
            </div>
          )}

          {error && (
            <div className="p-4 bg-red-50 text-red-700 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!file || !campaignName || loading}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Campaign'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}