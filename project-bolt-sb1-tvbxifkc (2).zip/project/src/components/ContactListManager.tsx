import React, { useState, useEffect } from 'react';
import { Plus, X, ChevronDown, ChevronUp, Users, Edit2, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface ContactList {
  id: string;
  name: string;
  description: string;
  type: 'static' | 'dynamic';
  filter_criteria?: Record<string, any>;
  contact_count: number;
  created_at: string;
  updated_at: string;
}

interface ContactListManagerProps {
  onClose: () => void;
  onListsChange: () => void;
}

export default function ContactListManager({ onClose, onListsChange }: ContactListManagerProps) {
  const [lists, setLists] = useState<ContactList[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingList, setEditingList] = useState<ContactList | null>(null);
  const [expandedList, setExpandedList] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'static' as const,
    filter_criteria: {}
  });

  useEffect(() => {
    fetchLists();
  }, []);

  async function fetchLists() {
    try {
      const { data, error } = await supabase
        .from('contact_lists')
        .select('*, contact_count:contact_list_members(count)');

      if (error) throw error;
      setLists(data || []);
    } catch (error) {
      console.error('Error fetching lists:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const listData = {
        ...formData,
        filter_criteria: formData.type === 'dynamic' ? formData.filter_criteria : null
      };

      let error;
      if (editingList) {
        ({ error } = await supabase
          .from('contact_lists')
          .update(listData)
          .eq('id', editingList.id));
      } else {
        ({ error } = await supabase
          .from('contact_lists')
          .insert([listData]));
      }

      if (error) throw error;

      setShowAddModal(false);
      setEditingList(null);
      setFormData({
        name: '',
        description: '',
        type: 'static',
        filter_criteria: {}
      });
      fetchLists();
      onListsChange();
    } catch (error) {
      console.error('Error saving list:', error);
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Are you sure you want to delete this list?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('contact_lists')
        .delete()
        .eq('id', id);

      if (error) throw error;
      fetchLists();
      onListsChange();
    } catch (error) {
      console.error('Error deleting list:', error);
    }
  }

  function handleEdit(list: ContactList) {
    setEditingList(list);
    setFormData({
      name: list.name,
      description: list.description,
      type: list.type,
      filter_criteria: list.filter_criteria || {}
    });
    setShowAddModal(true);
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg w-full max-w-2xl my-8">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Manage Contact Lists</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="text-sm text-gray-500">
              {lists.length} total lists
            </div>
            <button
              onClick={() => {
                setEditingList(null);
                setFormData({
                  name: '',
                  description: '',
                  type: 'static',
                  filter_criteria: {}
                });
                setShowAddModal(true);
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg flex items-center gap-2 hover:bg-indigo-700"
            >
              <Plus className="h-4 w-4" />
              Create List
            </button>
          </div>

          {loading ? (
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <div className="space-y-4">
              {lists.map((list) => (
                <div
                  key={list.id}
                  className="bg-white rounded-lg border border-gray-200"
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Users className="h-5 w-5 text-gray-400" />
                        <div>
                          <h3 className="text-sm font-medium text-gray-900">{list.name}</h3>
                          <p className="text-sm text-gray-500">{list.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          list.type === 'dynamic' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {list.type}
                        </span>
                        <span className="text-sm text-gray-500">
                          {list.contact_count} contacts
                        </span>
                        <button
                          onClick={() => handleEdit(list)}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(list.id)}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setExpandedList(
                            expandedList === list.id ? null : list.id
                          )}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          {expandedList === list.id ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    {expandedList === list.id && (
                      <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="space-y-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-900">List Details</h4>
                            <div className="mt-2 text-sm text-gray-500">
                              <p>Created: {format(new Date(list.created_at), 'MMM d, yyyy')}</p>
                              <p>Last updated: {format(new Date(list.updated_at), 'MMM d, yyyy')}</p>
                            </div>
                          </div>

                          {list.type === 'dynamic' && list.filter_criteria && (
                            <div>
                              <h4 className="text-sm font-medium text-gray-900">Filter Criteria</h4>
                              <pre className="mt-2 text-sm text-gray-500 whitespace-pre-wrap">
                                {JSON.stringify(list.filter_criteria, null, 2)}
                              </pre>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit List Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">
              {editingList ? 'Edit List' : 'Create New List'}
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">List Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">List Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      type: e.target.value as 'static' | 'dynamic',
                      filter_criteria: e.target.value === 'dynamic' ? {} : undefined
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="static">Static List</option>
                    <option value="dynamic">Dynamic List</option>
                  </select>
                  <p className="mt-1 text-sm text-gray-500">
                    {formData.type === 'dynamic' 
                      ? 'Contacts are automatically added based on criteria'
                      : 'Contacts are manually added to the list'
                    }
                  </p>
                </div>

                {formData.type === 'dynamic' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Filter Criteria</label>
                    <textarea
                      value={JSON.stringify(formData.filter_criteria, null, 2)}
                      onChange={(e) => {
                        try {
                          const criteria = JSON.parse(e.target.value);
                          setFormData({ ...formData, filter_criteria: criteria });
                        } catch (error) {
                          // Invalid JSON, ignore
                        }
                      }}
                      rows={4}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono text-sm"
                      placeholder="Enter JSON filter criteria"
                    />
                  </div>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingList(null);
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  {editingList ? 'Save Changes' : 'Create List'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}