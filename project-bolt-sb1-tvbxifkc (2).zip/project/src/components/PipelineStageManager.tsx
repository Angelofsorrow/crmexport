import React, { useState } from 'react';
import { X, Plus, ChevronUp, ChevronDown, Trash2 } from 'lucide-react';
import * as Icons from 'lucide-react';
import { supabase } from '../lib/supabase';

interface PipelineStage {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  order_number: number;
  tasks: string[];
  automations: string[];
  is_system: boolean;
  is_closed: boolean;
  is_won: boolean;
  probability: number;
}

interface PipelineStageManagerProps {
  stages: PipelineStage[];
  onStagesChange: (stages: PipelineStage[]) => void;
  onClose: () => void;
}

const COLORS = [
  { name: 'Sky', value: 'bg-sky-600' },
  { name: 'Blue', value: 'bg-blue-600' },
  { name: 'Indigo', value: 'bg-indigo-600' },
  { name: 'Violet', value: 'bg-violet-600' },
  { name: 'Purple', value: 'bg-purple-600' },
  { name: 'Fuchsia', value: 'bg-fuchsia-600' },
  { name: 'Pink', value: 'bg-pink-600' },
  { name: 'Rose', value: 'bg-rose-600' },
  { name: 'Orange', value: 'bg-orange-600' },
  { name: 'Yellow', value: 'bg-yellow-600' },
  { name: 'Green', value: 'bg-green-600' },
  { name: 'Red', value: 'bg-red-600' },
];

const ICONS = Object.keys(Icons).filter(key => 
  typeof Icons[key as keyof typeof Icons] === 'function' && 
  key !== 'createLucideIcon'
);

export default function PipelineStageManager({ stages, onStagesChange, onClose }: PipelineStageManagerProps) {
  const [editingStages, setEditingStages] = useState<PipelineStage[]>(stages);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [newTask, setNewTask] = useState('');
  const [newAutomation, setNewAutomation] = useState('');

  async function handleSaveChanges() {
    try {
      // Update all stages with new order numbers
      await Promise.all(editingStages.map((stage, index) => 
        supabase
          .from('pipeline_stages')
          .update({ 
            name: stage.name,
            description: stage.description,
            color: stage.color,
            icon: stage.icon,
            order_number: index + 1,
            tasks: stage.tasks,
            automations: stage.automations,
            probability: stage.probability
          })
          .eq('id', stage.id)
      ));

      onStagesChange(editingStages);
      onClose();
    } catch (error) {
      console.error('Error saving pipeline stages:', error);
    }
  }

  async function handleAddStage() {
    try {
      const { data, error } = await supabase
        .from('pipeline_stages')
        .insert([{
          name: 'New Stage',
          description: 'Description of the new stage',
          color: 'bg-gray-600',
          icon: 'CircleDot',
          order_number: editingStages.length + 1,
          tasks: [],
          automations: [],
          is_system: false,
          is_closed: false,
          is_won: false,
          probability: 0
        }])
        .select()
        .single();

      if (error) throw error;

      setEditingStages([...editingStages, data]);
      setSelectedStage(data.id);
    } catch (error) {
      console.error('Error adding stage:', error);
    }
  }

  async function handleDeleteStage(stageId: string) {
    if (!window.confirm('Are you sure you want to delete this stage? Any deals in this stage will need to be moved.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('pipeline_stages')
        .delete()
        .eq('id', stageId);

      if (error) throw error;

      setEditingStages(editingStages.filter(s => s.id !== stageId));
      if (selectedStage === stageId) {
        setSelectedStage(null);
      }
    } catch (error) {
      console.error('Error deleting stage:', error);
    }
  }

  function handleMoveStage(index: number, direction: 'up' | 'down') {
    const newStages = [...editingStages];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (newIndex >= 0 && newIndex < newStages.length) {
      const temp = newStages[index];
      newStages[index] = newStages[newIndex];
      newStages[newIndex] = temp;
      setEditingStages(newStages);
    }
  }

  function handleUpdateStage(id: string, updates: Partial<PipelineStage>) {
    setEditingStages(stages => 
      stages.map(stage => 
        stage.id === id ? { ...stage, ...updates } : stage
      )
    );
  }

  function handleAddTask(stageId: string) {
    if (!newTask.trim()) return;

    setEditingStages(stages =>
      stages.map(stage =>
        stage.id === stageId
          ? { ...stage, tasks: [...stage.tasks, newTask.trim()] }
          : stage
      )
    );
    setNewTask('');
  }

  function handleRemoveTask(stageId: string, index: number) {
    setEditingStages(stages =>
      stages.map(stage =>
        stage.id === stageId
          ? { ...stage, tasks: stage.tasks.filter((_, i) => i !== index) }
          : stage
      )
    );
  }

  function handleAddAutomation(stageId: string) {
    if (!newAutomation.trim()) return;

    setEditingStages(stages =>
      stages.map(stage =>
        stage.id === stageId
          ? { ...stage, automations: [...stage.automations, newAutomation.trim()] }
          : stage
      )
    );
    setNewAutomation('');
  }

  function handleRemoveAutomation(stageId: string, index: number) {
    setEditingStages(stages =>
      stages.map(stage =>
        stage.id === stageId
          ? { ...stage, automations: stage.automations.filter((_, i) => i !== index) }
          : stage
      )
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg w-full max-w-4xl my-8">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Manage Pipeline Stages</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="p-6 grid grid-cols-3 gap-6">
          {/* Stages List */}
          <div className="col-span-1 space-y-4">
            {editingStages.map((stage, index) => (
              <div
                key={stage.id}
                className={`p-4 rounded-lg border cursor-pointer ${
                  selectedStage === stage.id
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => setSelectedStage(stage.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {React.createElement(
                      Icons[stage.icon as keyof typeof Icons] || Icons.CircleDot,
                      { className: 'h-4 w-4' }
                    )}
                    <span className="font-medium">{stage.name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {!stage.is_system && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteStage(stage.id);
                        }}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMoveStage(index, 'up');
                      }}
                      disabled={index === 0}
                      className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
                    >
                      <ChevronUp className="h-4 w-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMoveStage(index, 'down');
                      }}
                      disabled={index === editingStages.length - 1}
                      className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
                    >
                      <ChevronDown className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {stage.description}
                </div>
              </div>
            ))}
            <button
              onClick={handleAddStage}
              className="w-full py-2 px-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-gray-400 hover:text-gray-600 flex items-center justify-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Add Stage
            </button>
          </div>

          {/* Stage Details */}
          {selectedStage && (
            <div className="col-span-2 space-y-6">
              {editingStages.map(stage => stage.id === selectedStage && (
                <div key={stage.id}>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Name</label>
                      <input
                        type="text"
                        value={stage.name}
                        onChange={(e) => handleUpdateStage(stage.id, { name: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Probability (%)</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={stage.probability}
                        onChange={(e) => handleUpdateStage(stage.id, { probability: parseInt(e.target.value) })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-sm font-medium text-gray-700">Description</label>
                      <textarea
                        value={stage.description}
                        onChange={(e) => handleUpdateStage(stage.id, { description: e.target.value })}
                        rows={2}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Color</label>
                      <select
                        value={stage.color}
                        onChange={(e) => handleUpdateStage(stage.id, { color: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      >
                        {COLORS.map(color => (
                          <option key={color.value} value={color.value}>
                            {color.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Icon</label>
                      <select
                        value={stage.icon}
                        onChange={(e) => handleUpdateStage(stage.id, { icon: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      >
                        {ICONS.map(icon => (
                          <option key={icon} value={icon}>
                            {icon}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Tasks */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tasks</label>
                    <div className="space-y-2">
                      {stage.tasks.map((task, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <input
                            type="text"
                            value={task}
                            onChange={(e) => {
                              const newTasks = [...stage.tasks];
                              newTasks[index] = e.target.value;
                              handleUpdateStage(stage.id, { tasks: newTasks });
                            }}
                            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          />
                          <button
                            onClick={() => handleRemoveTask(stage.id, index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={newTask}
                          onChange={(e) => setNewTask(e.target.value)}
                          placeholder="Add new task"
                          className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddTask(stage.id);
                            }
                          }}
                        />
                        <button
                          onClick={() => handleAddTask(stage.id)}
                          className="px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Automations */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Automations</label>
                    <div className="space-y-2">
                      {stage.automations.map((automation, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <input
                            type="text"
                            value={automation}
                            onChange={(e) => {
                              const newAutomations = [...stage.automations];
                              newAutomations[index] = e.target.value;
                              handleUpdateStage(stage.id, { automations: newAutomations });
                            }}
                            className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          />
                          <button
                            onClick={() => handleRemoveAutomation(stage.id, index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={newAutomation}
                          onChange={(e) => setNewAutomation(e.target.value)}
                          placeholder="Add new automation"
                          className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddAutomation(stage.id);
                            }
                          }}
                        />
                        <button
                          onClick={() => handleAddAutomation(stage.id)}
                          className="px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
          >
            Cancel
          </button>
          <button
            onClick={handleSaveChanges}
            className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}