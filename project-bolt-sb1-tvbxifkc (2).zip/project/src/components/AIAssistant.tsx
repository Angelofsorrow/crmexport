import React, { useState, useRef } from 'react';
import { useAuthStore } from '../store/auth';
import { MessageSquare, Play, Pause, Trash2, Mail, Phone, Calendar, Settings, Tag, Star, X, ChevronDown, ChevronUp, Reply, Send, Loader2 } from 'lucide-react';
import OpenAI from 'openai';
import { triggerAutomation } from '../lib/aiAgent';
import { supabase } from '../lib/supabase';
import type { AIRequestType, AIRequest, AIResponse } from '../lib/types';

interface AIAssistantProps {
  context?: {
    company?: {
      name: string;
      industry?: string;
      status?: string;
    };
    contact?: {
      name: string;
      role?: string;
      company?: string;
      email?: string;
    };
    deal?: {
      title: string;
      stage?: string;
      value?: number;
    };
  };
  onSuggestion?: (suggestion: string) => void;
}

const TASK_TYPES: Array<{
  type: AIRequestType;
  label: string;
  icon: React.ReactNode;
  description: string;
  requiredFields?: string[];
}> = [
  {
    type: 'email_draft',
    label: 'Write Email',
    icon: <Mail className="h-4 w-4" />,
    description: 'Draft an email message'
  },
  {
    type: 'calendar_event',
    label: 'Schedule Meeting',
    icon: <Calendar className="h-4 w-4" />,
    description: 'Create a calendar event',
    requiredFields: ['title', 'date', 'time', 'duration', 'attendees', 'description']
  },
  {
    type: 'task_suggestion',
    label: 'Suggest Tasks',
    icon: <Star className="h-4 w-4" />,
    description: 'Get task recommendations'
  },
  {
    type: 'contact_research',
    label: 'Research Contact',
    icon: <Tag className="h-4 w-4" />,
    description: 'Research contact information'
  },
  {
    type: 'document_generation',
    label: 'Generate Document',
    icon: <Mail className="h-4 w-4" />,
    description: 'Create a document'
  },
  {
    type: 'deal_analysis',
    label: 'Analyze Deal',
    icon: <Star className="h-4 w-4" />,
    description: 'Get deal insights'
  }
];

export default function AIAssistant({ context, onSuggestion }: AIAssistantProps) {
  const { user } = useAuthStore();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [selectedTask, setSelectedTask] = useState<AIRequestType | null>(null);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [messages, setMessages] = useState<Array<{
    role: 'assistant' | 'user';
    content: string;
    action?: {
      type: string;
      data: any;
    };
  }>>([]);
  const [collectedFields, setCollectedFields] = useState<Record<string, string>>({});
  const [currentField, setCurrentField] = useState<string | null>(null);
  const [fieldHistory, setFieldHistory] = useState<Array<{field: string, value: string}>>([]);

  const openai = new OpenAI({
    apiKey: import.meta.env.VITE_OPENAI_API_KEY,
    dangerouslyAllowBrowser: true
  });

  function parseTimeInput(timeStr: string): string {
    // Handle various time formats
    const timeRegex = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i;
    const match = timeStr.match(timeRegex);
    
    if (match) {
      let hours = parseInt(match[1]);
      const minutes = match[2] ? parseInt(match[2]) : 0;
      const period = match[3]?.toLowerCase();

      // Convert to 24-hour format
      if (period === 'pm' && hours < 12) hours += 12;
      if (period === 'am' && hours === 12) hours = 0;

      // If no am/pm specified and hours < 12, assume business hours (9am-5pm)
      if (!period && hours < 12) {
        const currentHour = new Date().getHours();
        if (currentHour >= 17) { // After business hours, schedule for next day morning
          hours = 9;
        } else if (hours < 9) { // Before 9am, set to 9am
          hours = 9;
        }
      }

      // Format as HH:MM
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    }

    throw new Error('Invalid time format. Please use HH:MM or H(am/pm)');
  }

  function getDefaultEventDetails() {
    const now = new Date();
    const roundedMinutes = Math.ceil(now.getMinutes() / 15) * 15;
    const startTime = new Date(now.setMinutes(roundedMinutes));
    
    // If we're past 5pm, schedule for next day at 9am
    if (startTime.getHours() >= 17) {
      startTime.setDate(startTime.getDate() + 1);
      startTime.setHours(9, 0, 0, 0);
    }
    // If we're before 9am, schedule for 9am
    else if (startTime.getHours() < 9) {
      startTime.setHours(9, 0, 0, 0);
    }

    return {
      date: startTime.toISOString().split('T')[0],
      time: `${startTime.getHours().toString().padStart(2, '0')}:${startTime.getMinutes().toString().padStart(2, '0')}`,
      duration: '30' // Default 30-minute meeting
    };
  }

  function handleGoBack() {
    if (fieldHistory.length > 0) {
      // Get the previous field
      const prevField = fieldHistory[fieldHistory.length - 2]?.field || null;
      const prevValue = fieldHistory[fieldHistory.length - 2]?.value || '';

      // Update state
      setCurrentField(prevField);
      setPrompt(prevValue);
      
      // Remove the last field from history
      setFieldHistory(history => history.slice(0, -1));

      // Remove the last field from collected fields
      const lastField = fieldHistory[fieldHistory.length - 1].field;
      const { [lastField]: _, ...remainingFields } = collectedFields;
      setCollectedFields(remainingFields);

      // Remove the last two messages (user input and assistant prompt)
      setMessages(messages => messages.slice(0, -2));

      setError(null);
    } else if (selectedTask) {
      // Go back to task selection
      setSelectedTask(null);
      setCurrentField(null);
      setCollectedFields({});
      setFieldHistory([]);
      setMessages([]);
      setPrompt('');
      setError(null);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!prompt.trim() || !user) return;

    try {
      setError(null);
      setLoading(true);

      // Add user message to chat
      const userMessage = { role: 'user' as const, content: prompt };
      setMessages(prev => [...prev, userMessage]);
      setPrompt('');

      // Get current session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session) throw new Error('No authenticated session');

      // For calendar events, collect all required fields
      if (selectedTask === 'calendar_event') {
        const requiredFields = TASK_TYPES.find(t => t.type === 'calendar_event')?.requiredFields || [];
        
        // If we're collecting fields and this isn't the last one
        if (currentField && currentField !== 'complete') {
          let fieldValue = prompt;

          // Special handling for time field
          if (currentField === 'time') {
            try {
              fieldValue = parseTimeInput(prompt);
            } catch (error: any) {
              setError(error.message);
              setLoading(false);
              return;
            }
          }

          // Store the current field value
          setCollectedFields(prev => ({
            ...prev,
            [currentField]: fieldValue
          }));

          // Add to field history
          setFieldHistory(prev => [...prev, { field: currentField, value: prompt }]);

          // Find next required field
          const nextFieldIndex = requiredFields.indexOf(currentField) + 1;
          if (nextFieldIndex < requiredFields.length) {
            const nextField = requiredFields[nextFieldIndex];
            setCurrentField(nextField);
            
            // Ask for next field
            setMessages(prev => [...prev, {
              role: 'assistant',
              content: getFieldPrompt(nextField)
            }]);
            
            setLoading(false);
            return;
          } else {
            // All fields collected, proceed with creating event
            setCurrentField('complete');
          }
        }

        // If we're just starting to collect fields
        if (!currentField) {
          // Set default values
          const defaults = getDefaultEventDetails();
          setCollectedFields(defaults);

          // Start with first field
          setCurrentField(requiredFields[0]);
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: getFieldPrompt(requiredFields[0])
          }]);
          
          setLoading(false);
          return;
        }

        // If all fields are collected, create the event
        if (currentField === 'complete') {
          const startDate = new Date(`${collectedFields.date}T${collectedFields.time}`);
          const endDate = new Date(startDate.getTime() + parseInt(collectedFields.duration) * 60000);

          const eventDetails = {
            title: collectedFields.title,
            startTime: startDate.toISOString(),
            endTime: endDate.toISOString(),
            description: collectedFields.description,
            attendees: collectedFields.attendees.split(',').map(email => ({
              email: email.trim()
            }))
          };

          console.log('Creating calendar event with details:', eventDetails);

          // Trigger the automation with properly formatted event details
          const response = await triggerAutomation({
            type: 'create_calendar_event',
            eventDetails
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to create calendar event');
          }

          // Add success message
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: 'Calendar event created successfully! What else can I help you with?',
            action: {
              type: 'create_calendar_event',
              data: { eventDetails }
            }
          }]);

          // Clear collected fields and reset state
          setCollectedFields({});
          setCurrentField(null);
          setSelectedTask(null);
          setFieldHistory([]);

          // Show task selection after a short delay
          setTimeout(() => {
            setMessages([]);
          }, 3000);

          setLoading(false);
          return;
        }
      }

      let systemContext = `You are an AI assistant helping with CRM tasks. The user wants to ${selectedTask ? TASK_TYPES.find(t => t.type === selectedTask)?.description.toLowerCase() : 'perform a task'}. `;

      if (context) {
        if (context.company) {
          systemContext += `Company: ${context.company.name} (${context.company.industry || 'Unknown industry'}, Status: ${context.company.status || 'Unknown'}). `;
        }
        if (context.contact) {
          systemContext += `Contact: ${context.contact.name} (${context.contact.role || 'Unknown role'} at ${context.contact.company || 'Unknown company'}). `;
        }
        if (context.deal) {
          systemContext += `Deal: ${context.deal.title} (Stage: ${context.deal.stage || 'Unknown'}, Value: ${context.deal.value ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(context.deal.value) : 'Unknown'}). `;
        }
      }

      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: systemContext },
          ...messages.map(m => ({ role: m.role, content: m.content })),
          userMessage
        ],
        temperature: 0.7,
        max_tokens: 500,
        functions: [
          {
            name: "performAction",
            description: "Perform a CRM action",
            parameters: {
              type: "object",
              properties: {
                type: {
                  type: "string",
                  enum: ["send_email", "create_calendar_event", "generate_document", "create_task", "research_contact", "analyze_deal"]
                },
                data: {
                  type: "object",
                  properties: {
                    eventDetails: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        startTime: { type: "string", format: "date-time" },
                        endTime: { type: "string", format: "date-time" },
                        description: { type: "string" },
                        location: { type: "string" },
                        attendees: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              email: { type: "string" },
                              name: { type: "string" }
                            },
                            required: ["email"]
                          }
                        }
                      },
                      required: ["title", "startTime", "attendees"]
                    },
                    to: { type: "string" },
                    subject: { type: "string" },
                    content: { type: "string" },
                    documentType: { type: "string" },
                    template: { type: "string" }
                  }
                }
              },
              required: ["type", "data"]
            }
          }
        ],
        function_call: "auto"
      });

      const result = completion.choices[0].message;
      let action = null;

      if (result.function_call) {
        const functionArgs = JSON.parse(result.function_call.arguments);
        action = {
          type: functionArgs.type,
          data: functionArgs.data
        };

        try {
          // Trigger the automation
          const response = await triggerAutomation({
            type: functionArgs.type,
            data: functionArgs.data,
            eventDetails: functionArgs.data.eventDetails
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to trigger automation');
          }

          // Add success message and return to main menu
          setMessages(prev => [...prev, { 
            role: 'assistant', 
            content: `${functionArgs.type === 'create_calendar_event' ? 'Calendar event created successfully!' : 'Task completed successfully!'} What else can I help you with?`,
            action
          }]);

          // Clear task selection and show menu after delay
          setTimeout(() => {
            setSelectedTask(null);
            setMessages([]);
          }, 3000);
        } catch (automationError: any) {
          console.error('Error triggering automation:', automationError);
          setError(automationError.message || 'Failed to perform the requested action. Please try again.');
          action = null; // Don't show the action UI if it failed
        }
      } else {
        // Add assistant response to chat
        setMessages(prev => [...prev, { 
          role: 'assistant', 
          content: result.content || "I will help you with that task.",
          action
        }]);
        
        if (onSuggestion && result.content) {
          onSuggestion(result.content);
        }
      }

      // Clear selected task after completion
      if (!currentField || currentField === 'complete') {
        setSelectedTask(null);
      }
    } catch (error: any) {
      console.error('Error getting AI response:', error);
      setError(error.message || 'Sorry, I encountered an error while processing your request. Please try again.');
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Sorry, I encountered an error while processing your request.' 
      }]);
    } finally {
      setLoading(false);
    }
  }

  function getFieldPrompt(field: string): string {
    switch (field) {
      case 'title':
        return "What's the title of the meeting?";
      case 'date':
        return "What date should the meeting be scheduled for? (YYYY-MM-DD)";
      case 'time':
        return "What time should the meeting start? (e.g. 2:30pm or 14:30)";
      case 'duration':
        return "How long should the meeting be? (in minutes)";
      case 'attendees':
        return "Please provide the email addresses of all attendees, separated by commas.";
      case 'description':
        return "Please provide a description or agenda for the meeting.";
      default:
        return "Please provide the required information.";
    }
  }

  return (
    <>
      {/* Chat bubble button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-indigo-600 text-white rounded-full shadow-lg hover:bg-indigo-700 flex items-center justify-center transition-all duration-200 z-50"
      >
        <MessageSquare className="h-6 w-6" />
      </button>

      {/* Chat window */}
      {isOpen && (
        <div className="fixed inset-x-0 bottom-0 z-50 flex justify-end">
          <div 
            className={`w-full max-w-md bg-white shadow-xl flex flex-col mr-24 transition-all duration-200 ${
              isMinimized ? 'h-14' : 'h-[600px]'
            }`}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-indigo-600" />
                <h3 className="font-medium">AI Assistant</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  {isMinimized ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>
                <button
                  onClick={() => {
                    setIsOpen(false);
                    setIsMinimized(false);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* Content (hidden when minimized) */}
            {!isMinimized && (
              <>
                {/* Task Type Selection */}
                {!selectedTask && messages.length === 0 && (
                  <div className="p-4 border-b">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">What would you like help with?</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {TASK_TYPES.map(task => (
                        <button
                          key={task.type}
                          onClick={() => setSelectedTask(task.type)}
                          className="flex items-center gap-2 p-2 text-left text-sm rounded-lg hover:bg-gray-50 border border-gray-200"
                        >
                          {task.icon}
                          <span>{task.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {selectedTask && messages.length === 0 && (
                    <div className="text-sm text-gray-500">
                      {TASK_TYPES.find(t => t.type === selectedTask)?.description}. How can I help?
                    </div>
                  )}
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg px-4 py-2 ${
                          message.role === 'user'
                            ? 'bg-indigo-600 text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        {message.action && (
                          <div className="mt-2 pt-2 border-t border-gray-200 flex items-center gap-2 text-xs">
                            {message.action.type === 'send_email' && <Mail className="h-4 w-4" />}
                            {message.action.type === 'create_calendar_event' && <Calendar className="h-4 w-4" />}
                            {message.action.type === 'generate_document' && <Mail className="h-4 w-4" />}
                            <span>
                              {message.action.type === 'send_email' && 'Sending email...'}
                              {message.action.type === 'create_calendar_event' && 'Creating calendar event...'}
                              {message.action.type === 'generate_document' && 'Generating document...'}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {loading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 rounded-lg px-4 py-2">
                        <Loader2 className="h-5 w-5 animate-spin text-indigo-600" />
                      </div>
                    </div>
                  )}
                </div>

                {/* Error message */}
                {error && (
                  <div className="px-4 py-2 bg-red-50 border-t border-red-100">
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                )}

                {/* Input form */}
                <form onSubmit={handleSubmit} className="p-4 border-t">
                  <div className="flex gap-2">
                    <div className="flex-1 flex gap-2">
                      {(currentField || selectedTask) && (
                        <button
                          type="button"
                          onClick={handleGoBack}
                          className="px-3 py-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
                          title="Go back"
                        >
                          <Reply className="h-4 w-4" />
                        </button>
                      )}
                      <input
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder={
                          currentField 
                            ? getFieldPrompt(currentField)
                            : selectedTask 
                              ? `Type your ${TASK_TYPES.find(t => t.type === selectedTask)?.label.toLowerCase()} request...`
                              : "Ask me anything..."
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={loading || !prompt.trim() || !user}
                      className="px-4 py-2 bg-indigo-600 text-white rounded-lg flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50"
                    >
                      {loading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}