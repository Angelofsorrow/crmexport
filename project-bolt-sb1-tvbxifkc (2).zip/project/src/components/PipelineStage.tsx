import React, { useState } from 'react';
import { useDroppable } from '@dnd-kit/core';
import { ChevronDown, ChevronUp, CheckCircle2, Zap, Building2, Trash2 } from 'lucide-react';
import type { Deal } from './PipelineView';
import * as Icons from 'lucide-react';
import { PipelineCard } from './PipelineCard';

interface StageProps {
  stage: {
    id: string;
    name: string;
    description: string;
    color: string;
    icon: keyof typeof Icons;
    tasks: string[];
    automations: string[];
    deals: Deal[];
    probability: number;
    is_system?: boolean;
  };
  totalValue: number;
  onDelete: (stageId: string) => void;
}

export function PipelineStage({ stage, totalValue, onDelete }: StageProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const { setNodeRef } = useDroppable({
    id: stage.id,
  });

  // Dynamically get icon component
  const IconComponent = Icons[stage.icon as keyof typeof Icons] || Icons.CircleDot;

  async function handleDelete() {
    if (stage.deals.length > 0) {
      alert('Cannot delete stage with active deals. Please move or close all deals first.');
      return;
    }
    
    try {
      await onDelete(stage.id);
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error('Error deleting stage:', error);
      alert('Failed to delete stage. Please try again.');
    }
  }

  return (
    <div 
      className="flex-1 min-w-[300px] bg-gray-50 rounded-lg overflow-hidden"
      ref={setNodeRef}
    >
      <div className={`p-4 ${stage.color} text-white`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <IconComponent className="h-5 w-5" />
              <h3 className="font-medium text-lg">{stage.name}</h3>
            </div>
            <span className="text-sm opacity-90">
              ({stage.deals.length})
            </span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm">
              {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD',
                notation: 'compact',
                maximumFractionDigits: 1,
              }).format(totalValue)}
            </div>
            {!stage.is_system && (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="text-white opacity-70 hover:opacity-100 transition-opacity"
                title="Delete stage"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
        <p className="text-sm mt-1 opacity-75">{stage.description}</p>
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="flex items-center gap-1 text-sm mt-2 opacity-90 hover:opacity-100"
        >
          {showDetails ? 'Hide' : 'Show'} details
          {showDetails ? (
            <ChevronUp className="h-4 w-4" />
          ) : (
            <ChevronDown className="h-4 w-4" />
          )}
        </button>
      </div>

      {showDetails && (
        <div className="p-4 border-b border-gray-200 space-y-4 bg-white">
          <div>
            <h4 className="text-sm font-medium text-gray-900 flex items-center gap-2 mb-2">
              <CheckCircle2 className="h-4 w-4 text-gray-500" />
              Required Tasks
            </h4>
            <ul className="space-y-2">
              {stage.tasks.map((task, index) => (
                <li key={index} className="text-sm text-gray-600 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-gray-400" />
                  {task}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-900 flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-gray-500" />
              Automations
            </h4>
            <ul className="space-y-2">
              {stage.automations.map((automation, index) => (
                <li key={index} className="text-sm text-gray-600 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-gray-400" />
                  {automation}
                </li>
              ))}
            </ul>
          </div>
          <div className="pt-2 border-t border-gray-100">
            <div className="text-sm text-gray-500">
              Approval Probability: {stage.probability}%
            </div>
          </div>
        </div>
      )}

      <div className="p-4 space-y-3">
        {stage.deals.map((deal) => (
          <PipelineCard key={deal.id} deal={deal} />
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Delete Stage</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this stage? This action cannot be undone.
              {stage.deals.length > 0 && (
                <span className="block mt-2 text-red-600">
                  Warning: This stage contains {stage.deals.length} active deals. You must move or close these deals before deleting the stage.
                </span>
              )}
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={stage.deals.length > 0}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Delete Stage
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}