import React, { useState } from 'react';
import {
  DndContext,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragStartEvent,
  DragEndEvent,
} from '@dnd-kit/core';
import { PipelineStage } from './PipelineStage';
import { PipelineCard } from './PipelineCard';
import { Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';

export interface Deal {
  id: string;
  title: string;
  amount: number;
  company?: {
    name: string;
  };
}

interface Stage {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  tasks: string[];
  automations: string[];
  probability: number;
  is_system?: boolean;
  deals: Deal[];
}

interface PipelineViewProps {
  stages: Stage[];
  onStageChange: (dealId: string, fromStage: string, toStage: string) => void;
  onAddDeal?: () => void;
  onStageDeleted?: () => void;
}

export function PipelineView({ stages, onStageChange, onAddDeal, onStageDeleted }: PipelineViewProps) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor)
  );

  function handleDragStart(event: DragStartEvent) {
    const { active } = event;
    setActiveId(active.id as string);
    
    // Find which stage the item is being dragged from
    const stage = stages.find(s => s.deals.some(d => d.id === active.id));
    if (stage) {
      setActiveStage(stage.id);
    }
  }

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const fromStageId = activeStage;
      const toStageId = over.id as string;

      if (fromStageId && toStageId && fromStageId !== toStageId) {
        onStageChange(active.id as string, fromStageId, toStageId);
      }
    }

    setActiveId(null);
    setActiveStage(null);
  }

  async function handleDeleteStage(stageId: string) {
    try {
      const { error } = await supabase
        .from('pipeline_stages')
        .delete()
        .eq('id', stageId);

      if (error) throw error;
      
      if (onStageDeleted) {
        onStageDeleted();
      }
    } catch (error) {
      console.error('Error deleting stage:', error);
      throw error;
    }
  }

  // Find the active deal for the drag overlay
  const activeDeal = activeId 
    ? stages.flatMap(s => s.deals).find(d => d.id === activeId)
    : null;

  const totalValue = stages.reduce((sum, stage) => 
    sum + stage.deals.reduce((stageSum, deal) => stageSum + deal.amount, 0), 
    0
  );

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-lg font-semibold">Pipeline View</h2>
          <div className="text-sm text-gray-500">
            Total value: {new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
              notation: 'compact',
              maximumFractionDigits: 1,
            }).format(totalValue)}
          </div>
        </div>
        {onAddDeal && (
          <button
            onClick={onAddDeal}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700"
          >
            <Plus className="h-4 w-4" />
            Add Deal
          </button>
        )}
      </div>

      <div className="flex-1 flex gap-4 overflow-x-auto pb-4">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          {stages.map((stage) => (
            <PipelineStage
              key={stage.id}
              stage={stage}
              totalValue={stage.deals.reduce((sum, deal) => sum + deal.amount, 0)}
              onDelete={handleDeleteStage}
            />
          ))}

          <DragOverlay>
            {activeDeal ? (
              <div className="w-[calc(100vw/5-24px)]">
                <PipelineCard deal={activeDeal} />
              </div>
            ) : null}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  );
}