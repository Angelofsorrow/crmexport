import React, { useState, useRef } from 'react';
import { MessageSquare, Mail, Voicemail, ChevronDown, Plus, X, Mic, Square, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';

interface CampaignStep {
  id: string;
  type: 'text' | 'email' | 'voicemail';
  delay_hours: number;
  subject?: string;
  content: string;
  voicemail_url?: string;
  scheduled_time?: string;
}

interface CampaignTimelineProps {
  campaignId: string;
  steps: CampaignStep[];
  onStepsChange: (steps: CampaignStep[]) => void;
}

interface TimeDelay {
  days: number;
  hours: number;
  minutes: number;
}

export default function CampaignTimeline({ campaignId, steps, onStepsChange }: CampaignTimelineProps) {
  const { user } = useAuthStore();
  const [showModal, setShowModal] = useState(false);
  const [selectedType, setSelectedType] = useState<'text' | 'email' | 'voicemail'>('text');
  const [voicemailFile, setVoicemailFile] = useState<File | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingBlob, setRecordingBlob] = useState<Blob | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const [formData, setFormData] = useState({
    delay: {
      days: 0,
      hours: 0,
      minutes: 0
    },
    subject: '',
    content: '',
  });

  // Convert total hours to days, hours, minutes
  function hoursToTimeDelay(totalHours: number): TimeDelay {
    const days = Math.floor(totalHours / 24);
    const remainingHours = totalHours % 24;
    const hours = Math.floor(remainingHours);
    const minutes = Math.round((remainingHours - hours) * 60);

    return { days, hours, minutes };
  }

  // Convert days, hours, minutes to total hours
  function timeDelayToHours(delay: TimeDelay): number {
    return Math.round(delay.days * 24 + delay.hours + (delay.minutes / 60));
  }

  // Group steps by day
  const stepsByDay = steps.reduce((acc: { [key: string]: CampaignStep[] }, step) => {
    const { days } = hoursToTimeDelay(step.delay_hours);
    const dayKey = `Day ${days + 1}`;
    if (!acc[dayKey]) {
      acc[dayKey] = [];
    }
    acc[dayKey].push(step);
    return acc;
  }, {});

  function getStepIcon(type: string) {
    switch (type) {
      case 'text':
        return <MessageSquare className="h-5 w-5 text-blue-500" />;
      case 'email':
        return <Mail className="h-5 w-5 text-green-500" />;
      case 'voicemail':
        return <Voicemail className="h-5 w-5 text-orange-500" />;
      default:
        return null;
    }
  }

  function formatDelay(totalHours: number): string {
    const { days, hours, minutes } = hoursToTimeDelay(totalHours);
    const parts = [];

    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);

    return parts.length > 0 ? `+${parts.join(' ')}` : 'Immediately';
  }

  async function uploadVoicemail(file: File | Blob): Promise<string> {
    if (!user) throw new Error('User not authenticated');

    const fileExt = file instanceof File ? file.name.split('.').pop() : 'webm';
    const fileName = `voicemails/${campaignId}/${Math.random().toString(36).substring(2)}.${fileExt}`;

    try {
      const { error: uploadError } = await supabase.storage
        .from('campaign-files')
        .upload(fileName, file, {
          upsert: true,
          contentType: file instanceof File ? file.type : 'audio/webm',
        });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('campaign-files')
        .getPublicUrl(fileName);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading voicemail:', error);
      throw error;
    }
  }

  async function handleAddStep(e: React.FormEvent) {
    e.preventDefault();

    try {
      if (!user) throw new Error('User not authenticated');

      const totalDelayHours = timeDelayToHours(formData.delay);

      let voicemailUrl = '';
      if (selectedType === 'voicemail' && (voicemailFile || recordingBlob)) {
        voicemailUrl = await uploadVoicemail(voicemailFile || recordingBlob!);
      }

      const { data, error } = await supabase
        .from('campaign_steps')
        .insert([{
          campaign_id: campaignId,
          type: selectedType,
          delay_hours: totalDelayHours,
          subject: selectedType === 'email' ? formData.subject : null,
          content: formData.content,
          voicemail_url: voicemailUrl || null,
          order_number: steps.length + 1,
        }])
        .select()
        .single();

      if (error) throw error;

      onStepsChange([...steps, data]);
      setShowModal(false);
      setFormData({
        delay: { days: 0, hours: 0, minutes: 0 },
        subject: '',
        content: '',
      });
      setVoicemailFile(null);
      setRecordingBlob(null);
      setUploadProgress(0);
    } catch (error) {
      console.error('Error adding step:', error);
    }
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true,
        video: false
      }).catch((err) => {
        if (err.name === 'NotAllowedError') {
          throw new Error('Microphone permission denied. Please allow microphone access to record voicemails.');
        }
        throw err;
      });

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setRecordingBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert(error instanceof Error ? error.message : 'Failed to start recording');
    }
  }

  function stopRecording() {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  }

  function handleAddMessage(type: 'text' | 'email' | 'voicemail') {
    setSelectedType(type);
    setShowModal(true);
  }

  return (
    <div className="space-y-8">
      {/* Communication Type Selector */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => handleAddMessage('text')}
          className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100"
        >
          <MessageSquare className="h-4 w-4" />
          <Plus className="h-4 w-4" />
          Add Text
        </button>
        <button
          onClick={() => handleAddMessage('email')}
          className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100"
        >
          <Mail className="h-4 w-4" />
          <Plus className="h-4 w-4" />
          Add Email
        </button>
        <button
          onClick={() => handleAddMessage('voicemail')}
          className="flex items-center gap-2 px-4 py-2 bg-orange-50 text-orange-600 rounded-lg hover:bg-orange-100"
        >
          <Voicemail className="h-4 w-4" />
          <Plus className="h-4 w-4" />
          Add Voicemail
        </button>
      </div>

      {/* Timeline */}
      <div className="space-y-6">
        {Object.entries(stepsByDay).map(([day, daySteps]) => (
          <div key={day} className="relative">
            <div className="text-lg font-semibold text-gray-900 mb-4">{day}</div>
            <div className="space-y-4">
              {daySteps.map((step) => (
                <div
                  key={step.id}
                  className="relative pl-8 before:absolute before:left-3 before:top-0 before:bottom-0 before:w-px before:bg-gray-200"
                >
                  <div className="absolute left-0 top-2 w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                  </div>
                  <div className="bg-white rounded-lg border border-gray-200 p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        {getStepIcon(step.type)}
                        <span className="font-medium text-gray-900 capitalize">
                          {step.type}
                        </span>
                        <span className="text-sm text-gray-500">
                          {formatDelay(step.delay_hours)}
                        </span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600">
                        <ChevronDown className="h-5 w-5" />
                      </button>
                    </div>
                    {step.subject && (
                      <div className="text-sm font-medium text-gray-900 mb-2">
                        Subject: {step.subject}
                      </div>
                    )}
                    {step.type === 'voicemail' && step.voicemail_url ? (
                      <audio src={step.voicemail_url} controls className="w-full" />
                    ) : (
                      <div className="text-sm text-gray-600 whitespace-pre-wrap">
                        {step.content}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Add Message Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Add {selectedType} Message</h2>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={handleAddStep}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Delay</label>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Days</label>
                      <input
                        type="number"
                        min="0"
                        value={formData.delay.days}
                        onChange={(e) => setFormData({
                          ...formData,
                          delay: { ...formData.delay, days: parseInt(e.target.value) || 0 }
                        })}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Hours</label>
                      <input
                        type="number"
                        min="0"
                        max="23"
                        value={formData.delay.hours}
                        onChange={(e) => setFormData({
                          ...formData,
                          delay: { ...formData.delay, hours: parseInt(e.target.value) || 0 }
                        })}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">Minutes</label>
                      <input
                        type="number"
                        min="0"
                        max="59"
                        value={formData.delay.minutes}
                        onChange={(e) => setFormData({
                          ...formData,
                          delay: { ...formData.delay, minutes: parseInt(e.target.value) || 0 }
                        })}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                </div>
                {selectedType === 'email' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Subject</label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                )}
                {selectedType === 'voicemail' ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Upload Voicemail</label>
                      <input
                        type="file"
                        accept="audio/*"
                        onChange={(e) => {
                          setVoicemailFile(e.target.files?.[0] || null);
                          setRecordingBlob(null);
                        }}
                        className="mt-1 block w-full text-sm text-gray-500
                          file:mr-4 file:py-2 file:px-4
                          file:rounded-md file:border-0
                          file:text-sm file:font-medium
                          file:bg-indigo-50 file:text-indigo-700
                          hover:file:bg-indigo-100"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Or Record Voicemail</label>
                      <div className="flex items-center gap-4">
                        {!isRecording ? (
                          <button
                            type="button"
                            onClick={startRecording}
                            disabled={!!voicemailFile}
                            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
                          >
                            <Mic className="h-4 w-4" />
                            Start Recording
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={stopRecording}
                            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                          >
                            <Square className="h-4 w-4" />
                            Stop Recording
                          </button>
                        )}
                        {recordingBlob && (
                          <audio src={URL.createObjectURL(recordingBlob)} controls className="flex-1" />
                        )}
                      </div>
                    </div>
                    {(voicemailFile || recordingBlob) && uploadProgress > 0 && uploadProgress < 100 && (
                      <div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-indigo-600 h-2 rounded-full"
                            style={{ width: `${uploadProgress}%` }}
                          />
                        </div>
                        <p className="mt-1 text-sm text-gray-500">
                          Uploading: {uploadProgress.toFixed(0)}%
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Content</label>
                    <textarea
                      rows={4}
                      value={formData.content}
                      onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                )}
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setVoicemailFile(null);
                    setRecordingBlob(null);
                    if (isRecording) {
                      stopRecording();
                    }
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    selectedType === 'voicemail'
                      ? (!voicemailFile && !recordingBlob) || uploadProgress > 0
                      : !formData.content
                  }
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md disabled:opacity-50"
                >
                  {uploadProgress > 0 ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    'Add Message'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}