import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Mail, MessageSquare, Voicemail, GripVertical, Trash2 } from 'lucide-react';

interface CampaignStep {
  id: string;
  type: 'email' | 'text' | 'voicemail';
  delay_hours: number;
  subject?: string;
  content: string;
  order_number: number;
  voicemail_url?: string;
}

interface SortableStepProps {
  step: CampaignStep;
  onDelete: () => void;
}

export function SortableStep({ step, onDelete }: SortableStepProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: step.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  function getStepIcon() {
    switch (step.type) {
      case 'email':
        return <Mail className="h-5 w-5 text-blue-500" />;
      case 'text':
        return <MessageSquare className="h-5 w-5 text-green-500" />;
      case 'voicemail':
        return <Voicemail className="h-5 w-5 text-purple-500" />;
    }
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white rounded-lg shadow p-4"
    >
      <div className="flex items-start gap-4">
        <div
          {...attributes}
          {...listeners}
          className="cursor-move text-gray-400 hover:text-gray-600"
        >
          <GripVertical className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            {getStepIcon()}
            <span className="font-medium text-gray-900 capitalize">
              {step.type} {step.delay_hours > 0 && `(+${step.delay_hours}h)`}
            </span>
          </div>
          {step.type === 'email' && step.subject && (
            <div className="text-sm text-gray-600 mb-1">
              Subject: {step.subject}
            </div>
          )}
          {step.type === 'voicemail' && step.voicemail_url ? (
            <audio src={step.voicemail_url} controls className="w-full" />
          ) : (
            <div className="text-sm text-gray-500">
              {step.content}
            </div>
          )}
        </div>
        <button
          onClick={onDelete}
          className="text-gray-400 hover:text-red-600"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}