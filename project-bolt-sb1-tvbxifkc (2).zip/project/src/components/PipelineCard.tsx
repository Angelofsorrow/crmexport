import React from 'react';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { Building2 } from 'lucide-react';
import type { Deal } from './PipelineView';

interface CardProps {
  deal: Deal;
}

export function PipelineCard({ deal }: CardProps) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: deal.id,
  });

  const style = transform ? {
    transform: CSS.Translate.toString(transform),
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className="bg-white rounded-lg shadow p-3 cursor-move hover:shadow-md transition-shadow"
    >
      <div className="text-sm font-medium text-gray-900 mb-1">
        {deal.title}
      </div>
      {deal.company && (
        <div className="flex items-center text-sm text-gray-500">
          <Building2 className="h-4 w-4 mr-1" />
          {deal.company.name}
        </div>
      )}
      <div className="mt-2 text-sm font-medium text-gray-900">
        {new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
        }).format(deal.amount)}
      </div>
    </div>
  );
}