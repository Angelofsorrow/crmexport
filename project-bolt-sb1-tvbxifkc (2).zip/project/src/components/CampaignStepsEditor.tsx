import React, { useState, useRef } from 'react';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { SortableStep } from './SortableStep';
import { Plus, Mail, MessageSquare, Voicemail, Mic, Square, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface CampaignStep {
  id: string;
  type: 'email' | 'text' | 'voicemail';
  delay_hours: number;
  subject?: string;
  content: string;
  order_number: number;
  voicemail_url?: string;
}

interface CampaignStepsEditorProps {
  campaignId: string;
  steps: CampaignStep[];
  onStepsChange: (steps: CampaignStep[]) => void;
}

export default function CampaignStepsEditor({ campaignId, steps, onStepsChange }: CampaignStepsEditorProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    type: 'email' as const,
    delay_hours: 0,
    subject: '',
    content: '',
  });
  const [voicemailFile, setVoicemailFile] = useState<File | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingBlob, setRecordingBlob] = useState<Blob | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  async function handleDragEnd(event: any) {
    const { active, over } = event;
    
    if (active.id !== over.id) {
      const oldIndex = steps.findIndex(step => step.id === active.id);
      const newIndex = steps.findIndex(step => step.id === over.id);
      
      const newSteps = arrayMove(steps, oldIndex, newIndex).map((step, index) => ({
        ...step,
        order_number: index + 1,
      }));

      try {
        await Promise.all(
          newSteps.map(step =>
            supabase
              .from('campaign_steps')
              .update({ order_number: step.order_number })
              .eq('id', step.id)
          )
        );

        onStepsChange(newSteps);
      } catch (error) {
        console.error('Error updating step order:', error);
      }
    }
  }

  async function uploadVoicemail(file: File | Blob): Promise<string> {
    const fileExt = file instanceof File ? file.name.split('.').pop() : 'webm';
    const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `voicemails/${campaignId}/${fileName}`;

    try {
      const { error: uploadError, data: uploadData } = await supabase.storage
        .from('campaign-files')
        .upload(filePath, file, {
          onUploadProgress: (progress) => {
            setUploadProgress((progress.loaded / progress.total) * 100);
          },
        });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('campaign-files')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading voicemail:', error);
      throw error;
    }
  }

  async function handleAddStep(e: React.FormEvent) {
    e.preventDefault();

    try {
      let voicemailUrl = '';
      if (formData.type === 'voicemail' && (voicemailFile || recordingBlob)) {
        voicemailUrl = await uploadVoicemail(voicemailFile || recordingBlob!);
      }

      const { data, error } = await supabase
        .from('campaign_steps')
        .insert([{
          campaign_id: campaignId,
          type: formData.type,
          delay_hours: formData.delay_hours,
          subject: formData.type === 'email' ? formData.subject : null,
          content: formData.content,
          order_number: steps.length + 1,
          voicemail_url: voicemailUrl || null,
        }])
        .select()
        .single();

      if (error) throw error;

      onStepsChange([...steps, data]);
      setShowAddModal(false);
      setFormData({
        type: 'email',
        delay_hours: 0,
        subject: '',
        content: '',
      });
      setVoicemailFile(null);
      setRecordingBlob(null);
      setUploadProgress(0);
    } catch (error) {
      console.error('Error adding step:', error);
    }
  }

  async function handleDeleteStep(stepId: string) {
    if (!window.confirm('Are you sure you want to delete this step?')) {
      return;
    }

    try {
      // Get the step to check if it has a voicemail file
      const stepToDelete = steps.find(step => step.id === stepId);
      
      // Delete the voicemail file if it exists
      if (stepToDelete?.voicemail_url) {
        const urlParts = stepToDelete.voicemail_url.split('/');
        const filePath = urlParts[urlParts.length - 1];
        
        const { error: storageError } = await supabase.storage
          .from('campaign-files')
          .remove([`voicemails/${campaignId}/${filePath}`]);

        if (storageError) {
          console.error('Error deleting voicemail file:', storageError);
        }
      }

      // Delete the step from the database
      const { error } = await supabase
        .from('campaign_steps')
        .delete()
        .eq('id', stepId);

      if (error) throw error;

      // Update the order numbers for remaining steps
      const updatedSteps = steps
        .filter(step => step.id !== stepId)
        .map((step, index) => ({
          ...step,
          order_number: index + 1,
        }));

      // Update order numbers in the database
      await Promise.all(
        updatedSteps.map(step =>
          supabase
            .from('campaign_steps')
            .update({ order_number: step.order_number })
            .eq('id', step.id)
        )
      );

      onStepsChange(updatedSteps);
    } catch (error) {
      console.error('Error deleting step:', error);
    }
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setRecordingBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  }

  function stopRecording() {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  }

  function handleAddMessage(type: 'text' | 'email' | 'voicemail') {
    setFormData({
      ...formData,
      type,
    });
    setShowAddModal(true);
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-medium">Campaign Steps</h3>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700"
        >
          <Plus className="h-4 w-4" />
          Add Step
        </button>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={steps.map(step => step.id)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-4">
            {steps.map((step) => (
              <SortableStep
                key={step.id}
                step={step}
                onDelete={() => handleDeleteStep(step.id)}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      {/* Add Step Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">Add Campaign Step</h2>
            <form onSubmit={handleAddStep}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Type</label>
                  <div className="mt-1 flex gap-4">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, type: 'email' })}
                      className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg ${
                        formData.type === 'email'
                          ? 'bg-indigo-100 text-indigo-700 border-2 border-indigo-500'
                          : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                      }`}
                    >
                      <Mail className="h-4 w-4" />
                      Email
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, type: 'text' })}
                      className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg ${
                        formData.type === 'text'
                          ? 'bg-indigo-100 text-indigo-700 border-2 border-indigo-500'
                          : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                      }`}
                    >
                      <MessageSquare className="h-4 w-4" />
                      Text
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, type: 'voicemail' })}
                      className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg ${
                        formData.type === 'voicemail'
                          ? 'bg-indigo-100 text-indigo-700 border-2 border-indigo-500'
                          : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                      }`}
                    >
                      <Voicemail className="h-4 w-4" />
                      Voicemail
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Delay (hours)</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.delay_hours}
                    onChange={(e) => setFormData({ ...formData, delay_hours: parseInt(e.target.value) })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                {formData.type === 'email' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Subject</label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                )}
                {formData.type === 'voicemail' ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Upload Voicemail</label>
                      <input
                        type="file"
                        accept="audio/*"
                        onChange={(e) => {
                          setVoicemailFile(e.target.files?.[0] || null);
                          setRecordingBlob(null);
                        }}
                        className="mt-1 block w-full text-sm text-gray-500
                          file:mr-4 file:py-2 file:px-4
                          file:rounded-md file:border-0
                          file:text-sm file:font-medium
                          file:bg-indigo-50 file:text-indigo-700
                          hover:file:bg-indigo-100"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Or Record Voicemail</label>
                      <div className="flex items-center gap-4">
                        {!isRecording ? (
                          <button
                            type="button"
                            onClick={startRecording}
                            disabled={!!voicemailFile}
                            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
                          >
                            <Mic className="h-4 w-4" />
                            Start Recording
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={stopRecording}
                            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                          >
                            <Square className="h-4 w-4" />
                            Stop Recording
                          </button>
                        )}
                        {recordingBlob && (
                          <audio src={URL.createObjectURL(recordingBlob)} controls className="flex-1" />
                        )}
                      </div>
                    </div>
                    {(voicemailFile || recordingBlob) && uploadProgress > 0 && uploadProgress < 100 && (
                      <div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-indigo-600 h-2 rounded-full"
                            style={{ width: `${uploadProgress}%` }}
                          />
                        </div>
                        <p className="mt-1 text-sm text-gray-500">
                          Uploading: {uploadProgress.toFixed(0)}%
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Content</label>
                    <textarea
                      rows={4}
                      value={formData.content}
                      onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    />
                  </div>
                )}
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setVoicemailFile(null);
                    setRecordingBlob(null);
                    if (isRecording) {
                      stopRecording();
                    }
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    formData.type === 'voicemail'
                      ? (!voicemailFile && !recordingBlob) || uploadProgress > 0
                      : !formData.content
                  }
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md disabled:opacity-50"
                >
                  {uploadProgress > 0 ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    'Add Step'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}