import express from 'express';
import cors from 'cors';
import { supabase } from '../lib/supabase';
import { runStageAutomations } from '../lib/automations';
import { getOpenAIInstance } from '../lib/openai';

const app = express();

app.use(cors());
app.use(express.json());

// Watch for deal stage changes
supabase
  .channel('deal_stage_changes')
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'deals',
      filter: 'stage_id IS NOT NULL'
    },
    async (payload) => {
      try {
        // Get full deal details
        const { data: deal } = await supabase
          .from('deals')
          .select(`
            *,
            stage:pipeline_stages(*),
            contact:contacts(
              id,
              first_name,
              last_name,
              email
            ),
            company:companies(
              id,
              name
            )
          `)
          .eq('id', payload.new.id)
          .single();

        if (!deal) return;

        // Get user details
        const { data: user } = await supabase
          .from('users')
          .select('id, email')
          .eq('id', deal.owner_id)
          .single();

        if (!user) return;

        // Run stage automations
        await runStageAutomations({
          deal,
          stage: deal.stage,
          user
        });

      } catch (error) {
        console.error('Error running automations:', error);
      }
    }
  )
  .subscribe();

// Watch for campaign status changes
supabase
  .channel('campaign_status_changes')
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'campaigns',
      filter: 'status=active'
    },
    async (payload) => {
      try {
        // Get campaign details
        const { data: campaign } = await supabase
          .from('campaigns')
          .select(`
            *,
            steps:campaign_steps(*)
          `)
          .eq('id', payload.new.id)
          .single();

        if (!campaign) return;

        // Process campaign contacts
        const { data: contacts } = await supabase
          .from('campaign_contacts')
          .select('*')
          .eq('campaign_id', campaign.id)
          .eq('status', 'pending');

        if (!contacts) return;

        // Start campaign for each contact
        for (const contact of contacts) {
          await supabase
            .from('campaign_contacts')
            .update({
              status: 'in_progress',
              started_at: new Date().toISOString()
            })
            .eq('id', contact.id);
        }

      } catch (error) {
        console.error('Error processing campaign:', error);
      }
    }
  )
  .subscribe();

// Process campaign steps
setInterval(async () => {
  try {
    // Get active campaigns
    const { data: campaigns } = await supabase
      .from('campaigns')
      .select('*')
      .eq('status', 'active');

    if (!campaigns) return;

    for (const campaign of campaigns) {
      // Get contacts in progress
      const { data: contacts } = await supabase
        .from('campaign_contacts')
        .select(`
          *,
          contact:contacts(*)
        `)
        .eq('campaign_id', campaign.id)
        .eq('status', 'in_progress');

      if (!contacts) continue;

      // Get campaign steps
      const { data: steps } = await supabase
        .from('campaign_steps')
        .select('*')
        .eq('campaign_id', campaign.id)
        .order('order_number');

      if (!steps) continue;

      // Process each contact
      for (const contact of contacts) {
        const currentStep = steps[contact.current_step];
        if (!currentStep) {
          // No more steps, mark as completed
          await supabase
            .from('campaign_contacts')
            .update({
              status: 'completed',
              completed_at: new Date().toISOString()
            })
            .eq('id', contact.id);
          continue;
        }

        // Check if it's time to execute the step
        const startedAt = new Date(contact.started_at);
        const executeAt = new Date(startedAt.getTime() + (currentStep.delay_hours * 60 * 60 * 1000));
        
        if (new Date() >= executeAt) {
          // Execute the step
          try {
            switch (currentStep.type) {
              case 'email':
                // Send email
                break;
              case 'sms':
                // Send SMS
                break;
              case 'voicemail':
                // Send voicemail
                break;
            }

            // Update contact progress
            await supabase
              .from('campaign_contacts')
              .update({
                current_step: contact.current_step + 1,
                status: contact.current_step === steps.length - 1 ? 'completed' : 'in_progress',
                completed_at: contact.current_step === steps.length - 1 ? new Date().toISOString() : null
              })
              .eq('id', contact.id);

          } catch (error) {
            console.error('Error executing campaign step:', error);
            
            // Mark contact as failed
            await supabase
              .from('campaign_contacts')
              .update({
                status: 'failed'
              })
              .eq('id', contact.id);
          }
        }
      }
    }
  } catch (error) {
    console.error('Error processing campaigns:', error);
  }
}, 60000); // Check every minute

const PORT = process.env.AUTOMATION_SERVICE_PORT || 3001;
app.listen(PORT, () => {
  console.log(`Automation service running on port ${PORT}`);
});