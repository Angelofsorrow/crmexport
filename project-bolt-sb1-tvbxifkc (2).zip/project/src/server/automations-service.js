import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { runStageAutomations } from '../lib/automations.js';
import { supabase } from '../lib/supabase.ts';

// Load environment variables
dotenv.config();

const app = express();

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json());

// Watch for deal stage changes
supabase
  .channel('deal_stage_changes')
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'deals',
      filter: 'stage_id IS NOT NULL'
    },
    async (payload) => {
      try {
        // Get full deal details
        const { data: deal } = await supabase
          .from('deals')
          .select(`
            *,
            stage:pipeline_stages(*),
            contact:contacts(
              id,
              first_name,
              last_name,
              email
            ),
            company:companies(
              id,
              name
            )
          `)
          .eq('id', payload.new.id)
          .single();

        if (!deal) return;

        // Get user details
        const { data: user } = await supabase
          .from('users')
          .select('id, email')
          .eq('id', deal.owner_id)
          .single();

        if (!user) return;

        // Run stage automations
        await runStageAutomations({
          deal,
          stage: deal.stage,
          user
        });

      } catch (error) {
        console.error('Error running automations:', error);
      }
    }
  )
  .subscribe();

// Health check endpoint
app.get('/', (req, res) => {
  res.json({ status: 'Automations service is running' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Automations service running on port ${PORT}`);
});