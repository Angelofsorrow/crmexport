import express from 'express';
import cors from 'cors';
import nodemailer from 'nodemailer';
import * as Imap from 'imap';
import { simpleParser } from 'mailparser';
import { supabase } from '../lib/supabase';

const app = express();

app.use(cors());
app.use(express.json());

// Email sending endpoint
app.post('/send', async (req, res) => {
  try {
    const { account, to, cc, bcc, subject, body, attachments } = req.body;

    const transporter = nodemailer.createTransport({
      host: account.smtp_host,
      port: account.smtp_port,
      secure: account.smtp_port === 465,
      auth: {
        user: account.username,
        pass: account.password,
      },
    });

    const info = await transporter.sendMail({
      from: `"${account.display_name}" <${account.email}>`,
      to: to.join(','),
      cc: cc?.join(','),
      bcc: bcc?.join(','),
      subject,
      html: body,
      attachments,
    });

    // Store sent message in database
    const { error } = await supabase.from('messages').insert([{
      type: 'email',
      direction: 'outbound',
      status: 'sent',
      subject,
      body,
      from_email: account.email,
      from_name: account.display_name,
      to_email: to,
      cc_email: cc,
      bcc_email: bcc,
      sent_at: new Date().toISOString(),
      email_account_id: account.id,
    }]);

    if (error) throw error;

    res.json({ messageId: info.messageId });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send email' });
  }
});

// Email sync endpoint
app.post('/sync', async (req, res) => {
  try {
    const { account } = req.body;

    const imap = new Imap({
      user: account.username,
      password: account.password,
      host: account.imap_host,
      port: account.imap_port,
      tls: account.imap_port === 993,
    });

    function openInbox(cb: (err: Error, box: Imap.Box) => void) {
      imap.openBox('INBOX', false, cb);
    }

    imap.once('ready', () => {
      openInbox(async (err, box) => {
        if (err) throw err;

        // Search for messages from the last sync
        const lastSync = account.last_sync_at || new Date(Date.now() - 24 * 60 * 60 * 1000);
        const searchCriteria = ['SINCE', lastSync];

        imap.search(searchCriteria, (err, results) => {
          if (err) throw err;

          const fetch = imap.fetch(results, {
            bodies: '',
            struct: true,
          });

          fetch.on('message', (msg) => {
            msg.on('body', async (stream) => {
              const parsed = await simpleParser(stream);

              // Store message in database
              await supabase.from('messages').insert([{
                type: 'email',
                direction: 'inbound',
                status: 'received',
                subject: parsed.subject,
                body: parsed.html || parsed.textAsHtml,
                from_email: parsed.from?.value[0].address,
                from_name: parsed.from?.value[0].name,
                to_email: parsed.to?.value.map(addr => addr.address),
                cc_email: parsed.cc?.value.map(addr => addr.address),
                message_id: parsed.messageId,
                in_reply_to: parsed.inReplyTo,
                received_at: parsed.date,
                email_account_id: account.id,
              }]);
            });
          });

          fetch.once('error', (err) => {
            console.error('Fetch error:', err);
          });

          fetch.once('end', () => {
            console.log('Done fetching messages');
            imap.end();
          });
        });
      });
    });

    imap.once('error', (err) => {
      console.error('IMAP error:', err);
    });

    imap.once('end', async () => {
      // Update last sync time
      await supabase
        .from('email_accounts')
        .update({ last_sync_at: new Date().toISOString() })
        .eq('id', account.id);

      console.log('Connection ended');
    });

    imap.connect();

    res.json({ success: true });
  } catch (error) {
    console.error('Error syncing emails:', error);
    res.status(500).json({ error: 'Failed to sync emails' });
  }
});

const PORT = process.env.EMAIL_SERVICE_PORT || 3000;
app.listen(PORT, () => {
  console.log(`Email service running on port ${PORT}`);
});