import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Get directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from root .env file
dotenv.config({ path: join(__dirname, '../../.env') });

// Initialize Supabase client
const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.VITE_OPENAI_API_KEY
});

const app = express();

// Enable CORS with proper configuration
app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  methods: ['GET', 'POST'],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ 
    error: err.message || 'An unexpected error occurred',
    details: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

// Auth middleware
async function authMiddleware(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ error: 'No authorization header' });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
}

// Root endpoint
app.get('/', (req, res) => {
  res.json({ status: 'AI Agent is running' });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'AI Agent is running' });
});

// Process automation requests
app.post('/process', authMiddleware, async (req, res) => {
  try {
    const { type, data, eventDetails } = req.body;
    const user = req.user;

    if (!type) {
      return res.status(400).json({ error: 'Automation type is required' });
    }

    if (!data && !eventDetails) {
      return res.status(400).json({ error: 'Either data or eventDetails must be provided' });
    }

    let result;
    switch (type) {
      case 'create_event':
        result = await createCalendarEvent(eventDetails, user);
        break;
      case 'send_email':
        result = await sendEmailToContact(data, user);
        break;
      case 'generate_document':
        result = await generateDocument(data, user);
        break;
      default:
        return res.status(400).json({ error: `Unknown automation type: ${type}` });
    }

    res.json(result);
  } catch (error) {
    console.error('Error processing automation:', error);
    res.status(500).json({ error: error.message });
  }
});

async function createCalendarEvent(eventDetails, user) {
  try {
    // Validate required fields
    if (!eventDetails?.title || !eventDetails?.startTime) {
      throw new Error('Missing required event details: title and startTime are required');
    }

    // Create calendar event
    const { error: eventError } = await supabase
      .from('calendar_events')
      .insert([{
        title: eventDetails.title,
        description: eventDetails.description,
        start: eventDetails.startTime,
        end: eventDetails.endTime || eventDetails.startTime,
        location: eventDetails.location,
        source: 'ai_agent',
        owner_id: user.id,
        all_day: false,
        status: 'confirmed',
        attendees: eventDetails.attendees || []
      }]);

    if (eventError) {
      console.error('Error creating calendar event:', eventError);
      throw new Error('Failed to create calendar event');
    }

    // Create activity record
    const { error: activityError } = await supabase
      .from('activities')
      .insert([{
        type: 'event',
        title: eventDetails.title,
        description: eventDetails.description,
        due_date: eventDetails.startTime,
        owner_id: user.id
      }]);

    if (activityError) {
      console.error('Error creating activity record:', activityError);
      throw new Error('Failed to create activity record');
    }

    return { success: true, message: 'Calendar event created successfully' };
  } catch (error) {
    console.error('Error in createCalendarEvent:', error);
    throw error;
  }
}

async function sendEmailToContact(data, user) {
  try {
    const { to, subject, content } = data;
    if (!to || !subject || !content) {
      throw new Error('Missing required email fields');
    }

    // Get user's email account
    const { data: emailAccount } = await supabase
      .from('email_accounts')
      .select('*')
      .eq('owner_id', user.id)
      .eq('is_active', true)
      .single();

    if (!emailAccount) {
      throw new Error('No active email account found');
    }

    // Create activity record
    const { error: activityError } = await supabase
      .from('activities')
      .insert([{
        type: 'email',
        title: `Email: ${subject}`,
        description: content,
        owner_id: user.id,
        completed_at: new Date().toISOString()
      }]);

    if (activityError) throw activityError;

    return { success: true, message: 'Email sent successfully' };
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
}

async function generateDocument(data, user) {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a document generator. Generate a ${data.documentType} using the following template: ${data.template}`
        }
      ]
    });

    const documentContent = completion.choices[0].message.content;
    const fileName = `${data.title || 'Generated Document'}-${Date.now()}.txt`;
    const filePath = `documents/${user.id}/${fileName}`;

    // Save document metadata
    const { error: docError } = await supabase
      .from('documents')
      .insert([{
        name: data.title || 'Generated Document',
        file_path: filePath,
        file_type: 'text/plain',
        size: documentContent.length,
        owner_id: user.id
      }]);

    if (docError) throw docError;

    return { 
      success: true, 
      message: 'Document generated successfully',
      content: documentContent
    };
  } catch (error) {
    console.error('Error generating document:', error);
    throw error;
  }
}

const PORT = process.env.AI_AGENT_PORT || 3004;

// Start server with error handling
const server = app.listen(PORT, () => {
  console.log(`AI agent running on port ${PORT}`);
}).on('error', (error) => {
  console.error('Failed to start server:', error);
  if (error.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use`);
  }
  process.exit(1);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  server.close(() => {
    process.exit(1);
  });
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});