import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { format, subDays } from 'date-fns';
import { Building2, Users, BadgeDollarSign, TrendingUp, ArrowUpRight, ArrowDownRight, Calendar, FileText, ChevronRight, ChevronDown, ChevronUp, Star } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, LineChart, Line } from 'recharts';
import ReviewsManager from '../components/ReviewsManager';

interface DashboardStats {
  deals: {
    total: number;
    won: number;
    open: number;
    lost: number;
    value: {
      total: number;
      won: number;
      open: number;
      lost: number;
    };
  };
  campaigns: {
    total: number;
    active: number;
    sources: string[];
    stages: {
      name: string;
      count: number;
      value: number;
      percentage: number;
    }[];
  };
  activities: {
    total: number;
    completed: number;
    overdue: number;
    upcoming: number;
  };
  performance: {
    deals_closed: number;
    revenue_generated: number;
    meetings_scheduled: number;
    tasks_completed: number;
    change: {
      deals: number;
      revenue: number;
      meetings: number;
      tasks: number;
    };
  };
  reviews: {
    total: number;
    pending: number;
    approved: number;
    rejected: number;
    average_rating: number;
  };
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    deals: {
      total: 0,
      won: 0,
      open: 0,
      lost: 0,
      value: {
        total: 0,
        won: 0,
        open: 0,
        lost: 0
      }
    },
    campaigns: {
      total: 0,
      active: 0,
      sources: [],
      stages: []
    },
    activities: {
      total: 0,
      completed: 0,
      overdue: 0,
      upcoming: 0
    },
    performance: {
      deals_closed: 0,
      revenue_generated: 0,
      meetings_scheduled: 0,
      tasks_completed: 0,
      change: {
        deals: 0,
        revenue: 0,
        meetings: 0,
        tasks: 0
      }
    },
    reviews: {
      total: 0,
      pending: 0,
      approved: 0,
      rejected: 0,
      average_rating: 0
    }
  });
  const [loading, setLoading] = useState(true);
  const [selectedTimeframe, setSelectedTimeframe] = useState('week');
  const [showReviews, setShowReviews] = useState(false);

  useEffect(() => {
    fetchDashboardStats();
  }, [selectedTimeframe]);

  async function fetchDashboardStats() {
    try {
      // Fetch deals statistics
      const { data: deals } = await supabase
        .from('deals')
        .select('status, stage, amount, created_at');

      const dealsStats = {
        total: deals?.length || 0,
        won: deals?.filter(d => d.status === 'won').length || 0,
        open: deals?.filter(d => d.status === 'open').length || 0,
        lost: deals?.filter(d => d.status === 'lost').length || 0,
        value: {
          total: deals?.reduce((sum, d) => sum + (d.amount || 0), 0) || 0,
          won: deals?.filter(d => d.status === 'won').reduce((sum, d) => sum + (d.amount || 0), 0) || 0,
          open: deals?.filter(d => d.status === 'open').reduce((sum, d) => sum + (d.amount || 0), 0) || 0,
          lost: deals?.filter(d => d.status === 'lost').reduce((sum, d) => sum + (d.amount || 0), 0) || 0
        }
      };

      // Fetch activities statistics
      const { data: activities } = await supabase
        .from('activities')
        .select('type, completed_at, due_date');

      const activitiesStats = {
        total: activities?.length || 0,
        completed: activities?.filter(a => a.completed_at).length || 0,
        overdue: activities?.filter(a => !a.completed_at && new Date(a.due_date) < new Date()).length || 0,
        upcoming: activities?.filter(a => !a.completed_at && new Date(a.due_date) >= new Date()).length || 0
      };

      // Fetch reviews statistics
      const { data: reviews } = await supabase
        .from('reviews')
        .select('status, rating');

      const reviewsStats = {
        total: reviews?.length || 0,
        pending: reviews?.filter(r => r.status === 'pending').length || 0,
        approved: reviews?.filter(r => r.status === 'approved').length || 0,
        rejected: reviews?.filter(r => r.status === 'rejected').length || 0,
        average_rating: reviews?.length 
          ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length 
          : 0
      };

      // Calculate performance metrics
      const now = new Date();
      const timeframeStart = selectedTimeframe === 'week' ? subDays(now, 7) : subDays(now, 30);
      const previousTimeframeStart = selectedTimeframe === 'week' ? subDays(timeframeStart, 7) : subDays(timeframeStart, 30);

      const currentDeals = deals?.filter(d => new Date(d.created_at) >= timeframeStart) || [];
      const previousDeals = deals?.filter(d => new Date(d.created_at) >= previousTimeframeStart && new Date(d.created_at) < timeframeStart) || [];

      const performanceStats = {
        deals_closed: currentDeals.filter(d => d.status === 'won').length,
        revenue_generated: currentDeals.filter(d => d.status === 'won').reduce((sum, d) => sum + (d.amount || 0), 0),
        meetings_scheduled: activities?.filter(a => a.type === 'meeting' && new Date(a.created_at) >= timeframeStart).length || 0,
        tasks_completed: activities?.filter(a => a.type === 'task' && a.completed_at && new Date(a.completed_at) >= timeframeStart).length || 0,
        change: {
          deals: calculatePercentageChange(
            currentDeals.filter(d => d.status === 'won').length,
            previousDeals.filter(d => d.status === 'won').length
          ),
          revenue: calculatePercentageChange(
            currentDeals.filter(d => d.status === 'won').reduce((sum, d) => sum + (d.amount || 0), 0),
            previousDeals.filter(d => d.status === 'won').reduce((sum, d) => sum + (d.amount || 0), 0)
          ),
          meetings: 15, // Example value
          tasks: 8 // Example value
        }
      };

      setStats({
        deals: dealsStats,
        campaigns: {
          total: 10, // Example values
          active: 4,
          sources: ['Website', 'Email', 'Social', 'Referral'],
          stages: [
            { name: 'New', count: 25, value: 50000, percentage: 25 },
            { name: 'Contacted', count: 30, value: 75000, percentage: 30 },
            { name: 'Qualified', count: 20, value: 100000, percentage: 20 },
            { name: 'Proposal', count: 15, value: 125000, percentage: 15 },
            { name: 'Negotiation', count: 10, value: 150000, percentage: 10 }
          ]
        },
        activities: activitiesStats,
        performance: performanceStats,
        reviews: reviewsStats
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  }

  function calculatePercentageChange(current: number, previous: number): number {
    if (previous === 0) return current > 0 ? 100 : 0;
    return Math.round(((current - previous) / previous) * 100);
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  // Sample data for charts
  const revenueData = [
    { name: 'Mon', value: 4000 },
    { name: 'Tue', value: 3000 },
    { name: 'Wed', value: 2000 },
    { name: 'Thu', value: 2780 },
    { name: 'Fri', value: 1890 },
    { name: 'Sat', value: 2390 },
    { name: 'Sun', value: 3490 }
  ];

  const dealsByStageData = [
    { name: 'Prospecting', value: 20 },
    { name: 'Qualification', value: 15 },
    { name: 'Proposal', value: 10 },
    { name: 'Negotiation', value: 5 },
    { name: 'Closing', value: 3 }
  ];

  const activityTrendData = [
    { name: '1', completed: 4, total: 5 },
    { name: '2', completed: 3, total: 6 },
    { name: '3', completed: 5, total: 7 },
    { name: '4', completed: 6, total: 8 },
    { name: '5', completed: 4, total: 6 },
    { name: '6', completed: 7, total: 9 },
    { name: '7', completed: 8, total: 10 }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">
            Overview of your sales and activities
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedTimeframe('week')}
              className={`px-3 py-1 text-sm rounded-md ${
                selectedTimeframe === 'week'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              This Week
            </button>
            <button
              onClick={() => setSelectedTimeframe('month')}
              className={`px-3 py-1 text-sm rounded-md ${
                selectedTimeframe === 'month'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              This Month
            </button>
          </div>
          <button
            onClick={() => setShowReviews(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          >
            <Star className="h-4 w-4" />
            Manage Reviews
            {stats.reviews.pending > 0 && (
              <span className="ml-1 px-2 py-0.5 text-xs bg-yellow-100 text-yellow-800 rounded-full">
                {stats.reviews.pending}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-5 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <BadgeDollarSign className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Deals Closed</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats.performance.deals_closed}</h3>
              </div>
            </div>
            <div className={`flex items-center ${stats.performance.change.deals >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {stats.performance.change.deals >= 0 ? (
                <ArrowUpRight className="h-4 w-4" />
              ) : (
                <ArrowDownRight className="h-4 w-4" />
              )}
              <span className="text-sm font-medium">{Math.abs(stats.performance.change.deals)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Revenue</p>
                <h3 className="text-2xl font-bold text-gray-900">
                  {new Intl.NumberFormat('en-US', {
                    style: 'currency',
                    currency: 'USD',
                    notation: 'compact',
                    maximumFractionDigits: 1,
                  }).format(stats.performance.revenue_generated)}
                </h3>
              </div>
            </div>
            <div className={`flex items-center ${stats.performance.change.revenue >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {stats.performance.change.revenue >= 0 ? (
                <ArrowUpRight className="h-4 w-4" />
              ) : (
                <ArrowDownRight className="h-4 w-4" />
              )}
              <span className="text-sm font-medium">{Math.abs(stats.performance.change.revenue)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Meetings</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats.performance.meetings_scheduled}</h3>
              </div>
            </div>
            <div className={`flex items-center ${stats.performance.change.meetings >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {stats.performance.change.meetings >= 0 ? (
                <ArrowUpRight className="h-4 w-4" />
              ) : (
                <ArrowDownRight className="h-4 w-4" />
              )}
              <span className="text-sm font-medium">{Math.abs(stats.performance.change.meetings)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <FileText className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Tasks</p>
                <h3 className="text-2xl font-bold text-gray-900">{stats.performance.tasks_completed}</h3>
              </div>
            </div>
            <div className={`flex items-center ${stats.performance.change.tasks >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {stats.performance.change.tasks >= 0 ? (
                <ArrowUpRight className="h-4 w-4" />
              ) : (
                <ArrowDownRight className="h-4 w-4" />
              )}
              <span className="text-sm font-medium">{Math.abs(stats.performance.change.tasks)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Star className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Reviews</p>
                <h3 className="text-2xl font-bold text-gray-900">
                  {stats.reviews.average_rating.toFixed(1)}
                  <span className="text-sm text-gray-500 ml-1">
                    ({stats.reviews.total})
                  </span>
                </h3>
              </div>
            </div>
            <div className="flex flex-col items-end text-xs">
              <span className="text-yellow-600">{stats.reviews.pending} pending</span>
              <span className="text-green-600">{stats.reviews.approved} approved</span>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-6">
        {/* Revenue Trend */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Revenue Trend</h3>
            <button className="text-gray-400 hover:text-gray-600">
              <ChevronDown className="h-5 w-5" />
            </button>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis data

Key="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="value" stroke="#4F46E5" fill="#EEF2FF" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Deals by Stage */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Deals by Stage</h3>
            <button className="text-gray-400 hover:text-gray-600">
              <ChevronDown className="h-5 w-5" />
            </button>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dealsByStageData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#4F46E5" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Activity Completion */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Activity Completion</h3>
            <button className="text-gray-400 hover:text-gray-600">
              <ChevronDown className="h-5 w-5" />
            </button>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={activityTrendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="completed" stroke="#4F46E5" />
                <Line type="monotone" dataKey="total" stroke="#818CF8" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Campaign Performance */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Campaign Performance</h3>
            <div className="flex items-center gap-2">
              <select
                className="text-sm border-gray-300 rounded-md"
                defaultValue="all"
              >
                <option value="all">All Campaigns</option>
                {stats.campaigns.sources.map(source => (
                  <option key={source} value={source}>{source}</option>
                ))}
              </select>
              <button className="text-gray-400 hover:text-gray-600">
                <ChevronDown className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="space-y-4">
            {stats.campaigns.stages.map((stage) => (
              <div key={stage.name}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">{stage.name}</span>
                  <span className="font-medium text-gray-900">{stage.percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full"
                    style={{ width: `${stage.percentage}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>{stage.count} contacts</span>
                  <span>
                    {new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: 'USD',
                      notation: 'compact',
                    }).format(stage.value)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reviews Management Modal */}
      {showReviews && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex-1 overflow-auto">
              <ReviewsManager />
            </div>
            <div className="p-4 border-t bg-gray-50">
              <button
                onClick={() => setShowReviews(false)}
                className="w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}