import React, { useState, useEffect } from 'react';
import { Plus, Search, Trash2, Star, Reply, Forward, Mail, MessageSquare, Phone, Settings } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { sendEmail, syncEmails } from '../lib/email';

interface Message {
  id: string;
  type: 'email' | 'text' | 'call';
  direction: 'inbound' | 'outbound';
  status: string;
  subject: string;
  body: string;
  from_email: string;
  from_name: string;
  from_phone: string;
  to_email: string[];
  to_phone: string;
  sent_at: string;
  received_at: string;
  read_at: string | null;
  contact?: {
    first_name: string;
    last_name: string;
  };
}

interface EmailAccount {
  id: string;
  email: string;
  display_name: string;
  imap_host: string;
  imap_port: number;
  smtp_host: string;
  smtp_port: number;
  username: string;
  password: string;
}

export default function Inbox() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [emailAccounts, setEmailAccounts] = useState<EmailAccount[]>([]);
  const [newEmailAccount, setNewEmailAccount] = useState({
    email: '',
    display_name: '',
    imap_host: '',
    imap_port: 993,
    smtp_host: '',
    smtp_port: 587,
    username: '',
    password: '',
  });

  useEffect(() => {
    fetchMessages();
    fetchEmailAccounts();
  }, []);

  async function fetchMessages() {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          contact:contacts(first_name, last_name)
        `)
        .order('received_at', { ascending: false });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchEmailAccounts() {
    try {
      const { data, error } = await supabase
        .from('email_accounts')
        .select('*')
        .order('created_at');

      if (error) throw error;
      setEmailAccounts(data || []);
    } catch (error) {
      console.error('Error fetching email accounts:', error);
    }
  }

  async function handleAddEmailAccount(e: React.FormEvent) {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('email_accounts')
        .insert([newEmailAccount]);

      if (error) throw error;

      setShowSettings(false);
      fetchEmailAccounts();
      setNewEmailAccount({
        email: '',
        display_name: '',
        imap_host: '',
        imap_port: 993,
        smtp_host: '',
        smtp_port: 587,
        username: '',
        password: '',
      });
    } catch (error) {
      console.error('Error adding email account:', error);
    }
  }

  async function handleSync() {
    try {
      setLoading(true);
      for (const account of emailAccounts) {
        await syncEmails(account);
      }
      fetchMessages();
    } catch (error) {
      console.error('Error syncing emails:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleMarkAsRead(message: Message) {
    if (message.read_at) return;

    try {
      const { error } = await supabase
        .from('messages')
        .update({ read_at: new Date().toISOString() })
        .eq('id', message.id);

      if (error) throw error;
      fetchMessages();
    } catch (error) {
      console.error('Error marking message as read:', error);
    }
  }

  function getMessageIcon(type: string) {
    switch (type) {
      case 'email':
        return <Mail className="h-5 w-5 text-blue-500" />;
      case 'text':
        return <MessageSquare className="h-5 w-5 text-green-500" />;
      case 'call':
        return <Phone className="h-5 w-5 text-purple-500" />;
      default:
        return null;
    }
  }

  async function handleGoogleAuth() {
    window.location.href = 'http://localhost:3000/auth/google';
  }

  async function handleMicrosoftAuth() {
    window.location.href = 'http://localhost:3000/auth/microsoft';
  }

  const filteredMessages = messages.filter(message =>
    message.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.body?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.from_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.from_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.contact?.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.contact?.last_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-full flex">
      {/* Message List */}
      <div className="w-1/3 border-r border-gray-200 bg-white">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Inbox</h2>
            <div className="flex items-center gap-2">
              <button
                onClick={handleSync}
                className="p-2 text-gray-500 hover:text-gray-700 rounded-lg"
                title="Sync messages"
              >
                <Mail className="h-5 w-5" />
              </button>
              <button
                onClick={() => setShowSettings(true)}
                className="p-2 text-gray-500 hover:text-gray-700 rounded-lg"
                title="Settings"
              >
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="overflow-auto h-[calc(100vh-8rem)]">
          {loading ? (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredMessages.map((message) => (
                <div
                  key={message.id}
                  className={`p-4 cursor-pointer hover:bg-gray-50 ${
                    selectedMessage?.id === message.id ? 'bg-gray-50' : ''
                  } ${!message.read_at ? 'font-semibold' : ''}`}
                  onClick={() => {
                    setSelectedMessage(message);
                    handleMarkAsRead(message);
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      {getMessageIcon(message.type)}
                      <div>
                        <div className="text-sm">
                          {message.from_name || message.from_email || message.from_phone}
                        </div>
                        <div className="text-sm font-medium text-gray-900">
                          {message.subject}
                        </div>
                        <div className="text-sm text-gray-500 line-clamp-1">
                          {message.body?.replace(/<[^>]*>/g, '')}
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {format(new Date(message.received_at), 'MMM d, h:mm a')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Message View */}
      <div className="flex-1 bg-white">
        {selectedMessage ? (
          <div className="h-full flex flex-col">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">{selectedMessage.subject}</h2>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-gray-500 hover:text-gray-700 rounded-lg">
                    <Star className="h-5 w-5" />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-gray-700 rounded-lg">
                    <Reply className="h-5 w-5" />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-gray-700 rounded-lg">
                    <Forward className="h-5 w-5" />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-gray-700 rounded-lg">
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm text-gray-500">
                <div>
                  From: {selectedMessage.from_name} {`<${selectedMessage.from_email}>`}
                </div>
                <div>
                  {format(new Date(selectedMessage.received_at), 'MMM d, yyyy h:mm a')}
                </div>
              </div>
              <div className="text-sm text-gray-500">
                To: {selectedMessage.to_email?.join(', ')}
              </div>
            </div>
            <div className="flex-1 p-4 overflow-auto">
              <div dangerouslySetInnerHTML={{ __html: selectedMessage.body }} />
            </div>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500">
            Select a message to view
          </div>
        )}
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">Email Account Settings</h2>
            
            {/* Add OAuth Buttons */}
            <div className="mb-6 space-y-3">
              <button
                onClick={handleGoogleAuth}
                className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
              >
                <img 
                  src="https://www.google.com/favicon.ico" 
                  alt="Google" 
                  className="w-5 h-5"
                />
                Connect Gmail Account
              </button>
              <button
                onClick={handleMicrosoftAuth}
                className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
              >
                <img 
                  src="https://www.microsoft.com/favicon.ico" 
                  alt="Microsoft" 
                  className="w-5 h-5"
                />
                Connect Outlook Account
              </button>
            </div>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Or add email manually</span>
              </div>
            </div>

            <form onSubmit={handleAddEmailAccount}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    value={newEmailAccount.email}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, email: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Display Name</label>
                  <input
                    type="text"
                    value={newEmailAccount.display_name}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, display_name: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">IMAP Host</label>
                  <input
                    type="text"
                    value={newEmailAccount.imap_host}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, imap_host: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">IMAP Port</label>
                  <input
                    type="number"
                    value={newEmailAccount.imap_port}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, imap_port: parseInt(e.target.value) })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">SMTP Host</label>
                  <input
                    type="text"
                    value={newEmailAccount.smtp_host}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, smtp_host: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">SMTP Port</label>
                  <input
                    type="number"
                    value={newEmailAccount.smtp_port}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, smtp_port: parseInt(e.target.value) })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Username</label>
                  <input
                    type="text"
                    value={newEmailAccount.username}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, username: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Password</label>
                  <input
                    type="password"
                    value={newEmailAccount.password}
                    onChange={(e) => setNewEmailAccount({ ...newEmailAccount, password: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowSettings(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  Add Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}