import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import CampaignDetails from '../components/CampaignDetails';
import CampaignTimeline from '../components/CampaignTimeline';

interface Campaign {
  id: string;
  name: string;
  email?: string;
  phone_number?: string;
  timezone?: string;
  status: 'draft' | 'active' | 'paused' | 'completed';
}

interface CampaignStep {
  id: string;
  type: 'text' | 'email' | 'voicemail';
  delay_hours: number;
  subject?: string;
  content: string;
  scheduled_time?: string;
}

export default function CampaignEditor() {
  const { id } = useParams<{ id: string }>();
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [steps, setSteps] = useState<CampaignStep[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchCampaign();
      fetchSteps();
    }
  }, [id]);

  async function fetchCampaign() {
    try {
      const { data, error } = await supabase
        .from('campaigns')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      setCampaign(data);
    } catch (error) {
      console.error('Error fetching campaign:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchSteps() {
    try {
      const { data, error } = await supabase
        .from('campaign_steps')
        .select('*')
        .eq('campaign_id', id)
        .order('order_number');

      if (error) throw error;
      setSteps(data || []);
    } catch (error) {
      console.error('Error fetching steps:', error);
    }
  }

  async function handleStatusChange(campaignId: string, newStatus: 'active' | 'paused') {
    try {
      const { error } = await supabase
        .from('campaigns')
        .update({ status: newStatus })
        .eq('id', campaignId);

      if (error) throw error;
      fetchCampaign();
    } catch (error) {
      console.error('Error updating campaign status:', error);
    }
  }

  async function handleDelete(campaignId: string) {
    if (window.confirm('Are you sure you want to delete this campaign?')) {
      try {
        const { error } = await supabase
          .from('campaigns')
          .delete()
          .eq('id', campaignId);

        if (error) throw error;
        // Navigate back to campaigns list
        window.location.href = '/campaigns';
      } catch (error) {
        console.error('Error deleting campaign:', error);
      }
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-600">Campaign not found</div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <CampaignDetails
        campaign={campaign}
        onDelete={handleDelete}
        onStatusChange={handleStatusChange}
      />
      
      <div className="bg-white rounded-lg shadow p-6">
        <CampaignTimeline
          campaignId={campaign.id}
          steps={steps}
          onStepsChange={setSteps}
        />
      </div>
    </div>
  );
}