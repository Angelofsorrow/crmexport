import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Building2, ChevronUp, ChevronDown, Calendar, Users, FileText, BadgeDollarSign, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import { format } from 'date-fns';
import { calculateMonthlyPayment, calculateLTV, calculateDTI } from '../lib/calculations';
import type { LoanApplication, LoanProduct, Property, Borrower } from '../lib/types';
import LoanApplicationForm from '../components/LoanApplicationForm';

interface LoanApplicationWithDetails extends LoanApplication {
  loan_product: LoanProduct;
  property: Property;
  primary_borrower: Borrower & {
    contact: {
      first_name: string;
      last_name: string;
    };
  };
  co_borrower?: Borrower & {
    contact: {
      first_name: string;
      last_name: string;
    };
  };
}

export default function LoanApplications() {
  const { user } = useAuthStore();
  const [applications, setApplications] = useState<LoanApplicationWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingApplication, setEditingApplication] = useState<LoanApplicationWithDetails | null>(null);
  const [loanProducts, setLoanProducts] = useState<LoanProduct[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [borrowers, setBorrowers] = useState<Borrower[]>([]);

  useEffect(() => {
    fetchApplications();
    fetchLoanProducts();
    fetchProperties();
    fetchBorrowers();
  }, [user]);

  async function fetchApplications() {
    try {
      const { data, error } = await supabase
        .from('loan_applications')
        .select(`
          *,
          loan_product:loan_products(*),
          property:properties(*),
          primary_borrower:borrowers!loan_applications_primary_borrower_id_fkey(
            *,
            contact:contacts(first_name, last_name)
          ),
          co_borrower:borrowers!loan_applications_co_borrower_id_fkey(
            *,
            contact:contacts(first_name, last_name)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      console.error('Error fetching loan applications:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchLoanProducts() {
    try {
      const { data, error } = await supabase
        .from('loan_products')
        .select('*')
        .order('name');

      if (error) throw error;

      // Parse JSON fields
      const parsedProducts = (data || []).map(product => ({
        ...product,
        interest_rate_range: typeof product.interest_rate_range === 'string'
          ? JSON.parse(product.interest_rate_range)
          : product.interest_rate_range,
        term_years: typeof product.term_years === 'string'
          ? JSON.parse(product.term_years)
          : product.term_years,
        requirements: typeof product.requirements === 'string'
          ? JSON.parse(product.requirements)
          : product.requirements,
        eligible_property_types: typeof product.eligible_property_types === 'string'
          ? JSON.parse(product.eligible_property_types)
          : product.eligible_property_types,
        income_limits: typeof product.income_limits === 'string'
          ? JSON.parse(product.income_limits)
          : product.income_limits,
        dti_limits: typeof product.dti_limits === 'string'
          ? JSON.parse(product.dti_limits)
          : product.dti_limits,
        credit_score_ranges: typeof product.credit_score_ranges === 'string'
          ? JSON.parse(product.credit_score_ranges)
          : product.credit_score_ranges
      }));

      console.log('Fetched loan products:', parsedProducts);
      setLoanProducts(parsedProducts);
    } catch (error) {
      console.error('Error fetching loan products:', error);
    }
  }

  async function fetchProperties() {
    try {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      console.log('Fetched properties:', data);
      setProperties(data || []);
    } catch (error) {
      console.error('Error fetching properties:', error);
    }
  }

  async function fetchBorrowers() {
    try {
      const { data, error } = await supabase
        .from('borrowers')
        .select(`
          *,
          contact:contacts(first_name, last_name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      console.log('Fetched borrowers:', data);
      setBorrowers(data || []);
    } catch (error) {
      console.error('Error fetching borrowers:', error);
    }
  }

  async function handleSubmit(data: any) {
    try {
      // Generate a unique loan number
      const loanNumber = `LOAN-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      const formattedData = {
        ...data,
        loan_number: editingApplication ? editingApplication.loan_number : loanNumber,
        owner_id: user?.id,
      };

      let error;
      if (editingApplication) {
        ({ error } = await supabase
          .from('loan_applications')
          .update(formattedData)
          .eq('id', editingApplication.id));
      } else {
        ({ error } = await supabase
          .from('loan_applications')
          .insert([formattedData]));
      }

      if (error) throw error;
      
      setShowModal(false);
      setEditingApplication(null);
      fetchApplications();
    } catch (error) {
      console.error('Error saving loan application:', error);
    }
  }

  async function handleDelete(id: string) {
    if (window.confirm('Are you sure you want to delete this application?')) {
      try {
        const { error } = await supabase
          .from('loan_applications')
          .delete()
          .eq('id', id);

        if (error) throw error;
        fetchApplications();
      } catch (error) {
        console.error('Error deleting loan application:', error);
      }
    }
  }

  function getStatusColor(status: string) {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'denied':
        return 'bg-red-100 text-red-800';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  function getStageColor(stage: string) {
    switch (stage) {
      case 'initial_review':
        return 'bg-blue-100 text-blue-800';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'underwriting':
        return 'bg-purple-100 text-purple-800';
      case 'conditions':
        return 'bg-orange-100 text-orange-800';
      case 'closing_prep':
        return 'bg-green-100 text-green-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  const filteredApplications = applications.filter(app =>
    app.loan_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.primary_borrower.contact.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.primary_borrower.contact.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    app.property.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Loan Applications</h1>
          <div className="mt-1 text-sm text-gray-500">
            {applications.length} total applications
          </div>
        </div>
        <button
          onClick={() => {
            setEditingApplication(null);
            setShowModal(true);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700"
        >
          <Plus className="h-4 w-4" />
          New Application
        </button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search applications..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredApplications.map((application) => (
            <div
              key={application.id}
              className="bg-white rounded-lg shadow p-6"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-medium text-gray-900">
                      Loan #{application.loan_number}
                    </h3>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(application.status)}`}>
                      {application.status}
                    </span>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStageColor(application.stage)}`}>
                      {application.stage.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-x-6 gap-y-2 mt-4">
                    <div>
                      <div className="text-sm font-medium text-gray-500">Borrower</div>
                      <div className="text-sm text-gray-900">
                        {application.primary_borrower.contact.first_name} {application.primary_borrower.contact.last_name}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-gray-500">Property</div>
                      <div className="text-sm text-gray-900">
                        {application.property.address}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-gray-500">Loan Amount</div>
                      <div className="text-sm text-gray-900">
                        {new Intl.NumberFormat('en-US', {
                          style: 'currency',
                          currency: 'USD'
                        }).format(application.loan_amount)}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-gray-500">Monthly Payment</div>
                      <div className="text-sm text-gray-900">
                        {new Intl.NumberFormat('en-US', {
                          style: 'currency',
                          currency: 'USD'
                        }).format(application.estimated_monthly_payment || 0)}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-gray-500">LTV</div>
                      <div className="text-sm text-gray-900">
                        {calculateLTV(
                          application.loan_amount,
                          application.property.purchase_price || application.property.estimated_value || 0
                        ).toFixed(2)}%
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-gray-500">DTI</div>
                      <div className="text-sm text-gray-900">
                        {calculateDTI(
                          application.primary_borrower.monthly_debts || 0,
                          application.primary_borrower.monthly_income || 0
                        ).toFixed(2)}%
                      </div>
                    </div>
                  </div>

                  {application.conditions && application.conditions.length > 0 && (
                    <div className="mt-4">
                      <div className="text-sm font-medium text-gray-500 mb-2">Conditions</div>
                      <div className="space-y-2">
                        {application.conditions.map((condition, index) => (
                          <div
                            key={index}
                            className={`text-sm p-2 rounded-lg ${
                              condition.status === 'cleared'
                                ? 'bg-green-50 text-green-700'
                                : condition.status === 'rejected'
                                ? 'bg-red-50 text-red-700'
                                : 'bg-yellow-50 text-yellow-700'
                            }`}
                          >
                            {condition.description}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setEditingApplication(application);
                      setShowModal(true);
                    }}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    <Edit2 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(application.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Application Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">
                {editingApplication ? 'Edit Loan Application' : 'New Loan Application'}
              </h2>
              <button
                onClick={() => {
                  setShowModal(false);
                  setEditingApplication(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <LoanApplicationForm
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowModal(false);
                setEditingApplication(null);
              }}
              initialData={editingApplication}
              loanProducts={loanProducts}
              properties={properties}
              borrowers={borrowers}
            />
          </div>
        </div>
      )}
    </div>
  );
}