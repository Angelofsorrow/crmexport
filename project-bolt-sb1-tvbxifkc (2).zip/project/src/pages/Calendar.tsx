import React, { useState, useEffect } from 'react';
import { Calendar as BigCalendar, dateFnsLocalizer } from 'react-big-calendar';
import { format, parse, startOfWeek, getDay, addHours } from 'date-fns';
import { enUS } from 'date-fns/locale';
import { supabase } from '../lib/supabase';
import { Settings, RefreshCw, Plus, X, Mail } from 'lucide-react';
import { useAuthStore } from '../store/auth';

// Import styles
import 'react-big-calendar/lib/css/react-big-calendar.css';

const locales = {
  'en-US': enUS,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  description?: string;
  location?: string;
  source: string;
  sourceId?: string;
  allDay?: boolean;
  attendees?: Array<{
    email: string;
    name?: string;
    response?: 'accepted' | 'declined' | 'tentative' | 'needsAction';
  }>;
}

interface EmailAccount {
  id: string;
  email: string;
  provider: string;
  access_token?: string;
  refresh_token?: string;
}

export default function Calendar() {
  const { user } = useAuthStore();
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showEventModal, setShowEventModal] = useState(false);
  const [emailAccounts, setEmailAccounts] = useState<EmailAccount[]>([]);
  const [syncing, setSyncing] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<{start: Date, end: Date} | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    start: new Date(),
    end: new Date(),
    allDay: false,
    attendees: [] as Array<{email: string, name?: string}>
  });

  useEffect(() => {
    fetchEvents();
    fetchEmailAccounts();
  }, []);

  async function fetchEmailAccounts() {
    try {
      const { data, error } = await supabase
        .from('email_accounts')
        .select('*')
        .eq('is_active', true);

      if (error) throw error;
      setEmailAccounts(data || []);
    } catch (error) {
      console.error('Error fetching email accounts:', error);
    }
  }

  async function fetchEvents() {
    try {
      setLoading(true);
      const { data: calendarEvents, error } = await supabase
        .from('calendar_events')
        .select('*')
        .gte('end', new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString())
        .lte('start', new Date(new Date().setMonth(new Date().getMonth() + 3)).toISOString());

      if (error) throw error;

      setEvents(
        (calendarEvents || []).map(event => ({
          ...event,
          start: new Date(event.start),
          end: new Date(event.end),
        }))
      );
    } catch (error) {
      console.error('Error fetching events:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSync() {
    try {
      setSyncing(true);
      
      // Sync with each connected account
      for (const account of emailAccounts) {
        if (account.provider === 'google' && account.access_token) {
          await syncGoogleCalendar(account);
        } else if (account.provider === 'microsoft' && account.access_token) {
          await syncMicrosoftCalendar(account);
        }
      }

      await fetchEvents();
    } catch (error) {
      console.error('Error syncing calendars:', error);
    } finally {
      setSyncing(false);
    }
  }

  async function syncGoogleCalendar(account: EmailAccount) {
    // In a real implementation, this would use the Google Calendar API
    console.log('Syncing Google Calendar for', account.email);
  }

  async function syncMicrosoftCalendar(account: EmailAccount) {
    // In a real implementation, this would use the Microsoft Graph API
    console.log('Syncing Microsoft Calendar for', account.email);
  }

  async function handleGoogleAuth() {
    window.location.href = 'http://localhost:3000/auth/google';
  }

  async function handleMicrosoftAuth() {
    window.location.href = 'http://localhost:3000/auth/microsoft';
  }

  async function handleCreateEvent(e: React.FormEvent) {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('calendar_events')
        .insert([{
          title: formData.title,
          description: formData.description,
          location: formData.location,
          start: formData.start.toISOString(),
          end: formData.end.toISOString(),
          all_day: formData.allDay,
          source: 'manual',
          attendees: formData.attendees,
          status: 'confirmed',
          owner_id: user?.id
        }]);

      if (error) throw error;

      setShowEventModal(false);
      setSelectedSlot(null);
      setFormData({
        title: '',
        description: '',
        location: '',
        start: new Date(),
        end: new Date(),
        allDay: false,
        attendees: []
      });
      fetchEvents();
    } catch (error) {
      console.error('Error creating event:', error);
    }
  }

  async function handleUpdateEvent(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedEvent) return;

    try {
      const { error } = await supabase
        .from('calendar_events')
        .update({
          title: formData.title,
          description: formData.description,
          location: formData.location,
          start: formData.start.toISOString(),
          end: formData.end.toISOString(),
          all_day: formData.allDay,
          attendees: formData.attendees
        })
        .eq('id', selectedEvent.id);

      if (error) throw error;

      setShowEventModal(false);
      setSelectedEvent(null);
      setFormData({
        title: '',
        description: '',
        location: '',
        start: new Date(),
        end: new Date(),
        allDay: false,
        attendees: []
      });
      fetchEvents();
    } catch (error) {
      console.error('Error updating event:', error);
    }
  }

  async function handleDeleteEvent() {
    if (!selectedEvent || !window.confirm('Are you sure you want to delete this event?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('calendar_events')
        .delete()
        .eq('id', selectedEvent.id);

      if (error) throw error;

      setShowEventModal(false);
      setSelectedEvent(null);
      fetchEvents();
    } catch (error) {
      console.error('Error deleting event:', error);
    }
  }

  const eventStyleGetter = (event: CalendarEvent) => {
    let backgroundColor = '#3B82F6'; // Default blue

    switch (event.source) {
      case 'google':
        backgroundColor = '#34D399'; // Green
        break;
      case 'microsoft':
        backgroundColor = '#818CF8'; // Indigo
        break;
      case 'manual':
        backgroundColor = '#F472B6'; // Pink
        break;
    }

    return {
      style: {
        backgroundColor,
        borderRadius: '4px',
        opacity: 0.8,
        color: 'white',
        border: 'none',
        display: 'block',
      },
    };
  };

  function handleSelectSlot({ start, end }: { start: Date; end: Date }) {
    setSelectedSlot({ start, end });
    setFormData({
      ...formData,
      start,
      end: end || addHours(start, 1),
      allDay: start === end
    });
    setShowEventModal(true);
  }

  function handleSelectEvent(event: CalendarEvent) {
    setSelectedEvent(event);
    setFormData({
      title: event.title,
      description: event.description || '',
      location: event.location || '',
      start: event.start,
      end: event.end,
      allDay: event.allDay || false,
      attendees: event.attendees || []
    });
    setShowEventModal(true);
  }

  return (
    <div className="p-6 h-full">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Calendar</h1>
        <div className="flex items-center gap-2">
          <button
            onClick={handleSync}
            disabled={syncing}
            className="flex items-center gap-2 px-4 py-2 text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync'}
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="flex items-center gap-2 px-4 py-2 text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100"
          >
            <Settings className="h-4 w-4" />
            Settings
          </button>
          <button
            onClick={() => {
              setSelectedEvent(null);
              setFormData({
                title: '',
                description: '',
                location: '',
                start: new Date(),
                end: addHours(new Date(), 1),
                allDay: false,
                attendees: []
              });
              setShowEventModal(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            <Plus className="h-4 w-4" />
            Add Event
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-[calc(100vh-12rem)]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="h-[calc(100vh-12rem)] bg-white rounded-lg shadow">
          <BigCalendar
            localizer={localizer}
            events={events}
            startAccessor="start"
            endAccessor="end"
            style={{ height: '100%' }}
            eventPropGetter={eventStyleGetter}
            views={['month', 'week', 'day', 'agenda']}
            defaultView="week"
            selectable
            onSelectSlot={handleSelectSlot}
            onSelectEvent={handleSelectEvent}
          />
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">Calendar Settings</h2>
            
            {/* Add OAuth Buttons */}
            <div className="mb-6 space-y-3">
              <button
                onClick={handleGoogleAuth}
                className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
              >
                <img 
                  src="https://www.google.com/favicon.ico" 
                  alt="Google" 
                  className="w-5 h-5"
                />
                Connect Gmail Account
              </button>
              <button
                onClick={handleMicrosoftAuth}
                className="w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
              >
                <img 
                  src="https://www.microsoft.com/favicon.ico" 
                  alt="Microsoft" 
                  className="w-5 h-5"
                />
                Connect Outlook Account
              </button>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowSettings(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Event Modal */}
      {showEventModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-lg w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">
                {selectedEvent ? 'Edit Event' : 'Create Event'}
              </h2>
              <button
                onClick={() => {
                  setShowEventModal(false);
                  setSelectedEvent(null);
                  setSelectedSlot(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={selectedEvent ? handleUpdateEvent : handleCreateEvent}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Title</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Start</label>
                    <input
                      type="datetime-local"
                      value={format(formData.start, "yyyy-MM-dd'T'HH:mm")}
                      onChange={(e) => setFormData({ ...formData, start: new Date(e.target.value) })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">End</label>
                    <input
                      type="datetime-local"
                      value={format(formData.end, "yyyy-MM-dd'T'HH:mm")}
                      onChange={(e) => setFormData({ ...formData, end: new Date(e.target.value) })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.allDay}
                      onChange={(e) => setFormData({ ...formData, allDay: e.target.checked })}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">All day event</span>
                  </label>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Attendees</label>
                  <div className="space-y-2">
                    {formData.attendees.map((attendee, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <input
                          type="email"
                          value={attendee.email}
                          onChange={(e) => {
                            const newAttendees = [...formData.attendees];
                            newAttendees[index].email = e.target.value;
                            setFormData({ ...formData, attendees: newAttendees });
                          }}
                          placeholder="Email"
                          className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const newAttendees = formData.attendees.filter((_, i) => i !== index);
                            setFormData({ ...formData, attendees: newAttendees });
                          }}
                          className="text-red-600 hover:text-red-700"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={() => setFormData({
                        ...formData,
                        attendees: [...formData.attendees, { email: '' }]
                      })}
                      className="text-sm text-indigo-600 hover:text-indigo-700"
                    >
                      Add Attendee
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                {selectedEvent && (
                  <button
                    type="button"
                    onClick={handleDeleteEvent}
                    className="px-4 py-2 text-sm font-medium text-red-600 bg-red-50 rounded-md hover:bg-red-100"
                  >
                    Delete
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setShowEventModal(false);
                    setSelectedEvent(null);
                    setSelectedSlot(null);
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  {selectedEvent ? 'Update Event' : 'Create Event'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}