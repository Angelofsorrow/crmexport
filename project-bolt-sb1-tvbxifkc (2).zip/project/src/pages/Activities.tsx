import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Building2, Calendar, Clock, CheckCircle2, User, FileText, BadgeDollarSign, ChevronUp, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import { format, isAfter, isBefore, isToday } from 'date-fns';

interface Activity {
  id: string;
  type: string;
  title: string;
  description: string;
  due_date: string;
  completed_at: string | null;
  company_id: string | null;
  contact_id: string | null;
  deal_id: string | null;
  created_at: string;
  company?: {
    name: string;
  };
  contact?: {
    first_name: string;
    last_name: string;
  };
  deal?: {
    title: string;
    amount: number;
  };
}

interface Company {
  id: string;
  name: string;
}

interface Contact {
  id: string;
  first_name: string;
  last_name: string;
}

interface Deal {
  id: string;
  title: string;
}

type SortField = 'title' | 'type' | 'due_date' | 'completed_at';
type SortDirection = 'asc' | 'desc';

const ACTIVITY_TYPES = [
  'call',
  'meeting',
  'email',
  'task',
  'deadline',
  'follow_up'
];

export default function Activities() {
  const { user } = useAuthStore();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'overdue'>('all');
  const [sortField, setSortField] = useState<SortField>('due_date');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [formData, setFormData] = useState({
    type: 'task',
    title: '',
    description: '',
    due_date: '',
    company_id: '',
    contact_id: '',
    deal_id: '',
  });

  useEffect(() => {
    fetchActivities();
    fetchCompanies();
    fetchContacts();
    fetchDeals();
  }, [user]);

  async function fetchActivities() {
    try {
      const { data, error } = await supabase
        .from('activities')
        .select(`
          *,
          company:companies(name),
          contact:contacts(first_name, last_name),
          deal:deals(title, amount)
        `)
        .order('due_date', { ascending: true });

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchCompanies() {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .order('name');

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching companies:', error);
    }
  }

  async function fetchContacts() {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select('id, first_name, last_name')
        .order('last_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    }
  }

  async function fetchDeals() {
    try {
      const { data, error } = await supabase
        .from('deals')
        .select('id, title')
        .order('title');

      if (error) throw error;
      setDeals(data || []);
    } catch (error) {
      console.error('Error fetching deals:', error);
    }
  }

  function handleSort(field: SortField) {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  }

  function getSortIcon(field: SortField) {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? (
      <ChevronUp className="h-4 w-4" />
    ) : (
      <ChevronDown className="h-4 w-4" />
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const formattedData = {
        ...formData,
        owner_id: user?.id,
      };

      let error;
      if (editingActivity) {
        ({ error } = await supabase
          .from('activities')
          .update(formattedData)
          .eq('id', editingActivity.id));
      } else {
        ({ error } = await supabase.from('activities').insert([formattedData]));
      }

      if (error) throw error;

      // Update contact's last_contacted if this is a contact activity
      if (formData.contact_id) {
        const { error: updateError } = await supabase
          .from('contacts')
          .update({ last_contacted: new Date().toISOString() })
          .eq('id', formData.contact_id);

        if (updateError) throw updateError;
      }
      
      setShowModal(false);
      setEditingActivity(null);
      setFormData({
        type: 'task',
        title: '',
        description: '',
        due_date: '',
        company_id: '',
        contact_id: '',
        deal_id: '',
      });
      fetchActivities();
    } catch (error) {
      console.error('Error saving activity:', error);
    }
  }

  function handleEdit(activity: Activity) {
    setEditingActivity(activity);
    setFormData({
      type: activity.type,
      title: activity.title,
      description: activity.description || '',
      due_date: activity.due_date ? activity.due_date.split('.')[0] : '', // Remove milliseconds
      company_id: activity.company_id || '',
      contact_id: activity.contact_id || '',
      deal_id: activity.deal_id || '',
    });
    setShowModal(true);
  }

  async function handleDelete(id: string) {
    if (window.confirm('Are you sure you want to delete this activity?')) {
      try {
        const { error } = await supabase
          .from('activities')
          .delete()
          .eq('id', id);

        if (error) throw error;
        fetchActivities();
      } catch (error) {
        console.error('Error deleting activity:', error);
      }
    }
  }

  async function handleToggleComplete(activity: Activity) {
    try {
      const { error } = await supabase
        .from('activities')
        .update({
          completed_at: activity.completed_at ? null : new Date().toISOString(),
        })
        .eq('id', activity.id);

      if (error) throw error;
      fetchActivities();
    } catch (error) {
      console.error('Error updating activity:', error);
    }
  }

  function getActivityTypeIcon(type: string) {
    switch (type) {
      case 'call':
        return <User className="h-4 w-4" />;
      case 'meeting':
        return <Users className="h-4 w-4" />;
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'task':
        return <CheckCircle2 className="h-4 w-4" />;
      case 'deadline':
        return <Clock className="h-4 w-4" />;
      case 'follow_up':
        return <Calendar className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  }

  function getActivityStatus(activity: Activity) {
    if (activity.completed_at) {
      return {
        label: 'Completed',
        color: 'bg-green-100 text-green-800',
      };
    }

    const dueDate = new Date(activity.due_date);
    if (isAfter(new Date(), dueDate)) {
      return {
        label: 'Overdue',
        color: 'bg-red-100 text-red-800',
      };
    }

    if (isToday(dueDate)) {
      return {
        label: 'Due Today',
        color: 'bg-yellow-100 text-yellow-800',
      };
    }

    return {
      label: 'Upcoming',
      color: 'bg-blue-100 text-blue-800',
    };
  }

  const filteredActivities = activities
    .filter(activity => {
      if (filter === 'pending') return !activity.completed_at;
      if (filter === 'completed') return activity.completed_at;
      if (filter === 'overdue') {
        return !activity.completed_at && isAfter(new Date(), new Date(activity.due_date));
      }
      return true;
    })
    .filter(activity =>
      activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.company?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      `${activity.contact?.first_name} ${activity.contact?.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.deal?.title?.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      let aValue = a[sortField];
      let bValue = b[sortField];
      
      if (aValue === null) return 1;
      if (bValue === null) return -1;
      
      const comparison = aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const stats = {
    total: activities.length,
    completed: activities.filter(a => a.completed_at).length,
    pending: activities.filter(a => !a.completed_at).length,
    overdue: activities.filter(a => !a.completed_at && isAfter(new Date(), new Date(a.due_date))).length,
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Activities</h1>
          <div className="mt-1 text-sm text-gray-500">
            {stats.total} total • {stats.completed} completed • {stats.pending} pending • {stats.overdue} overdue
          </div>
        </div>
        <button
          onClick={() => {
            setEditingActivity(null);
            setFormData({
              type: 'task',
              title: '',
              description: '',
              due_date: '',
              company_id: '',
              contact_id: '',
              deal_id: '',
            });
            setShowModal(true);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700"
        >
          <Plus className="h-4 w-4" />
          Add Activity
        </button>
      </div>

      <div className="mb-6 space-y-4">
        <div className="flex gap-4">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg ${
              filter === 'all'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-4 py-2 rounded-lg ${
              filter === 'pending'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded-lg ${
              filter === 'completed'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setFilter('overdue')}
            className={`px-4 py-2 rounded-lg ${
              filter === 'overdue'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Overdue
          </button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search activities..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredActivities.map((activity) => {
            const status = getActivityStatus(activity);
            return (
              <div
                key={activity.id}
                className={`bg-white rounded-lg shadow p-4 ${
                  activity.completed_at ? 'opacity-75' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <button
                      onClick={() => handleToggleComplete(activity)}
                      className={`mt-1 rounded-full p-1 ${
                        activity.completed_at
                          ? 'bg-green-100 text-green-600'
                          : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                      }`}
                    >
                      <CheckCircle2 className="h-5 w-5" />
                    </button>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${status.color}`}>
                          {status.label}
                        </span>
                        <span className="text-sm text-gray-500">
                          {format(new Date(activity.due_date), 'MMM d, yyyy h:mm a')}
                        </span>
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 mt-1">
                        {activity.title}
                      </h3>
                      {activity.description && (
                        <p className="text-gray-500 mt-1">{activity.description}</p>
                      )}
                      <div className="flex flex-wrap gap-4 mt-2">
                        {activity.company && (
                          <div className="flex items-center text-sm text-gray-500">
                            <Building2 className="h-4 w-4 mr-1" />
                            {activity.company.name}
                          </div>
                        )}
                        {activity.contact && (
                          <div className="flex items-center text-sm text-gray-500">
                            <User className="h-4 w-4 mr-1" />
                            {activity.contact.first_name} {activity.contact.last_name}
                          </div>
                        )}
                        {activity.deal && (
                          <div className="flex items-center text-sm text-gray-500">
                            <BadgeDollarSign className="h-4 w-4 mr-1" />
                            {activity.deal.title}
                            {activity.deal.amount && (
                              <span className="ml-1">
                                ({new Intl.NumberFormat('en-US', {
                                  style: 'currency',
                                  currency: 'USD',
                                  notation: 'compact',
                                  maximumFractionDigits: 1,
                                }).format(activity.deal.amount)})
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEdit(activity)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(activity.id)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Activity Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">
              {editingActivity ? 'Edit Activity' : 'Add New Activity'}
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    {ACTIVITY_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type.replace('_', ' ')}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Title</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Description</label>
                  <textarea
                    rows={3}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Due Date & Time</label>
                  <input
                    type="datetime-local"
                    required
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Company</label>
                  <select
                    value={formData.company_id}
                    onChange={(e) => setFormData({ ...formData, company_id: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="">Select a company</option>
                    {companies.map((company) => (
                      <option key={company.id} value={company.id}>
                        {company.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Contact</label>
                  <select
                    value={formData.contact_id}
                    onChange={(e) => setFormData({ ...formData, contact_id: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="">Select a contact</option>
                    {contacts.map((contact) => (
                      <option key={contact.id} value={contact.id}>
                        {contact.first_name} {contact.last_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Deal</label>
                  <select
                    value={formData.deal_id}
                    onChange={(e) => setFormData({ ...formData, deal_id: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="">Select a deal</option>
                    {deals.map((deal) => (
                      <option key={deal.id} value={deal.id}>
                        {deal.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditingActivity(null);
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  {editingActivity ? 'Save Changes' : 'Add Activity'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}