import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { calculateMonthlyPayment, calculateAPR } from '../lib/calculations';
import { BadgeDollarSign, Calculator, ChevronDown, ChevronUp, Upload, X, AlertCircle } from 'lucide-react';
import { parseLoanProductFile } from '../lib/loanProductParser';

interface LoanProduct {
  id: string;
  name: string;
  type: string;
  description: string;
  min_credit_score: number;
  max_ltv: number;
  min_down_payment: number;
  interest_rate_range: {
    min: number;
    max: number;
  };
  term_years: number[];
  requirements: string[];
  eligible_property_types: string[];
  income_limits: any;
  dti_limits: {
    front: number;
    back: number;
  };
  credit_score_ranges: Array<{
    min: number;
    max: number;
    rate_adjustment: number;
  }>;
}

export default function LoanProducts() {
  const [products, setProducts] = useState<LoanProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [calculatorValues, setCalculatorValues] = useState({
    loanAmount: '300000',
    interestRate: '6.5',
    termYears: '30',
    downPayment: '60000'
  });
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  async function fetchProducts() {
    try {
      const { data, error } = await supabase
        .from('loan_products')
        .select('*')
        .order('name');

      if (error) throw error;

      // Parse JSON fields
      const parsedProducts = (data || []).map(product => ({
        ...product,
        interest_rate_range: typeof product.interest_rate_range === 'string'
          ? JSON.parse(product.interest_rate_range)
          : product.interest_rate_range,
        term_years: typeof product.term_years === 'string'
          ? JSON.parse(product.term_years)
          : product.term_years,
        requirements: typeof product.requirements === 'string'
          ? JSON.parse(product.requirements)
          : product.requirements,
        eligible_property_types: typeof product.eligible_property_types === 'string'
          ? JSON.parse(product.eligible_property_types)
          : product.eligible_property_types,
        income_limits: typeof product.income_limits === 'string'
          ? JSON.parse(product.income_limits)
          : product.income_limits,
        dti_limits: typeof product.dti_limits === 'string'
          ? JSON.parse(product.dti_limits)
          : product.dti_limits,
        credit_score_ranges: typeof product.credit_score_ranges === 'string'
          ? JSON.parse(product.credit_score_ranges)
          : product.credit_score_ranges
      }));

      setProducts(parsedProducts);
    } catch (error) {
      console.error('Error fetching loan products:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleFileUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadError(null);

    try {
      // Parse the file
      const products = await parseLoanProductFile(file);

      // Insert products into database
      const { error } = await supabase
        .from('loan_products')
        .insert(products);

      if (error) throw error;

      // Refresh products list
      fetchProducts();

      // Clear file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error uploading loan products:', error);
      setUploadError(error.message);
    } finally {
      setIsUploading(false);
    }
  }

  function calculatePayments() {
    const loanAmount = parseFloat(calculatorValues.loanAmount);
    const interestRate = parseFloat(calculatorValues.interestRate);
    const termYears = parseInt(calculatorValues.termYears);
    const downPayment = parseFloat(calculatorValues.downPayment);

    if (isNaN(loanAmount) || isNaN(interestRate) || isNaN(termYears) || isNaN(downPayment)) {
      return null;
    }

    const monthlyPayment = calculateMonthlyPayment(loanAmount - downPayment, interestRate, termYears);
    const apr = calculateAPR(loanAmount - downPayment, interestRate, termYears, 5000); // Estimated closing costs

    return {
      monthlyPayment,
      apr,
      totalPayment: monthlyPayment * termYears * 12,
      totalInterest: (monthlyPayment * termYears * 12) - (loanAmount - downPayment)
    };
  }

  const payments = calculatePayments();

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Loan Products</h1>
          <p className="mt-1 text-sm text-gray-500">
            Compare different loan options and calculate payments
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".csv,.xlsx,.xls"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50"
            >
              <Upload className="h-4 w-4" />
              {isUploading ? 'Uploading...' : 'Upload Products'}
            </button>
            {uploadError && (
              <div className="absolute top-full mt-2 w-64 bg-red-50 text-red-700 p-2 rounded-lg text-sm flex items-start gap-2">
                <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>{uploadError}</span>
                <button
                  onClick={() => setUploadError(null)}
                  className="ml-auto flex-shrink-0"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
          <a
            href="/sample-loan-products.csv"
            download
            className="text-indigo-600 hover:text-indigo-700 text-sm"
          >
            Download Template
          </a>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-4">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : products.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-6 text-center text-gray-500">
              No loan products available
            </div>
          ) : (
            products.map((product) => (
              <div key={product.id} className="bg-white rounded-lg shadow">
                <div
                  className="p-6 cursor-pointer"
                  onClick={() => setSelectedProduct(selectedProduct === product.id ? null : product.id)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
                      <p className="text-sm text-gray-500">{product.description}</p>
                    </div>
                    {selectedProduct === product.id ? (
                      <ChevronUp className="h-5 w-5 text-gray-400" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                </div>

                {selectedProduct === product.id && (
                  <div className="px-6 pb-6 border-t border-gray-200">
                    <div className="grid grid-cols-2 gap-6 mt-6">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">Requirements</h4>
                        <ul className="mt-2 space-y-2">
                          {product.requirements?.map((req, index) => (
                            <li key={index} className="text-sm text-gray-600 flex items-start">
                              <span className="h-5 w-5 text-indigo-500 mr-2">•</span>
                              {req}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium text-gray-900">Terms</h4>
                        <dl className="mt-2 space-y-2">
                          <div className="text-sm">
                            <dt className="inline text-gray-500">Min Credit Score:</dt>
                            <dd className="inline ml-1 text-gray-900">{product.min_credit_score}</dd>
                          </div>
                          <div className="text-sm">
                            <dt className="inline text-gray-500">Max LTV:</dt>
                            <dd className="inline ml-1 text-gray-900">{product.max_ltv}%</dd>
                          </div>
                          <div className="text-sm">
                            <dt className="inline text-gray-500">Min Down Payment:</dt>
                            <dd className="inline ml-1 text-gray-900">{product.min_down_payment}%</dd>
                          </div>
                          <div className="text-sm">
                            <dt className="inline text-gray-500">Interest Rate Range:</dt>
                            <dd className="inline ml-1 text-gray-900">
                              {product.interest_rate_range?.min}% - {product.interest_rate_range?.max}%
                            </dd>
                          </div>
                          <div className="text-sm">
                            <dt className="inline text-gray-500">Available Terms:</dt>
                            <dd className="inline ml-1 text-gray-900">
                              {product.term_years?.join(', ')} years
                            </dd>
                          </div>
                          <div className="text-sm">
                            <dt className="inline text-gray-500">DTI Limits:</dt>
                            <dd className="inline ml-1 text-gray-900">
                              Front: {product.dti_limits?.front}%, Back: {product.dti_limits?.back}%
                            </dd>
                          </div>
                          <div className="text-sm">
                            <dt className="block text-gray-500 mb-1">Eligible Property Types:</dt>
                            <dd className="text-gray-900">
                              {product.eligible_property_types?.join(', ')}
                            </dd>
                          </div>
                          {product.income_limits && (
                            <div className="text-sm">
                              <dt className="block text-gray-500 mb-1">Income Limits:</dt>
                              <dd className="text-gray-900">
                                {product.income_limits.percentage_ami 
                                  ? `${product.income_limits.percentage_ami}% of AMI`
                                  : `Single: $${product.income_limits.single?.toLocaleString()}, Joint: $${product.income_limits.joint?.toLocaleString()}`
                                }
                              </dd>
                            </div>
                          )}
                        </dl>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-2 mb-4">
            <Calculator className="h-5 w-5 text-indigo-600" />
            <h2 className="text-lg font-medium text-gray-900">Payment Calculator</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Purchase Price</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">$</span>
                </div>
                <input
                  type="number"
                  value={calculatorValues.loanAmount}
                  onChange={(e) => setCalculatorValues({ ...calculatorValues, loanAmount: e.target.value })}
                  className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Down Payment</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">$</span>
                </div>
                <input
                  type="number"
                  value={calculatorValues.downPayment}
                  onChange={(e) => setCalculatorValues({ ...calculatorValues, downPayment: e.target.value })}
                  className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Interest Rate (%)</label>
              <input
                type="number"
                step="0.125"
                value={calculatorValues.interestRate}
                onChange={(e) => setCalculatorValues({ ...calculatorValues, interestRate: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Term (Years)</label>
              <select
                value={calculatorValues.termYears}
                onChange={(e) => setCalculatorValues({ ...calculatorValues, termYears: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              >
                <option value="10">10 Years</option>
                <option value="15">15 Years</option>
                <option value="20">20 Years</option>
                <option value="30">30 Years</option>
              </select>
            </div>

            {payments && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Payment Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Monthly Payment:</span>
                    <span className="text-sm font-medium text-gray-900">
                      {new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD'
                      }).format(payments.monthlyPayment)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">APR:</span>
                    <span className="text-sm font-medium text-gray-900">
                      {payments.apr.toFixed(3)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Total Payment:</span>
                    <span className="text-sm font-medium text-gray-900">
                      {new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD'
                      }).format(payments.totalPayment)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500">Total Interest:</span>
                    <span className="text-sm font-medium text-gray-900">
                      {new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD'
                      }).format(payments.totalInterest)}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}