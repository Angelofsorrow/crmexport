import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import { whitelabelConfigSchema } from '../lib/types';
import type { WhitelabelConfig } from '../lib/types';
import { Settings as SettingsIcon, Mail, MessageSquare, Phone, Calendar, FileText, Key, RefreshCw, AlertCircle, Check, X, ChevronDown, ChevronUp, Globe, Database, Workflow } from 'lucide-react';

interface Integration {
  id: string;
  name: string;
  type: string;
  config: Record<string, any>;
  status: 'active' | 'inactive' | 'error';
  last_sync?: string;
  created_at: string;
}

interface ApiKey {
  id: string;
  name: string;
  key: string;
  created_at: string;
  last_used?: string;
}

export default function Settings() {
  const { organization, whitelabelConfig, setOrganization, setWhitelabelConfig } = useAuthStore();
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'integrations' | 'api-keys'>('integrations');
  const [showNewKeyForm, setShowNewKeyForm] = useState(false);
  const [showIntegrationForm, setShowIntegrationForm] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [newKeyData, setNewKeyData] = useState({ name: '', key: '' });
  const [newIntegrationData, setNewIntegrationData] = useState({
    name: '',
    type: 'email',
    config: {}
  });
  const [whitelabelFormData, setWhitelabelFormData] = useState<Partial<WhitelabelConfig>>({
    name: '',
    logo_url: '',
    favicon_url: '',
    primary_color: '#4F46E5',
    secondary_color: '#818CF8',
    accent_color: '#6366F1',
    font_family: 'Inter',
    custom_css: '',
    email_template: '',
    custom_domain: '',
    support_email: '',
    support_phone: '',
    footer_text: '',
    terms_url: '',
    privacy_url: '',
    is_active: true
  });
  const [saveError, setSaveError] = useState<string | null>(null);
  const [organizationName, setOrganizationName] = useState('');

  useEffect(() => {
    if (organization) {
      fetchIntegrations();
      fetchApiKeys();
      loadWhitelabelConfig();
      setOrganizationName(organization.name);
    }
  }, [organization]);

  useEffect(() => {
    if (whitelabelConfig) {
      setWhitelabelFormData(whitelabelConfig);
    }
  }, [whitelabelConfig]);

  async function fetchIntegrations() {
    try {
      const { data, error } = await supabase
        .from('integrations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setIntegrations(data || []);
    } catch (error) {
      console.error('Error fetching integrations:', error);
    }
  }

  async function fetchApiKeys() {
    try {
      const { data, error } = await supabase
        .from('api_keys')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setApiKeys(data || []);
    } catch (error) {
      console.error('Error fetching API keys:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadWhitelabelConfig() {
    try {
      if (!organization) return;

      const { data, error } = await supabase
        .from('whitelabel_configs')
        .select('*')
        .eq('organization_id', organization.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      if (data) {
        setWhitelabelFormData(data);
      }
    } catch (error) {
      console.error('Error loading whitelabel config:', error);
    }
  }

  async function handleSaveWhitelabel(e: React.FormEvent) {
    e.preventDefault();
    setSaveError(null);

    try {
      if (!organization) throw new Error('No organization selected');

      // First update organization name if changed
      if (organizationName !== organization.name) {
        const { error: orgError } = await supabase
          .from('organizations')
          .update({ name: organizationName })
          .eq('id', organization.id);

        if (orgError) throw orgError;

        // Update local organization state
        setOrganization({
          ...organization,
          name: organizationName
        });
      }

      // Prepare the data for validation
      const formData = {
        ...whitelabelFormData,
        organization_id: organization.id,
        // Ensure optional string fields are empty strings instead of null
        logo_url: whitelabelFormData.logo_url || '',
        favicon_url: whitelabelFormData.favicon_url || '',
        custom_css: whitelabelFormData.custom_css || '',
        email_template: whitelabelFormData.email_template || '',
        custom_domain: whitelabelFormData.custom_domain || '',
        support_email: whitelabelFormData.support_email || '',
        support_phone: whitelabelFormData.support_phone || '',
        footer_text: whitelabelFormData.footer_text || '',
        terms_url: whitelabelFormData.terms_url || '',
        privacy_url: whitelabelFormData.privacy_url || ''
      };

      // Validate the data
      const validatedData = whitelabelConfigSchema.parse(formData);

      // Save to database
      const { error } = await supabase
        .from('whitelabel_configs')
        .upsert({
          ...validatedData,
          organization_id: organization.id
        });

      if (error) throw error;

      // Update local state
      setWhitelabelConfig(validatedData);
      
      // Show success message
      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      setSaveError(error.message || 'Failed to save settings');
    }
  }

  async function handleSaveApiKey(e: React.FormEvent) {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('api_keys')
        .insert([{
          name: newKeyData.name,
          key: newKeyData.key
        }]);

      if (error) throw error;

      setShowNewKeyForm(false);
      setNewKeyData({ name: '', key: '' });
      fetchApiKeys();
    } catch (error) {
      console.error('Error saving API key:', error);
    }
  }

  async function handleDeleteApiKey(id: string) {
    if (!window.confirm('Are you sure you want to delete this API key?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('api_keys')
        .delete()
        .eq('id', id);

      if (error) throw error;
      fetchApiKeys();
    } catch (error) {
      console.error('Error deleting API key:', error);
    }
  }

  async function handleSaveIntegration(e: React.FormEvent) {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('integrations')
        .insert([newIntegrationData]);

      if (error) throw error;

      setShowIntegrationForm(false);
      setNewIntegrationData({
        name: '',
        type: 'email',
        config: {}
      });
      fetchIntegrations();
    } catch (error) {
      console.error('Error saving integration:', error);
    }
  }

  async function handleDeleteIntegration(id: string) {
    if (!window.confirm('Are you sure you want to delete this integration?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('integrations')
        .delete()
        .eq('id', id);

      if (error) throw error;
      fetchIntegrations();
    } catch (error) {
      console.error('Error deleting integration:', error);
    }
  }

  function getIntegrationIcon(type: string) {
    switch (type) {
      case 'email':
        return <Mail className="h-5 w-5" />;
      case 'sms':
        return <MessageSquare className="h-5 w-5" />;
      case 'phone':
        return <Phone className="h-5 w-5" />;
      case 'calendar':
        return <Calendar className="h-5 w-5" />;
      case 'document':
        return <FileText className="h-5 w-5" />;
      case 'crm':
        return <Database className="h-5 w-5" />;
      case 'automation':
        return <Workflow className="h-5 w-5" />;
      default:
        return <Globe className="h-5 w-5" />;
    }
  }

  const integrationSections = [
    {
      title: 'Email & Communication',
      types: ['email', 'sms', 'phone'],
      description: 'Configure email accounts, SMS providers, and phone systems'
    },
    {
      title: 'Calendar & Scheduling',
      types: ['calendar'],
      description: 'Manage calendar integrations and appointment scheduling'
    },
    {
      title: 'Document Management',
      types: ['document'],
      description: 'Set up document storage and processing integrations'
    },
    {
      title: 'CRM & Data',
      types: ['crm'],
      description: 'Configure external CRM connections and data sources'
    },
    {
      title: 'Automation & Workflows',
      types: ['automation'],
      description: 'Manage automation tools and workflow integrations'
    }
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!organization) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-yellow-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                No organization found. Please contact your administrator.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage your integrations, API keys, and organization settings
          </p>
        </div>
      </div>

      <div className="mb-6">
        <div className="sm:hidden">
          <select
            value={activeTab}
            onChange={(e) => setActiveTab(e.target.value as 'integrations' | 'api-keys')}
            className="block w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="integrations">Integrations</option>
            <option value="api-keys">API Keys</option>
          </select>
        </div>
        <div className="hidden sm:block">
          <nav className="flex space-x-4" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('integrations')}
              className={`px-3 py-2 text-sm font-medium rounded-md ${
                activeTab === 'integrations'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Integrations
            </button>
            <button
              onClick={() => setActiveTab('api-keys')}
              className={`px-3 py-2 text-sm font-medium rounded-md ${
                activeTab === 'api-keys'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              API Keys
            </button>
          </nav>
        </div>
      </div>

      {activeTab === 'integrations' ? (
        <div className="space-y-6">
          {integrationSections.map((section) => (
            <div key={section.title} className="bg-white rounded-lg shadow">
              <button
                onClick={() => setExpandedSection(
                  expandedSection === section.title ? null : section.title
                )}
                className="w-full px-6 py-4 flex items-center justify-between text-left"
              >
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{section.title}</h3>
                  <p className="mt-1 text-sm text-gray-500">{section.description}</p>
                </div>
                {expandedSection === section.title ? (
                  <ChevronUp className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </button>

              {expandedSection === section.title && (
                <div className="px-6 pb-6 space-y-4">
                  {integrations
                    .filter((integration) => section.types.includes(integration.type))
                    .map((integration) => (
                      <div
                        key={integration.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          {getIntegrationIcon(integration.type)}
                          <div>
                            <div className="font-medium text-gray-900">
                              {integration.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              Last synced: {integration.last_sync ? 
                                new Date(integration.last_sync).toLocaleString() : 
                                'Never'}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              integration.status === 'active'
                                ? 'bg-green-100 text-green-800'
                                : integration.status === 'error'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {integration.status}
                          </span>
                          <button
                            onClick={() => handleDeleteIntegration(integration.id)}
                            className="text-gray-400 hover:text-gray-500"
                          >
                            <X className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  
                  <button
                    onClick={() => setShowIntegrationForm(true)}
                    className="mt-4 w-full px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 font-medium flex items-center justify-center gap-2 hover:bg-gray-50"
                  >
                    Add New Integration
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow">
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-medium text-gray-900">API Keys</h2>
              <button
                onClick={() => setShowNewKeyForm(true)}
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
              >
                Add New Key
              </button>
            </div>

            <div className="space-y-4">
              {apiKeys.map((apiKey) => (
                <div
                  key={apiKey.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <div className="font-medium text-gray-900">{apiKey.name}</div>
                    <div className="text-sm text-gray-500">
                      Created: {new Date(apiKey.created_at).toLocaleDateString()}
                      {apiKey.last_used && 
                        ` • Last used: ${new Date(apiKey.last_used).toLocaleDateString()}`
                      }
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(apiKey.key);
                        // Show a toast or some feedback
                      }}
                      className="text-indigo-600 hover:text-indigo-700"
                    >
                      <Key className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDeleteApiKey(apiKey.id)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* New API Key Modal */}
      {showNewKeyForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">Add New API Key</h2>
            <form onSubmit={handleSaveApiKey}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Name</label>
                  <input
                    type="text"
                    value={newKeyData.name}
                    onChange={(e) => setNewKeyData({ ...newKeyData, name: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">API Key</label>
                  <input
                    type="text"
                    value={newKeyData.key}
                    onChange={(e) => setNewKeyData({ ...newKeyData, key: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowNewKeyForm(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  Save Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Integration Modal */}
      {showIntegrationForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">Add New Integration</h2>
            <form onSubmit={handleSaveIntegration}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Name</label>
                  <input
                    type="text"
                    value={newIntegrationData.name}
                    onChange={(e) => setNewIntegrationData({ 
                      ...newIntegrationData, 
                      name: e.target.value 
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Type</label>
                  <select
                    value={newIntegrationData.type}
                    onChange={(e) => setNewIntegrationData({ 
                      ...newIntegrationData, 
                      type: e.target.value 
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="email">Email</option>
                    <option value="sms">SMS</option>
                    <option value="phone">Phone</option>
                    <option value="calendar">Calendar</option>
                    <option value="document">Document</option>
                    <option value="crm">CRM</option>
                    <option value="automation">Automation</option>
                  </select>
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowIntegrationForm(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
                >
                  Add Integration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Whitelabel Settings */}
      <div className="mt-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-6">Organization Settings</h2>
          
          <form onSubmit={handleSaveWhitelabel} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Organization Name</label>
              <input
                type="text"
                value={organizationName}
                onChange={(e) => setOrganizationName(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Your Organization Name"
                required
              />
            </div>

            <h3 className="text-lg font-medium text-gray-900 mt-8 mb-6">Whitelabel Configuration</h3>
            
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  value={whitelabelFormData.name || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Your Company Name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Logo URL</label>
                <input
                  type="url"
                  value={whitelabelFormData.logo_url || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, logo_url: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="https://example.com/logo.png"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Favicon URL</label>
                <input
                  type="url"
                  value={whitelabelFormData.favicon_url || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, favicon_url: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="https://example.com/favicon.ico"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Primary Color</label>
                <input
                  type="text"
                  value={whitelabelFormData.primary_color || '#4F46E5'}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, primary_color: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="#4F46E5"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Secondary Color</label>
                <input
                  type="text"
                  value={whitelabelFormData.secondary_color || '#818CF8'}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, secondary_color: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="#818CF8"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Accent Color</label>
                <input
                  type="text"
                  value={whitelabelFormData.accent_color || '#6366F1'}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, accent_color: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="#6366F1"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Font Family</label>
                <input
                  type="text"
                  value={whitelabelFormData.font_family || 'Inter'}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, font_family: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Inter"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700">Custom CSS</label>
                <textarea
                  value={whitelabelFormData.custom_css || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, custom_css: e.target.value })}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Add custom CSS rules here..."
                />
              </div>

              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700">Email Template</label>
                <textarea
                  value={whitelabelFormData.email_template || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, email_template: e.target.value })}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="HTML email template..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Custom Domain</label>
                <input
                  type="text"
                  value={whitelabelFormData.custom_domain || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, custom_domain: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="app.yourdomain.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Support Email</label>
                <input
                  type="email"
                  value={whitelabelFormData.support_email || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, support_email: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="support@yourdomain.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Support Phone</label>
                <input
                  type="tel"
                  value={whitelabelFormData.support_phone || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, support_phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="+1 (555) 123-4567"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Footer Text</label>
                <input
                  type="text"
                  value={whitelabelFormData.footer_text || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, footer_text: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="© 2023 Your Company. All rights reserved."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Terms URL</label>
                <input
                  type="url"
                  value={whitelabelFormData.terms_url || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, terms_url: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="https://example.com/terms"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Privacy URL</label>
                <input
                  type="url"
                  value={whitelabelFormData.privacy_url || ''}
                  onChange={(e) => setWhitelabelFormData({ ...whitelabelFormData, privacy_url: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="https://example.com/privacy"
                />
              </div>
            </div>

            {saveError && (
              <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg">
                {saveError}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
              >
                Save Settings
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}