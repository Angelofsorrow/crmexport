import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Users, Building2, Settings, ChevronDown, ChevronUp, Mail, Phone, Globe, Calendar } from 'lucide-react';
import { format } from 'date-fns';

interface Organization {
  id: string;
  name: string;
  slug: string;
  domain: string;
  created_at: string;
  owner_id: string;
  _count?: {
    members: number;
    companies: number;
    contacts: number;
    deals: number;
  };
  whitelabel_configs?: Array<{
    name: string;
    custom_domain: string;
    support_email: string;
    support_phone: string;
  }>;
}

interface OrganizationMember {
  id: string;
  user_id: string;
  role: string;
  created_at: string;
  user_email: string;
  last_sign_in_at?: string;
}

export default function Organizations() {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrg, setSelectedOrg] = useState<string | null>(null);
  const [members, setMembers] = useState<Record<string, OrganizationMember[]>>({});

  useEffect(() => {
    fetchOrganizations();
  }, []);

  async function fetchOrganizations() {
    try {
      // Get organizations with whitelabel configs
      const { data: orgs, error: orgsError } = await supabase
        .from('organizations')
        .select(`
          *,
          whitelabel_configs(
            name,
            custom_domain,
            support_email,
            support_phone
          )
        `)
        .order('created_at', { ascending: false });

      if (orgsError) throw orgsError;

      // Get counts for each organization
      const orgsWithCounts = await Promise.all((orgs || []).map(async (org) => {
        const [
          { count: members },
          { count: companies },
          { count: contacts },
          { count: deals }
        ] = await Promise.all([
          supabase.from('organization_members').select('*', { count: 'exact' }).eq('organization_id', org.id),
          supabase.from('companies').select('*', { count: 'exact' }).eq('organization_id', org.id),
          supabase.from('contacts').select('*', { count: 'exact' }).eq('organization_id', org.id),
          supabase.from('deals').select('*', { count: 'exact' }).eq('organization_id', org.id)
        ]);

        return {
          ...org,
          _count: {
            members: members || 0,
            companies: companies || 0,
            contacts: contacts || 0,
            deals: deals || 0
          }
        };
      }));

      setOrganizations(orgsWithCounts);
    } catch (error) {
      console.error('Error fetching organizations:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchOrganizationMembers(orgId: string) {
    try {
      const { data, error } = await supabase
        .from('organization_members')
        .select('*, user_email:user_id')
        .eq('organization_id', orgId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setMembers(prev => ({
        ...prev,
        [orgId]: data || []
      }));
    } catch (error) {
      console.error('Error fetching organization members:', error);
    }
  }

  function handleExpandOrg(orgId: string) {
    if (selectedOrg === orgId) {
      setSelectedOrg(null);
    } else {
      setSelectedOrg(orgId);
      if (!members[orgId]) {
        fetchOrganizationMembers(orgId);
      }
    }
  }

  const filteredOrganizations = organizations.filter(org =>
    org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    org.domain?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Organizations</h1>
          <div className="mt-1 text-sm text-gray-500">
            {organizations.length} total organizations
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Search organizations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-4 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrganizations.map((org) => (
            <div key={org.id} className="bg-white rounded-lg shadow">
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Building2 className="h-5 w-5 text-gray-400" />
                      <h3 className="text-lg font-medium text-gray-900">
                        {org.name}
                      </h3>
                      {org.whitelabel_configs?.[0]?.custom_domain && (
                        <span className="text-sm text-gray-500">
                          ({org.whitelabel_configs[0].custom_domain})
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-4 gap-4 mt-4">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {org._count?.members} Users
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {org._count?.companies} Companies
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {org._count?.contacts} Contacts
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {org._count?.deals} Deals
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 text-sm text-gray-500">
                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4" />
                          {org.whitelabel_configs?.[0]?.support_email || 'No support email'}
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          {org.whitelabel_configs?.[0]?.support_phone || 'No support phone'}
                        </div>
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4" />
                          {org.domain || 'No domain'}
                        </div>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleExpandOrg(org.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    {selectedOrg === org.id ? (
                      <ChevronUp className="h-5 w-5" />
                    ) : (
                      <ChevronDown className="h-5 w-5" />
                    )}
                  </button>
                </div>

                {selectedOrg === org.id && (
                  <div className="mt-6 border-t pt-6">
                    <h4 className="text-sm font-medium text-gray-900 mb-4">Organization Members</h4>
                    <div className="space-y-4">
                      {members[org.id]?.map((member) => (
                        <div
                          key={member.id}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                        >
                          <div>
                            <div className="font-medium text-gray-900">
                              {member.user_email}
                            </div>
                            <div className="text-sm text-gray-500">
                              Role: {member.role}
                              {member.last_sign_in_at && (
                                <span className="ml-2">
                                  • Last login: {format(new Date(member.last_sign_in_at), 'MMM d, yyyy')}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                member.role === 'admin'
                                  ? 'bg-indigo-100 text-indigo-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {member.role}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}