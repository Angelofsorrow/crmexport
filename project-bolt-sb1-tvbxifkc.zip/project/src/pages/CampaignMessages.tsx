import React, { useState, useEffect } from 'react';
import { Search, Calendar, Mail, MessageSquare, Voicemail, Edit2, Save, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { format, addHours } from 'date-fns';

interface CampaignMessage {
  id: string;
  campaign_id: string;
  type: 'email' | 'sms' | 'voicemail';
  delay_hours: number;
  subject?: string;
  content: string;
  order_number: number;
  campaign: {
    name: string;
    status: string;
  };
  scheduled_contacts: number;
  sent_contacts: number;
}

export default function CampaignMessages() {
  const [messages, setMessages] = useState<CampaignMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingMessage, setEditingMessage] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({
    subject: '',
    content: '',
  });

  useEffect(() => {
    fetchMessages();
  }, []);

  async function fetchMessages() {
    try {
      // Get all campaign steps with campaign info
      const { data: stepsData, error: stepsError } = await supabase
        .from('campaign_steps')
        .select(`
          *,
          campaign:campaigns(name, status)
        `)
        .order('created_at', { ascending: false });

      if (stepsError) throw stepsError;

      // Get contact counts for each step
      const messagesWithCounts = await Promise.all((stepsData || []).map(async (step) => {
        const { count: totalContacts } = await supabase
          .from('campaign_contacts')
          .select('*', { count: 'exact' })
          .eq('campaign_id', step.campaign_id);

        const { count: sentContacts } = await supabase
          .from('campaign_contacts')
          .select('*', { count: 'exact' })
          .eq('campaign_id', step.campaign_id)
          .gte('current_step', step.order_number);

        return {
          ...step,
          scheduled_contacts: totalContacts || 0,
          sent_contacts: sentContacts || 0,
        };
      }));

      setMessages(messagesWithCounts);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSaveEdit(message: CampaignMessage) {
    try {
      const { error } = await supabase
        .from('campaign_steps')
        .update({
          subject: editForm.subject,
          content: editForm.content,
        })
        .eq('id', message.id);

      if (error) throw error;

      setEditingMessage(null);
      fetchMessages();
    } catch (error) {
      console.error('Error updating message:', error);
    }
  }

  function handleEdit(message: CampaignMessage) {
    setEditingMessage(message.id);
    setEditForm({
      subject: message.subject || '',
      content: message.content,
    });
  }

  function getMessageIcon(type: string) {
    switch (type) {
      case 'email':
        return <Mail className="h-5 w-5 text-blue-500" />;
      case 'sms':
        return <MessageSquare className="h-5 w-5 text-green-500" />;
      case 'voicemail':
        return <Voicemail className="h-5 w-5 text-purple-500" />;
    }
  }

  const filteredMessages = messages.filter(message =>
    message.campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    message.subject?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Campaign Messages</h1>
          <div className="mt-1 text-sm text-gray-500">
            {messages.length} total messages
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search messages..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMessages.map((message) => (
            <div
              key={message.id}
              className="bg-white rounded-lg shadow p-6"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    {getMessageIcon(message.type)}
                    <span className="font-medium text-gray-900 capitalize">
                      {message.type}
                    </span>
                    <span className="text-sm text-gray-500">
                      Step {message.order_number}
                    </span>
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        message.campaign.status === 'active'
                          ? 'bg-green-100 text-green-800'
                          : message.campaign.status === 'paused'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {message.campaign.status}
                    </span>
                  </div>

                  <div className="text-sm text-gray-500 mb-3">
                    Campaign: {message.campaign.name}
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Delay: {message.delay_hours}h
                    </div>
                    <div>
                      Progress: {message.sent_contacts} / {message.scheduled_contacts} contacts
                    </div>
                  </div>

                  {editingMessage === message.id ? (
                    <div className="space-y-4">
                      {message.type === 'email' && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Subject</label>
                          <input
                            type="text"
                            value={editForm.subject}
                            onChange={(e) => setEditForm({ ...editForm, subject: e.target.value })}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          />
                        </div>
                      )}
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Content</label>
                        <textarea
                          rows={4}
                          value={editForm.content}
                          onChange={(e) => setEditForm({ ...editForm, content: e.target.value })}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => setEditingMessage(null)}
                          className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                        >
                          <X className="h-4 w-4 mr-1" />
                          Cancel
                        </button>
                        <button
                          onClick={() => handleSaveEdit(message)}
                          className="flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
                        >
                          <Save className="h-4 w-4 mr-1" />
                          Save Changes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      {message.type === 'email' && message.subject && (
                        <div className="font-medium text-gray-900 mb-2">
                          Subject: {message.subject}
                        </div>
                      )}
                      <div className="text-gray-600 whitespace-pre-wrap">
                        {message.content}
                      </div>
                      <button
                        onClick={() => handleEdit(message)}
                        className="mt-4 flex items-center text-sm text-indigo-600 hover:text-indigo-700"
                      >
                        <Edit2 className="h-4 w-4 mr-1" />
                        Edit Message
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}