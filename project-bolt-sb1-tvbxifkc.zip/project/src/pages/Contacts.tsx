import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Mail, Phone, Building2, ChevronUp, ChevronDown, Calendar, Users, FileText, MessageSquare, Settings, Tag, Star, List } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import { format } from 'date-fns';
import CommunicationModal from '../components/CommunicationModal';
import CustomFieldManager from '../components/CustomFieldManager';
import TagManager from '../components/TagManager';
import ReviewRequestManager from '../components/ReviewRequestManager';
import ContactProfile from '../components/ContactProfile';
import ContactListManager from '../components/ContactListManager';

interface Contact {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  preferred_language: string;
  contact_preference: string;
  company_id: string;
  last_contacted: string;
  company?: {
    name: string;
  };
  custom_fields?: Record<string, any>;
  tags?: string[];
}

const LANGUAGES = [
  'English',
  'Spanish',
  'French',
  'German',
  'Chinese',
  'Japanese',
  'Korean',
  'Arabic',
  'Portuguese',
  'Russian'
];

export default function Contacts() {
  const { user } = useAuthStore();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showCommunicationModal, setShowCommunicationModal] = useState(false);
  const [showCustomFieldManager, setShowCustomFieldManager] = useState(false);
  const [showTagManager, setShowTagManager] = useState(false);
  const [showReviewManager, setShowReviewManager] = useState(false);
  const [showListManager, setShowListManager] = useState(false);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [customFields, setCustomFields] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    preferred_language: 'English',
    contact_preference: 'email'
  });

  useEffect(() => {
    fetchContacts();
    fetchCustomFields();
  }, [user]);

  async function fetchContacts() {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select(`
          *,
          company:companies(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Fetch custom field values for each contact
      const contactsWithFields = await Promise.all((data || []).map(async (contact) => {
        const { data: fieldValues } = await supabase
          .from('custom_field_values')
          .select('field_id, value')
          .eq('entity_id', contact.id);

        const customFieldValues = (fieldValues || []).reduce((acc, { field_id, value }) => ({
          ...acc,
          [field_id]: value
        }), {});

        return {
          ...contact,
          custom_fields: customFieldValues
        };
      }));

      setContacts(contactsWithFields);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchCustomFields() {
    try {
      const { data, error } = await supabase
        .from('custom_fields')
        .select('*')
        .eq('entity_type', 'contact')
        .order('display_order');

      if (error) throw error;
      setCustomFields(data || []);
    } catch (error) {
      console.error('Error fetching custom fields:', error);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const formattedData = {
        ...formData,
        owner_id: user?.id,
      };

      let error;
      if (editingContact) {
        ({ error } = await supabase
          .from('contacts')
          .update(formattedData)
          .eq('id', editingContact.id));
      } else {
        ({ error } = await supabase.from('contacts').insert([formattedData]));
      }

      if (error) throw error;
      
      setShowModal(false);
      setEditingContact(null);
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        preferred_language: 'English',
        contact_preference: 'email'
      });
      fetchContacts();
    } catch (error) {
      console.error('Error saving contact:', error);
    }
  }

  function handleEdit(contact: Contact) {
    setEditingContact(contact);
    setFormData({
      first_name: contact.first_name,
      last_name: contact.last_name,
      email: contact.email || '',
      phone: contact.phone || '',
      preferred_language: contact.preferred_language || 'English',
      contact_preference: contact.contact_preference || 'email'
    });
    setShowModal(true);
  }

  async function handleDelete(id: string) {
    if (!window.confirm('Are you sure you want to delete this contact?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('contacts')
        .delete()
        .eq('id', id);

      if (error) throw error;
      fetchContacts();
    } catch (error) {
      console.error('Error deleting contact:', error);
    }
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Contacts</h1>
          <div className="mt-1 text-sm text-gray-500">
            {contacts.length} total contacts
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCustomFieldManager(true)}
            className="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 flex items-center gap-2"
          >
            <Settings className="h-4 w-4" />
            Custom Fields
          </button>
          <button
            onClick={() => setShowTagManager(true)}
            className="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 flex items-center gap-2"
          >
            <Tag className="h-4 w-4" />
            Tags
          </button>
          <button
            onClick={() => setShowListManager(true)}
            className="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 flex items-center gap-2"
          >
            <List className="h-4 w-4" />
            Lists
          </button>
          <button
            onClick={() => setShowReviewManager(true)}
            className="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 flex items-center gap-2"
          >
            <Star className="h-4 w-4" />
            Request Reviews
          </button>
          <button
            onClick={() => {
              setEditingContact(null);
              setFormData({
                first_name: '',
                last_name: '',
                email: '',
                phone: '',
                preferred_language: 'English',
                contact_preference: 'email'
              });
              setShowModal(true);
            }}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700"
          >
            <Plus className="h-4 w-4" />
            Add Contact
          </button>
        </div>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search contacts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Contacted
                </th>
                {customFields.map(field => (
                  <th key={field.id} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {field.label}
                  </th>
                ))}
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {contacts.map((contact) => (
                <tr 
                  key={contact.id} 
                  className="hover:bg-gray-50 cursor-pointer"
                  onClick={() => setSelectedContact(contact)}
                >
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900">
                      {contact.first_name} {contact.last_name}
                    </div>
                    <div className="mt-1 space-y-1">
                      {contact.email && (
                        <div className="flex items-center text-sm text-gray-500">
                          <Mail className="h-4 w-4 mr-2" />
                          <a href={`mailto:${contact.email}`} className="hover:text-indigo-600">
                            {contact.email}
                          </a>
                        </div>
                      )}
                      {contact.phone && (
                        <div className="flex items-center text-sm text-gray-500">
                          <Phone className="h-4 w-4 mr-2" />
                          <a href={`tel:${contact.phone}`} className="hover:text-indigo-600">
                            {contact.phone}
                          </a>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center text-sm text-gray-900">
                      <Building2 className="h-4 w-4 mr-2 text-gray-400" />
                      {contact.company?.name || '-'}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {contact.last_contacted
                      ? format(new Date(contact.last_contacted), 'MMM d, yyyy')
                      : '-'}
                  </td>
                  {customFields.map(field => (
                    <td key={field.id} className="px-6 py-4 text-sm text-gray-500">
                      {contact.custom_fields?.[field.id] || '-'}
                    </td>
                  ))}
                  <td className="px-6 py-4 text-right text-sm font-medium">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedContact(contact);
                        setShowCommunicationModal(true);
                      }}
                      className="text-indigo-600 hover:text-indigo-900 mr-3"
                      title="Send message"
                    >
                      <MessageSquare className="h-4 w-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(contact);
                      }}
                      className="text-indigo-600 hover:text-indigo-900 mr-3"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(contact.id);
                      }}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add/Edit Contact Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">
              {editingContact ? 'Edit Contact' : 'Add New Contact'}
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">First Name</label>
                  <input
                    type="text"
                    value={formData.first_name}
                    onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Last Name</label>
                  <input
                    type="text"
                
                    value={formData.last_name}
                    onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Preferred Language</label>
                  <select
                    value={formData.preferred_language}
                    onChange={(e) => setFormData({ ...formData, preferred_language: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    {LANGUAGES.map((language) => (
                      <option key={language} value={language}>
                        {language}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Contact Preference</label>
                  <select
                    value={formData.contact_preference}
                    onChange={(e) => setFormData({ ...formData, contact_preference: e.target.value })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  >
                    <option value="email">Email</option>
                    <option value="phone">Phone</option>
                    <option value="sms">SMS</option>
                  </select>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
                >
                  {editingContact ? 'Update Contact' : 'Add Contact'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Communication Modal */}
      {showCommunicationModal && selectedContact && (
        <CommunicationModal
          isOpen={showCommunicationModal}
          onClose={() => {
            setShowCommunicationModal(false);
            setSelectedContact(null);
          }}
          contact={selectedContact}
        />
      )}

      {/* Custom Field Manager */}
      {showCustomFieldManager && (
        <CustomFieldManager
          entityType="contact"
          onClose={() => setShowCustomFieldManager(false)}
          onFieldsChange={() => {
            fetchCustomFields();
            fetchContacts();
          }}
        />
      )}

      {/* Tag Manager */}
      {showTagManager && (
        <TagManager
          entityType="contact"
          onClose={() => setShowTagManager(false)}
          onTagsChange={fetchContacts}
        />
      )}

      {/* List Manager */}
      {showListManager && (
        <ContactListManager
          onClose={() => setShowListManager(false)}
          onListsChange={fetchContacts}
        />
      )}

      {/* Review Manager */}
      {showReviewManager && (
        <ReviewRequestManager
          onClose={() => setShowReviewManager(false)}
        />
      )}

      {selectedContact && !showCommunicationModal && (
        <ContactProfile
          contact={selectedContact}
          onClose={() => setSelectedContact(null)}
          onUpdate={() => {
            fetchContacts();
            setSelectedContact(null);
          }}
        />
      )}
    </div>
  );
}