import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Building2, ChevronUp, ChevronDown, Calendar, Users, FileText, BadgeDollarSign, Settings } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import { format } from 'date-fns';
import { PipelineView } from '../components/PipelineView';
import PipelineStageManager from '../components/PipelineStageManager';

interface Deal {
  id: string;
  title: string;
  contact_id: string;
  amount: number;
  stage_id: string;
  status: string;
  close_date: string;
  probability: number;
  notes: string;
  created_at: string;
  contact?: {
    first_name: string;
    last_name: string;
    company?: {
      name: string;
    };
  };
  activities: number;
  contacts: number;
  documents: number;
}

interface Contact {
  id: string;
  first_name: string;
  last_name: string;
  company?: {
    name: string;
  };
}

interface PipelineStage {
  id: string;
  name: string;
  description: string;
  color: string;
  order_number: number;
  tasks: string[];
  automations: string[];
  is_closed: boolean;
  is_won: boolean;
  is_system: boolean;
  icon: string;
  probability: number;
}

export default function Deals() {
  const { user } = useAuthStore();
  const [deals, setDeals] = useState<Deal[]>([]);
  const [stages, setStages] = useState<PipelineStage[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showStageManager, setShowStageManager] = useState(false);
  const [editingDeal, setEditingDeal] = useState<Deal | null>(null);
  const [filter, setFilter] = useState<'all' | 'open' | 'won' | 'lost'>('all');
  const [viewMode, setViewMode] = useState<'table' | 'pipeline'>('pipeline');
  const [formData, setFormData] = useState({
    title: '',
    contact_id: '',
    amount: '',
    stage_id: '',
    status: 'open',
    close_date: '',
    probability: '0',
    notes: '',
  });

  useEffect(() => {
    fetchDeals();
    fetchStages();
    fetchContacts();
  }, [user]);

  async function fetchDeals() {
    try {
      const { data, error } = await supabase
        .from('deals')
        .select(`
          *,
          contact:contacts(
            first_name,
            last_name,
            company:companies(name)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const dealsWithCounts = await Promise.all((data || []).map(async (deal) => {
        const [
          { count: activities },
          { count: contacts },
          { count: documents }
        ] = await Promise.all([
          supabase.from('activities').select('*', { count: 'exact' }).eq('deal_id', deal.id),
          supabase.from('deal_contacts').select('*', { count: 'exact' }).eq('deal_id', deal.id),
          supabase.from('documents').select('*', { count: 'exact' }).eq('deal_id', deal.id)
        ]);

        return {
          ...deal,
          activities: activities || 0,
          contacts: contacts || 0,
          documents: documents || 0
        };
      }));

      setDeals(dealsWithCounts);
    } catch (error) {
      console.error('Error fetching deals:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchStages() {
    try {
      const { data, error } = await supabase
        .from('pipeline_stages')
        .select('*')
        .order('order_number');

      if (error) throw error;
      setStages(data || []);
    } catch (error) {
      console.error('Error fetching stages:', error);
    }
  }

  async function fetchContacts() {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select(`
          id,
          first_name,
          last_name,
          company:companies(name)
        `)
        .order('last_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    }
  }

  async function handleStageChange(dealId: string, fromStageId: string, toStageId: string) {
    try {
      const toStage = stages.find(s => s.id === toStageId);
      if (!toStage) return;

      const { error } = await supabase
        .from('deals')
        .update({ 
          stage_id: toStageId,
          status: toStage.is_closed ? (toStage.is_won ? 'won' : 'lost') : 'open'
        })
        .eq('id', dealId);

      if (error) throw error;
      fetchDeals();
    } catch (error) {
      console.error('Error updating deal stage:', error);
    }
  }

  const pipelineStages = stages.map(stage => ({
    id: stage.id,
    name: stage.name,
    description: stage.description,
    color: stage.color,
    icon: stage.icon,
    tasks: stage.tasks || [],
    automations: stage.automations || [],
    probability: stage.probability,
    is_system: stage.is_system,
    deals: deals.filter(deal => deal.stage_id === stage.id),
  }));

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Deals</h1>
          <div className="mt-1 text-sm text-gray-500">
            {deals.length} total deals
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('pipeline')}
              className={`px-4 py-2 ${
                viewMode === 'pipeline'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Pipeline
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-4 py-2 ${
                viewMode === 'table'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Table
            </button>
          </div>
          <button
            onClick={() => setShowStageManager(true)}
            className="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 flex items-center gap-2"
          >
            <Settings className="h-4 w-4" />
            Manage Stages
          </button>
          <button
            onClick={() => {
              setEditingDeal(null);
              setShowModal(true);
            }}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700"
          >
            <Plus className="h-4 w-4" />
            Add Deal
          </button>
        </div>
      </div>

      {viewMode === 'pipeline' ? (
        <div className="h-[calc(100vh-12rem)]">
          <PipelineView
            stages={pipelineStages}
            onStageChange={handleStageChange}
            onAddDeal={() => {
              setEditingDeal(null);
              setShowModal(true);
            }}
            onStageDeleted={fetchStages}
          />
        </div>
      ) : (
        // Table view code remains unchanged
        <div>Table view</div>
      )}

      {/* Stage Manager Modal */}
      {showStageManager && (
        <PipelineStageManager
          stages={stages}
          onStagesChange={(newStages) => {
            setStages(newStages);
            setShowStageManager(false);
            fetchStages();
          }}
          onClose={() => setShowStageManager(false)}
        />
      )}

      {/* Add/Edit Deal Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          {/* Deal form modal content */}
        </div>
      )}
    </div>
  );
}