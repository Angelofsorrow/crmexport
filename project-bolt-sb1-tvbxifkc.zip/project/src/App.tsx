import React, { useEffect, startTransition, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, NavLink } from 'react-router-dom';
import { useAuthStore } from './store/auth';
import { Users, BadgeDollarSign, CalendarClock, FileText, LogOut, Send, Home, Calculator, Inbox, Calendar, Settings, Building2 } from 'lucide-react';
import { supabase } from './lib/supabase';
import AIAssistant from './components/AIAssistant';
import { ErrorBoundary } from './components/ErrorBoundary';

// Lazy load components with error boundaries
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const Companies = React.lazy(() => import('./pages/Companies'));
const Contacts = React.lazy(() => import('./pages/Contacts'));
const Deals = React.lazy(() => import('./pages/Deals'));
const Activities = React.lazy(() => import('./pages/Activities'));
const Documents = React.lazy(() => import('./pages/Documents'));
const Campaigns = React.lazy(() => import('./pages/Campaigns'));
const CampaignEditor = React.lazy(() => import('./pages/CampaignEditor'));
const LoanApplications = React.lazy(() => import('./pages/LoanApplications'));
const LoanProducts = React.lazy(() => import('./pages/LoanProducts'));
const InboxPage = React.lazy(() => import('./pages/Inbox'));
const CalendarPage = React.lazy(() => import('./pages/Calendar'));
const SettingsPage = React.lazy(() => import('./pages/Settings'));
const OrganizationsPage = React.lazy(() => import('./pages/Organizations'));
const Login = React.lazy(() => import('./pages/Login'));

const navigation = [
  { name: 'Dashboard', icon: Home, path: '/' },
  { name: 'Calendar', icon: Calendar, path: '/calendar' },
  { name: 'Inbox', icon: Inbox, path: '/inbox' },
  { name: 'Contacts', icon: Users, path: '/contacts' },
  { name: 'Deals', icon: BadgeDollarSign, path: '/deals' },
  { name: 'Activities', icon: CalendarClock, path: '/activities' },
  { name: 'Documents', icon: FileText, path: '/documents' },
  { name: 'Campaigns', icon: Send, path: '/campaigns' },
  { name: 'Loan Products', icon: Calculator, path: '/loan-products' },
  { name: 'Loan Applications', icon: Calculator, path: '/loan-applications' },
  { name: 'Organizations', icon: Building2, path: '/organizations' },
  { name: 'Settings', icon: Settings, path: '/settings' },
];

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center h-full">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
    </div>
  );
}

function App() {
  const { user, loading, setUser, signOut, organization, whitelabelConfig } = useAuthStore();

  useEffect(() => {
    // Initialize auth state
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      startTransition(() => {
        setUser(session?.user ?? null);
      });
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [setUser]);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {user ? (
          <div className="flex h-screen">
            {/* Sidebar */}
            <div className="w-64 bg-white shadow-lg flex flex-col">
              <div className="p-6">
                {whitelabelConfig?.logo_url ? (
                  <img 
                    src={whitelabelConfig.logo_url} 
                    alt={whitelabelConfig.name || 'Logo'} 
                    className="h-8 w-auto"
                  />
                ) : (
                  <h1 className="text-2xl font-bold text-gray-900">
                    {organization?.name || 'CRM System'}
                  </h1>
                )}
              </div>
              <nav className="flex-1 mt-6">
                {navigation.map((item) => (
                  <NavLink
                    key={item.name}
                    to={item.path}
                    className={({ isActive }) =>
                      `flex items-center px-6 py-3 text-gray-600 hover:bg-gray-50 hover:text-gray-900 ${
                        isActive ? 'bg-gray-50 text-gray-900 border-r-4 border-indigo-600' : ''
                      }`
                    }
                  >
                    <item.icon className="h-5 w-5 mr-3" />
                    {item.name}
                  </NavLink>
                ))}
              </nav>
              <div className="p-4 border-t">
                <button
                  onClick={() => {
                    startTransition(() => {
                      signOut();
                    });
                  }}
                  className="flex items-center w-full px-4 py-2 text-gray-600 hover:bg-gray-50 hover:text-gray-900 rounded-lg"
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Sign out
                </button>
              </div>
            </div>

            {/* Main content */}
            <div className="flex-1 overflow-auto">
              <ErrorBoundary>
                <Suspense fallback={<LoadingSpinner />}>
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/calendar" element={<CalendarPage />} />
                    <Route path="/companies" element={<Companies />} />
                    <Route path="/contacts" element={<Contacts />} />
                    <Route path="/deals" element={<Deals />} />
                    <Route path="/activities" element={<Activities />} />
                    <Route path="/documents" element={<Documents />} />
                    <Route path="/campaigns" element={<Campaigns />} />
                    <Route path="/campaigns/:id" element={<CampaignEditor />} />
                    <Route path="/loan-products" element={<LoanProducts />} />
                    <Route path="/loan-applications" element={<LoanApplications />} />
                    <Route path="/inbox" element={<InboxPage />} />
                    <Route path="/organizations" element={<OrganizationsPage />} />
                    <Route path="/settings" element={<SettingsPage />} />
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </Suspense>
              </ErrorBoundary>
            </div>

            {/* AI Assistant */}
            <AIAssistant />
          </div>
        ) : (
          <ErrorBoundary>
            <Suspense fallback={<LoadingSpinner />}>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="*" element={<Navigate to="/login" replace />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        )}
      </div>
    </Router>
  );
}

export default App;