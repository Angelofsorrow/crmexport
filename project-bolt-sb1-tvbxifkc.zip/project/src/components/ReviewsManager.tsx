import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Star, MessageSquare, CheckCircle, XCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';

interface Review {
  id: string;
  contact_id: string;
  rating: number;
  content: string;
  status: 'pending' | 'approved' | 'rejected';
  is_published: boolean;
  submitted_at: string;
  reviewed_at?: string;
  contact?: {
    first_name: string;
    last_name: string;
    email: string;
  };
  responses?: Array<{
    id: string;
    content: string;
    is_public: boolean;
    created_at: string;
  }>;
}

export default function ReviewsManager() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [expandedReview, setExpandedReview] = useState<string | null>(null);
  const [responseContent, setResponseContent] = useState('');
  const [isPublicResponse, setIsPublicResponse] = useState(true);

  useEffect(() => {
    fetchReviews();
  }, [filter]);

  async function fetchReviews() {
    try {
      setLoading(true);
      let query = supabase
        .from('reviews')
        .select(`
          *,
          contact:contacts(
            first_name,
            last_name,
            email
          ),
          responses:review_responses(
            id,
            content,
            is_public,
            created_at
          )
        `)
        .order('submitted_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data, error } = await query;

      if (error) throw error;
      setReviews(data || []);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleStatusChange(reviewId: string, newStatus: 'approved' | 'rejected') {
    try {
      const { error } = await supabase
        .from('reviews')
        .update({
          status: newStatus,
          is_published: newStatus === 'approved',
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id
        })
        .eq('id', reviewId);

      if (error) throw error;
      fetchReviews();
    } catch (error) {
      console.error('Error updating review status:', error);
    }
  }

  async function handleAddResponse(reviewId: string) {
    try {
      const { error } = await supabase
        .from('review_responses')
        .insert([{
          review_id: reviewId,
          content: responseContent,
          is_public: isPublicResponse
        }]);

      if (error) throw error;

      setResponseContent('');
      setIsPublicResponse(true);
      fetchReviews();
    } catch (error) {
      console.error('Error adding response:', error);
    }
  }

  function renderStars(rating: number) {
    return [...Array(5)].map((_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Reviews Management</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 text-sm rounded-md ${
              filter === 'all'
                ? 'bg-gray-200 text-gray-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1 text-sm rounded-md ${
              filter === 'pending'
                ? 'bg-yellow-100 text-yellow-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setFilter('approved')}
            className={`px-3 py-1 text-sm rounded-md ${
              filter === 'approved'
                ? 'bg-green-100 text-green-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Approved
          </button>
          <button
            onClick={() => setFilter('rejected')}
            className={`px-3 py-1 text-sm rounded-md ${
              filter === 'rejected'
                ? 'bg-red-100 text-red-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Rejected
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <div key={review.id} className="bg-white rounded-lg shadow">
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex">{renderStars(review.rating)}</div>
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          review.status === 'approved'
                            ? 'bg-green-100 text-green-800'
                            : review.status === 'rejected'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {review.status}
                      </span>
                    </div>
                    <div className="text-sm text-gray-500 mb-2">
                      From: {review.contact?.first_name} {review.contact?.last_name} ({review.contact?.email})
                    </div>
                    <div className="text-sm text-gray-500 mb-4">
                      Submitted: {format(new Date(review.submitted_at), 'MMM d, yyyy h:mm a')}
                    </div>
                    <p className="text-gray-700">{review.content}</p>
                  </div>
                  <button
                    onClick={() => setExpandedReview(
                      expandedReview === review.id ? null : review.id
                    )}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    {expandedReview === review.id ? (
                      <ChevronUp className="h-5 w-5" />
                    ) : (
                      <ChevronDown className="h-5 w-5" />
                    )}
                  </button>
                </div>

                {expandedReview === review.id && (
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    {/* Review Actions */}
                    {review.status === 'pending' && (
                      <div className="flex gap-2 mb-6">
                        <button
                          onClick={() => handleStatusChange(review.id, 'approved')}
                          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleStatusChange(review.id, 'rejected')}
                          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                        >
                          <XCircle className="h-4 w-4" />
                          Reject
                        </button>
                      </div>
                    )}

                    {/* Responses */}
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Responses</h4>
                      {review.responses?.map((response) => (
                        <div
                          key={response.id}
                          className="bg-gray-50 rounded-lg p-4"
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <MessageSquare className="h-4 w-4 text-gray-400" />
                            <span className="text-sm text-gray-500">
                              {format(new Date(response.created_at), 'MMM d, yyyy h:mm a')}
                            </span>
                            {response.is_public && (
                              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                                Public
                              </span>
                            )}
                          </div>
                          <p className="text-gray-700">{response.content}</p>
                        </div>
                      ))}

                      {/* Add Response Form */}
                      <div className="mt-4">
                        <textarea
                          value={responseContent}
                          onChange={(e) => setResponseContent(e.target.value)}
                          placeholder="Write a response..."
                          rows={3}
                          className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                        <div className="mt-2 flex items-center justify-between">
                          <label className="flex items-center">
                            <input
                              type="checkbox"
                              checked={isPublicResponse}
                              onChange={(e) => setIsPublicResponse(e.target.checked)}
                              className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                            <span className="ml-2 text-sm text-gray-600">
                              Make response public
                            </span>
                          </label>
                          <button
                            onClick={() => handleAddResponse(review.id)}
                            disabled={!responseContent.trim()}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                          >
                            Add Response
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}