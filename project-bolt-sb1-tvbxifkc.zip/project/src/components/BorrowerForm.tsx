import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { borrowerSchema } from '../lib/types';
import type { Borrower, Contact } from '../lib/types';
import { X } from 'lucide-react';

interface BorrowerFormProps {
  onSubmit: (data: Borrower) => void;
  onCancel: () => void;
  initialData?: Borrower;
  contacts: Contact[];
}

export default function BorrowerForm({ onSubmit, onCancel, initialData, contacts }: BorrowerFormProps) {
  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    resolver: zodResolver(borrowerSchema),
    defaultValues: {
      ...initialData,
      bankruptcy_history: initialData?.bankruptcy_history || false,
      foreclosure_history: initialData?.foreclosure_history || false,
    }
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-2 gap-6">
        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Contact</label>
          <select
            {...register('contact_id')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="">Select contact</option>
            {contacts.map((contact) => (
              <option key={contact.id} value={contact.id}>
                {contact.first_name} {contact.last_name}
              </option>
            ))}
          </select>
          {errors.contact_id && (
            <p className="mt-1 text-sm text-red-600">{errors.contact_id.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Credit Score</label>
          <input
            type="number"
            min="300"
            max="850"
            {...register('credit_score')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          />
          {errors.credit_score && (
            <p className="mt-1 text-sm text-red-600">{errors.credit_score.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Monthly Income</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500 sm:text-sm">$</span>
            </div>
            <input
              type="number"
              {...register('monthly_income')}
              className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          {errors.monthly_income && (
            <p className="mt-1 text-sm text-red-600">{errors.monthly_income.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Monthly Debts</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500 sm:text-sm">$</span>
            </div>
            <input
              type="number"
              {...register('monthly_debts')}
              className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          {errors.monthly_debts && (
            <p className="mt-1 text-sm text-red-600">{errors.monthly_debts.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Employment Status</label>
          <select
            {...register('employment_status')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="">Select status</option>
            <option value="Employed">Employed</option>
            <option value="Self-Employed">Self-Employed</option>
            <option value="Retired">Retired</option>
            <option value="Unemployed">Unemployed</option>
          </select>
          {errors.employment_status && (
            <p className="mt-1 text-sm text-red-600">{errors.employment_status.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Years at Current Employment</label>
          <input
            type="number"
            step="0.1"
            {...register('employment_years')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          />
          {errors.employment_years && (
            <p className="mt-1 text-sm text-red-600">{errors.employment_years.message}</p>
          )}
        </div>

        <div>
          <div className="flex items-center">
            <input
              type="checkbox"
              {...register('bankruptcy_history')}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-900">
              Bankruptcy History
            </label>
          </div>
          {errors.bankruptcy_history && (
            <p className="mt-1 text-sm text-red-600">{errors.bankruptcy_history.message}</p>
          )}
        </div>

        <div>
          <div className="flex items-center">
            <input
              type="checkbox"
              {...register('foreclosure_history')}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-900">
              Foreclosure History
            </label>
          </div>
          {errors.foreclosure_history && (
            <p className="mt-1 text-sm text-red-600">{errors.foreclosure_history.message}</p>
          )}
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md"
        >
          {initialData ? 'Update Borrower' : 'Add Borrower'}
        </button>
      </div>
    </form>
  );
}