import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loanApplicationSchema } from '../lib/types';
import { calculateMonthlyPayment, calculateLTV, calculateDTI } from '../lib/calculations';
import type { LoanProduct, Property, Borrower, LoanApplication } from '../lib/types';

interface LoanApplicationFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: LoanApplication;
  loanProducts: LoanProduct[];
  properties: Property[];
  borrowers: Borrower[];
}

export default function LoanApplicationForm({
  onSubmit,
  onCancel,
  initialData,
  loanProducts,
  properties,
  borrowers
}: LoanApplicationFormProps) {
  const [selectedLoanProduct, setSelectedLoanProduct] = useState<LoanProduct | null>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [selectedBorrower, setSelectedBorrower] = useState<Borrower | null>(null);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm({
    resolver: zodResolver(loanApplicationSchema),
    defaultValues: initialData || {
      status: 'draft',
      stage: 'initial_review',
      application_date: new Date().toISOString().split('T')[0]
    }
  });

  const watchLoanAmount = watch('loan_amount');
  const watchDownPayment = watch('down_payment');
  const watchInterestRate = watch('interest_rate');
  const watchTermYears = watch('term_years');
  const watchLoanProductId = watch('loan_product_id');
  const watchPropertyId = watch('property_id');
  const watchPrimaryBorrowerId = watch('primary_borrower_id');

  useEffect(() => {
    if (watchLoanProductId) {
      const product = loanProducts.find(p => p.id === watchLoanProductId);
      setSelectedLoanProduct(product || null);

      // Set default interest rate based on product's range
      if (product?.interest_rate_range) {
        const range = typeof product.interest_rate_range === 'string' 
          ? JSON.parse(product.interest_rate_range)
          : product.interest_rate_range;
        setValue('interest_rate', range.min);
      }

      // Set default term if only one option available
      if (product?.term_years && product.term_years.length === 1) {
        setValue('term_years', product.term_years[0]);
      }
    }
  }, [watchLoanProductId, loanProducts, setValue]);

  useEffect(() => {
    if (watchPropertyId) {
      const property = properties.find(p => p.id === watchPropertyId);
      setSelectedProperty(property || null);
    }
  }, [watchPropertyId, properties]);

  useEffect(() => {
    if (watchPrimaryBorrowerId) {
      const borrower = borrowers.find(b => b.id === watchPrimaryBorrowerId);
      setSelectedBorrower(borrower || null);
    }
  }, [watchPrimaryBorrowerId, borrowers]);

  // Calculate monthly payment whenever relevant fields change
  useEffect(() => {
    if (watchLoanAmount && watchInterestRate && watchTermYears) {
      const payment = calculateMonthlyPayment(
        parseFloat(watchLoanAmount),
        parseFloat(watchInterestRate),
        parseInt(watchTermYears)
      );
      setValue('estimated_monthly_payment', payment);
    }
  }, [watchLoanAmount, watchInterestRate, watchTermYears, setValue]);

  // Calculate metrics for display
  const metrics = {
    ltv: selectedProperty && watchLoanAmount
      ? calculateLTV(
          parseFloat(watchLoanAmount),
          selectedProperty.purchase_price || selectedProperty.estimated_value || 0
        )
      : null,
    dti: selectedBorrower && selectedBorrower.monthly_income
      ? calculateDTI(
          selectedBorrower.monthly_debts || 0,
          selectedBorrower.monthly_income
        )
      : null
  };

  // Check if the selected property type is eligible for the loan product
  const isPropertyTypeEligible = selectedLoanProduct && selectedProperty
    ? selectedLoanProduct.eligible_property_types?.includes(selectedProperty.property_type)
    : true;

  // Check if the borrower meets the credit score requirement
  const meetsCreditScore = selectedLoanProduct && selectedBorrower
    ? (selectedBorrower.credit_score || 0) >= selectedLoanProduct.min_credit_score
    : true;

  // Check if the LTV meets the requirement
  const meetsLTV = selectedLoanProduct && metrics.ltv
    ? metrics.ltv <= selectedLoanProduct.max_ltv
    : true;

  // Check if the DTI meets the requirement
  const meetsDTI = selectedLoanProduct && metrics.dti && selectedLoanProduct.dti_limits
    ? metrics.dti <= (typeof selectedLoanProduct.dti_limits === 'string' 
        ? JSON.parse(selectedLoanProduct.dti_limits).back 
        : selectedLoanProduct.dti_limits.back)
    : true;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-2 gap-6">
        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Loan Product</label>
          <select
            {...register('loan_product_id')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="">Select a loan product</option>
            {loanProducts.map((product) => (
              <option key={product.id} value={product.id}>
                {product.name} - {product.description}
              </option>
            ))}
          </select>
          {errors.loan_product_id && (
            <p className="mt-1 text-sm text-red-600">{errors.loan_product_id.message}</p>
          )}
          {selectedLoanProduct && (
            <div className="mt-2 text-sm text-gray-500">
              <ul className="list-disc pl-5 space-y-1">
                <li>Min Credit Score: {selectedLoanProduct.min_credit_score}</li>
                <li>Max LTV: {selectedLoanProduct.max_ltv}%</li>
                <li>Min Down Payment: {selectedLoanProduct.min_down_payment}%</li>
                <li>DTI Limits: Front {selectedLoanProduct.dti_limits?.front}%, Back {selectedLoanProduct.dti_limits?.back}%</li>
                <li>Eligible Property Types: {selectedLoanProduct.eligible_property_types?.join(', ')}</li>
              </ul>
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Property</label>
          <select
            {...register('property_id')}
            className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${
              !isPropertyTypeEligible ? 'border-red-300' : ''
            }`}
          >
            <option value="">Select a property</option>
            {properties.map((property) => (
              <option key={property.id} value={property.id}>
                {property.address}, {property.city}, {property.state} - {property.property_type}
              </option>
            ))}
          </select>
          {errors.property_id && (
            <p className="mt-1 text-sm text-red-600">{errors.property_id.message}</p>
          )}
          {!isPropertyTypeEligible && (
            <p className="mt-1 text-sm text-red-600">
              Property type not eligible for selected loan product
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Primary Borrower</label>
          <select
            {...register('primary_borrower_id')}
            className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${
              !meetsCreditScore ? 'border-red-300' : ''
            }`}
          >
            <option value="">Select a borrower</option>
            {borrowers.map((borrower) => (
              <option key={borrower.id} value={borrower.id}>
                {borrower.contact?.first_name} {borrower.contact?.last_name} 
                {borrower.credit_score ? ` (Credit: ${borrower.credit_score})` : ''}
              </option>
            ))}
          </select>
          {errors.primary_borrower_id && (
            <p className="mt-1 text-sm text-red-600">{errors.primary_borrower_id.message}</p>
          )}
          {!meetsCreditScore && (
            <p className="mt-1 text-sm text-red-600">
              Credit score below minimum requirement
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Co-Borrower (Optional)</label>
          <select
            {...register('co_borrower_id')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="">Select a co-borrower</option>
            {borrowers
              .filter(b => b.id !== watchPrimaryBorrowerId)
              .map((borrower) => (
                <option key={borrower.id} value={borrower.id}>
                  {borrower.contact?.first_name} {borrower.contact?.last_name}
                  {borrower.credit_score ? ` (Credit: ${borrower.credit_score})` : ''}
                </option>
              ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Loan Amount</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500 sm:text-sm">$</span>
            </div>
            <input
              type="number"
              {...register('loan_amount')}
              className={`pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${
                !meetsLTV ? 'border-red-300' : ''
              }`}
              placeholder="0.00"
            />
          </div>
          {errors.loan_amount && (
            <p className="mt-1 text-sm text-red-600">{errors.loan_amount.message}</p>
          )}
          {!meetsLTV && (
            <p className="mt-1 text-sm text-red-600">
              LTV ratio exceeds maximum allowed
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Down Payment</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500 sm:text-sm">$</span>
            </div>
            <input
              type="number"
              {...register('down_payment')}
              className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="0.00"
            />
          </div>
          {errors.down_payment && (
            <p className="mt-1 text-sm text-red-600">{errors.down_payment.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Interest Rate (%)</label>
          <input
            type="number"
            step="0.125"
            {...register('interest_rate')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          />
          {errors.interest_rate && (
            <p className="mt-1 text-sm text-red-600">{errors.interest_rate.message}</p>
          )}
          {selectedLoanProduct?.interest_rate_range && (
            <p className="mt-1 text-sm text-gray-500">
              Range: {selectedLoanProduct.interest_rate_range.min}% - {selectedLoanProduct.interest_rate_range.max}%
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Term (Years)</label>
          <select
            {...register('term_years')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="">Select term</option>
            {selectedLoanProduct?.term_years?.map((term) => (
              <option key={term} value={term}>{term}</option>
            ))}
          </select>
          {errors.term_years && (
            <p className="mt-1 text-sm text-red-600">{errors.term_years.message}</p>
          )}
        </div>
      </div>

      {/* Metrics Display */}
      <div className="bg-gray-50 p-4 rounded-lg grid grid-cols-2 gap-4">
        <div>
          <div className="text-sm font-medium text-gray-500">LTV Ratio</div>
          <div className="text-lg font-semibold text-gray-900">
            {metrics.ltv ? `${metrics.ltv.toFixed(2)}%` : '-'}
          </div>
        </div>
        <div>
          <div className="text-sm font-medium text-gray-500">DTI Ratio</div>
          <div className="text-lg font-semibold text-gray-900">
            {metrics.dti ? `${metrics.dti.toFixed(2)}%` : '-'}
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={!isPropertyTypeEligible || !meetsCreditScore || !meetsLTV || !meetsDTI}
          className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md disabled:opacity-50"
        >
          {initialData ? 'Update Application' : 'Create Application'}
        </button>
      </div>
    </form>
  );
}