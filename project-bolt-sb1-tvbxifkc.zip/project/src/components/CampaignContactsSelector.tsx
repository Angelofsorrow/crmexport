import React, { useState, useEffect } from 'react';
import { Search, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Contact {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  company?: {
    name: string;
  };
}

interface CampaignContactsSelectorProps {
  campaignId: string;
  onContactsSelected: () => void;
}

export default function CampaignContactsSelector({ campaignId, onContactsSelected }: CampaignContactsSelectorProps) {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContacts, setSelectedContacts] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchContacts();
    fetchExistingSelections();
  }, [campaignId]);

  async function fetchContacts() {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select(`
          *,
          company:companies(name)
        `)
        .order('last_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchExistingSelections() {
    try {
      const { data, error } = await supabase
        .from('campaign_contacts')
        .select('contact_id')
        .eq('campaign_id', campaignId);

      if (error) throw error;
      setSelectedContacts(new Set(data?.map(row => row.contact_id)));
    } catch (error) {
      console.error('Error fetching existing selections:', error);
    }
  }

  async function handleToggleContact(contactId: string) {
    try {
      if (selectedContacts.has(contactId)) {
        // Remove contact from campaign
        const { error } = await supabase
          .from('campaign_contacts')
          .delete()
          .eq('campaign_id', campaignId)
          .eq('contact_id', contactId);

        if (error) throw error;
        selectedContacts.delete(contactId);
      } else {
        // Add contact to campaign
        const { error } = await supabase
          .from('campaign_contacts')
          .insert([{
            campaign_id: campaignId,
            contact_id: contactId
          }]);

        if (error) throw error;
        selectedContacts.add(contactId);
      }

      setSelectedContacts(new Set(selectedContacts));
      onContactsSelected();
    } catch (error) {
      console.error('Error updating campaign contacts:', error);
    }
  }

  const filteredContacts = contacts.filter(contact =>
    `${contact.first_name} ${contact.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.company?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search contacts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto">
          {filteredContacts.map((contact) => (
            <div
              key={contact.id}
              className="flex items-center justify-between p-4 bg-white rounded-lg shadow"
            >
              <div>
                <div className="font-medium text-gray-900">
                  {contact.first_name} {contact.last_name}
                </div>
                <div className="text-sm text-gray-500">
                  {contact.company?.name}
                </div>
                <div className="text-sm text-gray-500">
                  {contact.email}
                </div>
              </div>
              <button
                onClick={() => handleToggleContact(contact.id)}
                className={`p-2 rounded-full ${
                  selectedContacts.has(contact.id)
                    ? 'bg-green-100 text-green-600'
                    : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                }`}
              >
                <Check className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}