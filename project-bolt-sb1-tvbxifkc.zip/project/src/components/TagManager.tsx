import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Tag } from '../lib/types';

interface TagManagerProps {
  entityType: 'contact' | 'deal' | 'company';
  onClose: () => void;
  onTagsChange: () => void;
}

const COLORS = [
  { name: 'Gray', value: 'bg-gray-100' },
  { name: 'Red', value: 'bg-red-100' },
  { name: 'Yellow', value: 'bg-yellow-100' },
  { name: 'Green', value: 'bg-green-100' },
  { name: 'Blue', value: 'bg-blue-100' },
  { name: 'Indigo', value: 'bg-indigo-100' },
  { name: 'Purple', value: 'bg-purple-100' },
  { name: 'Pink', value: 'bg-pink-100' }
];

export default function TagManager({ entityType, onClose, onTagsChange }: TagManagerProps) {
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    color: 'bg-gray-100'
  });

  React.useEffect(() => {
    fetchTags();
  }, []);

  async function fetchTags() {
    try {
      const { data, error } = await supabase
        .from('tags')
        .select('*')
        .eq('entity_type', entityType)
        .order('name');

      if (error) throw error;
      setTags(data || []);
    } catch (error) {
      console.error('Error fetching tags:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    try {
      const { error } = await supabase
        .from('tags')
        .insert([{
          ...formData,
          entity_type: entityType
        }]);

      if (error) throw error;

      fetchTags();
      onTagsChange();
      setFormData({
        name: '',
        color: 'bg-gray-100'
      });
    } catch (error) {
      console.error('Error creating tag:', error);
    }
  }

  async function handleDeleteTag(id: string) {
    if (!window.confirm('Are you sure you want to delete this tag?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('tags')
        .delete()
        .eq('id', id);

      if (error) throw error;

      fetchTags();
      onTagsChange();
    } catch (error) {
      console.error('Error deleting tag:', error);
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg w-full max-w-md my-8">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Manage Tags</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <form onSubmit={handleSubmit} className="mb-8">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Tag Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Color</label>
                <select
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  {COLORS.map(color => (
                    <option key={color.value} value={color.value}>
                      {color.name}
                    </option>
                  ))}
                </select>
              </div>
              <button
                type="submit"
                className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center justify-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Add Tag
              </button>
            </div>
          </form>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Existing Tags</h3>
            {loading ? (
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              </div>
            ) : (
              <div className="space-y-2">
                {tags.map(tag => (
                  <div
                    key={tag.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-2">
                      <div className={`w-4 h-4 rounded-full ${tag.color}`}></div>
                      <span>{tag.name}</span>
                    </div>
                    <button
                      onClick={() => handleDeleteTag(tag.id!)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}