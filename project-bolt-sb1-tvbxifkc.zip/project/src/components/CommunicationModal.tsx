import React, { useState, useEffect } from 'react';
import { X, Mail, MessageSquare, Voicemail, Loader2 } from 'lucide-react';
import { generateEmailResponse } from '../lib/openai';
import { sendEmail } from '../lib/email';
import { sendSMS, makeRinglessVoicemail } from '../lib/twilio';
import { supabase } from '../lib/supabase';

interface CommunicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  contact: {
    first_name: string;
    last_name: string;
    email?: string;
    phone?: string;
  };
  context?: string;
}

export default function CommunicationModal({ isOpen, onClose, contact, context = '' }: CommunicationModalProps) {
  const [activeTab, setActiveTab] = useState<'email' | 'sms' | 'voicemail'>('email');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState('');
  const [voicemailFile, setVoicemailFile] = useState<File | null>(null);
  const [emailAccount, setEmailAccount] = useState<any>(null);
  const [subject, setSubject] = useState('');

  useEffect(() => {
    fetchEmailAccount();
  }, []);

  async function fetchEmailAccount() {
    try {
      const { data: accounts, error } = await supabase
        .from('email_accounts')
        .select('*')
        .eq('is_active', true)
        .limit(1);

      if (error) throw error;
      if (accounts && accounts.length > 0) {
        setEmailAccount(accounts[0]);
      }
    } catch (error) {
      console.error('Error fetching email account:', error);
    }
  }

  async function handleGenerateResponse() {
    try {
      setLoading(true);
      const response = await generateEmailResponse(message, context);
      setAiSuggestion(response || '');
    } catch (error) {
      console.error('Error generating response:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSendEmail() {
    if (!emailAccount || !contact.email) return;

    try {
      setLoading(true);
      await sendEmail(emailAccount, {
        to: [contact.email],
        subject,
        body: message
      });

      // Update last_contacted
      await supabase
        .from('contacts')
        .update({ last_contacted: new Date().toISOString() })
        .eq('id', contact.id);

      onClose();
    } catch (error) {
      console.error('Error sending email:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSendSMS() {
    try {
      setLoading(true);
      await sendSMS(contact.phone!, message);
      onClose();
    } catch (error) {
      console.error('Error sending SMS:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSendVoicemail() {
    if (!voicemailFile) return;

    try {
      setLoading(true);
      // In a real application, you would first upload the voicemail file to a storage service
      // and then use the URL with Twilio
      const recordingUrl = 'https://your-storage-service.com/' + voicemailFile.name;
      await makeRinglessVoicemail(contact.phone!, recordingUrl);
      onClose();
    } catch (error) {
      console.error('Error sending voicemail:', error);
    } finally {
      setLoading(false);
    }
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-lg w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">
            Contact {contact.first_name} {contact.last_name}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setActiveTab('email')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'email'
                ? 'bg-indigo-100 text-indigo-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
            disabled={!contact.email}
          >
            <Mail className="h-4 w-4 mr-2" />
            Email
          </button>
          <button
            onClick={() => setActiveTab('sms')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'sms'
                ? 'bg-indigo-100 text-indigo-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
            disabled={!contact.phone}
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            SMS
          </button>
          <button
            onClick={() => setActiveTab('voicemail')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'voicemail'
                ? 'bg-indigo-100 text-indigo-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
            disabled={!contact.phone}
          >
            <Voicemail className="h-4 w-4 mr-2" />
            Voicemail
          </button>
        </div>

        {activeTab === 'email' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Enter email subject..."
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700">Message</label>
              <textarea
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Type your message here..."
              />
            </div>
            
            <div className="flex justify-between">
              <button
                onClick={handleGenerateResponse}
                disabled={loading || !message}
                className="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-md hover:bg-indigo-100 disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'Generate AI Response'
                )}
              </button>
              <button
                onClick={handleSendEmail}
                disabled={!message || !subject}
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50"
              >
                Send Email
              </button>
            </div>

            {aiSuggestion && (
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  AI Suggested Response
                </label>
                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="text-sm text-gray-800 whitespace-pre-wrap">{aiSuggestion}</p>
                  <button
                    onClick={() => setMessage(aiSuggestion)}
                    className="mt-2 text-sm text-indigo-600 hover:text-indigo-700"
                  >
                    Use this response
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'sms' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Message</label>
              <textarea
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                placeholder="Type your SMS message here..."
                maxLength={160}
              />
              <p className="mt-1 text-sm text-gray-500">
                {message.length}/160 characters
              </p>
            </div>
            
            <div className="flex justify-end">
              <button
                onClick={handleSendSMS}
                disabled={loading || !message}
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'Send SMS'
                )}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'voicemail' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Upload Voicemail Recording</label>
              <input
                type="file"
                accept="audio/*"
                onChange={(e) => setVoicemailFile(e.target.files?.[0] || null)}
                className="mt-1 block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-md file:border-0
                  file:text-sm file:font-medium
                  file:bg-indigo-50 file:text-indigo-700
                  hover:file:bg-indigo-100"
              />
            </div>
            
            <div className="flex justify-end">
              <button
                onClick={handleSendVoicemail}
                disabled={loading || !voicemailFile}
                className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'Send Voicemail'
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}