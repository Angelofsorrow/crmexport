import React, { useState } from 'react';
import { Users, Play, Pause, Trash2, ChevronDown } from 'lucide-react';

interface CampaignDetailsProps {
  campaign: {
    id: string;
    name: string;
    email?: string;
    phone_number?: string;
    timezone?: string;
    status: 'draft' | 'active' | 'paused' | 'completed';
  };
  onDelete: (id: string) => void;
  onStatusChange: (id: string, status: 'active' | 'paused') => void;
}

export default function CampaignDetails({ campaign, onDelete, onStatusChange }: CampaignDetailsProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            Campaign Details
            <span className="text-sm font-normal text-gray-500">
              <Users className="h-4 w-4 inline" /> (0)
            </span>
          </h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onDelete(campaign.id)}
              className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2"
            >
              <Trash2 className="h-4 w-4" />
              Delete Campaign
            </button>
            {campaign.status === 'active' ? (
              <button
                onClick={() => onStatusChange(campaign.id, 'paused')}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700"
              >
                <Pause className="h-4 w-4" />
                Pause Campaign
              </button>
            ) : (
              <button
                onClick={() => onStatusChange(campaign.id, 'active')}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700"
              >
                <Play className="h-4 w-4" />
                Start Campaign
              </button>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Campaign Name</label>
            <input
              type="text"
              value={campaign.name}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              readOnly
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Campaign Email Address</label>
            <input
              type="email"
              value={campaign.email || ''}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              readOnly
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Campaign Phone Number</label>
              <select
                value={campaign.phone_number}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                disabled
              >
                <option>Select a phone number</option>
              </select>
              <p className="mt-1 text-xs text-gray-500">
                You won't be able to change the number after a contact has been added
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Campaign Timezone</label>
              <select
                value={campaign.timezone}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                disabled
              >
                <option>Select timezone</option>
              </select>
              <p className="mt-1 text-xs text-gray-500">
                You won't be able to change the timezone after a contact has been added
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4">
            <span className="text-sm text-gray-600">
              If a message fails, pause campaign for that contact:
            </span>
            <button
              className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                false ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span className="sr-only">Enable notifications</span>
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                  false ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold mb-4">Connect Your Lead Source - Basic</h2>
            <p className="text-sm text-gray-600 mb-4">
              Connect your lead source below to start receiving leads inside this campaign.
            </p>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <button className="flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <Users className="h-4 w-4" />
                Add A Contact
              </button>
              <button className="flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                Upload Contact(s)
              </button>
            </div>

            <div className="space-y-2">
              <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Connect Via Facebook
              </button>
              <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Connect Via API
              </button>
              <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Connect Via Zapier
              </button>
            </div>
          </div>

          <div>
            <h3 className="font-medium text-gray-900 mb-2">Direct Integrations</h3>
            <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Connect Prospect Source
            </button>
          </div>

          <div>
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
            >
              Connect Your Lead Source - Advanced
              <ChevronDown className={`h-4 w-4 transform ${showAdvanced ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}