import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Star, Send, Loader2, CheckCircle, XCircle } from 'lucide-react';

interface ReviewRequestManagerProps {
  onClose: () => void;
}

interface Contact {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  tags?: string[];
}

export default function ReviewRequestManager({ onClose }: ReviewRequestManagerProps) {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedTag, setSelectedTag] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState(`Hi {first_name},

We hope you're enjoying our services! Your feedback means a lot to us. Could you take a moment to share your experience on Google Reviews?

Here's our Google Review link: {review_link}

Thank you for your time!

Best regards,
{sender_name}`);
  const [reviewLink, setReviewLink] = useState('');
  const [senderName, setSenderName] = useState('');
  const [sentCount, setSentCount] = useState(0);
  const [errorCount, setErrorCount] = useState(0);

  useEffect(() => {
    fetchTags();
  }, []);

  async function fetchTags() {
    try {
      const { data: tagData, error: tagError } = await supabase
        .from('tags')
        .select('name')
        .eq('entity_type', 'contact');

      if (tagError) throw tagError;
      setTags(tagData?.map(t => t.name) || []);
    } catch (error) {
      console.error('Error fetching tags:', error);
    }
  }

  async function fetchContacts() {
    try {
      setLoading(true);
      
      // Get contacts with the selected tag
      const { data: taggedContacts, error: contactsError } = await supabase
        .from('entity_tags')
        .select(`
          entity_id,
          tag:tags!inner(name),
          contact:contacts!inner(
            id,
            first_name,
            last_name,
            email
          )
        `)
        .eq('tags.name', selectedTag)
        .eq('tags.entity_type', 'contact');

      if (contactsError) throw contactsError;

      const contacts = taggedContacts?.map(tc => ({
        id: tc.contact.id,
        first_name: tc.contact.first_name,
        last_name: tc.contact.last_name,
        email: tc.contact.email
      })) || [];

      setContacts(contacts);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleSendReviews() {
    if (!reviewLink || !senderName) {
      alert('Please provide both a review link and sender name');
      return;
    }

    setSending(true);
    setSentCount(0);
    setErrorCount(0);

    try {
      for (const contact of contacts) {
        if (!contact.email) continue;

        try {
          // Replace placeholders in message
          const personalizedMessage = message
            .replace('{first_name}', contact.first_name)
            .replace('{review_link}', reviewLink)
            .replace('{sender_name}', senderName);

          // Create email activity
          const { error: emailError } = await supabase
            .from('activities')
            .insert([{
              type: 'email',
              title: 'Review Request Sent',
              description: personalizedMessage,
              contact_id: contact.id,
              owner_id: (await supabase.auth.getUser()).data.user?.id,
              created_at: new Date().toISOString()
            }]);

          if (emailError) throw emailError;

          // In a real implementation, this would integrate with your email service
          console.log('Sending review request to:', contact.email);
          
          // Create a tag for contacted contacts
          const { error: tagError } = await supabase
            .from('entity_tags')
            .insert([{
              entity_id: contact.id,
              tag_id: (await supabase
                .from('tags')
                .select('id')
                .eq('name', 'Review Requested')
                .single()
              ).data?.id
            }]);

          if (tagError) throw tagError;

          setSentCount(prev => prev + 1);
        } catch (error) {
          console.error(`Error sending review request to ${contact.email}:`, error);
          setErrorCount(prev => prev + 1);
        }
      }
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-400" />
            Review Request Manager
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <XCircle className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Tag Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Contact Tag
            </label>
            <div className="flex gap-2">
              <select
                value={selectedTag}
                onChange={(e) => setSelectedTag(e.target.value)}
                className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              >
                <option value="">Select a tag</option>
                {tags.map(tag => (
                  <option key={tag} value={tag}>{tag}</option>
                ))}
              </select>
              <button
                onClick={fetchContacts}
                disabled={!selectedTag || loading}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
              >
                Load Contacts
              </button>
            </div>
          </div>

          {/* Review Link */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Google Review Link
            </label>
            <input
              type="url"
              value={reviewLink}
              onChange={(e) => setReviewLink(e.target.value)}
              placeholder="https://g.page/r/..."
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>

          {/* Sender Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Sender Name
            </label>
            <input
              type="text"
              value={senderName}
              onChange={(e) => setSenderName(e.target.value)}
              placeholder="Your name"
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>

          {/* Message Template */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message Template
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={8}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
            <p className="mt-1 text-sm text-gray-500">
              Available placeholders: {'{first_name}'}, {'{review_link}'}, {'{sender_name}'}
            </p>
          </div>

          {/* Contact List */}
          {contacts.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">
                Selected Contacts ({contacts.length})
              </h3>
              <div className="max-h-40 overflow-y-auto border rounded-md">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {contacts.map(contact => (
                      <tr key={contact.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {contact.first_name} {contact.last_name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {contact.email}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Send Button */}
          <div className="flex justify-between items-center">
            <div className="text-sm text-gray-500">
              {sentCount > 0 && (
                <span className="flex items-center gap-1 text-green-600">
                  <CheckCircle className="h-4 w-4" />
                  {sentCount} sent successfully
                </span>
              )}
              {errorCount > 0 && (
                <span className="flex items-center gap-1 text-red-600 ml-4">
                  <XCircle className="h-4 w-4" />
                  {errorCount} failed
                </span>
              )}
            </div>
            <button
              onClick={handleSendReviews}
              disabled={contacts.length === 0 || sending || !reviewLink || !senderName}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
            >
              {sending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Send Review Requests
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}