import express from 'express';
import cors from 'cors';
import { google } from 'googleapis';
import { Client } from '@microsoft/microsoft-graph-client';
import { supabase } from '../lib/supabase';
import { format, parseISO } from 'date-fns';
import { zonedTimeToUtc } from 'date-fns-tz';

const app = express();

app.use(cors());
app.use(express.json());

// Google Calendar Setup
const GOOGLE_SCOPES = ['https://www.googleapis.com/auth/calendar'];

async function getGoogleAuth(refreshToken: string) {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );

  auth.setCredentials({ refresh_token: refreshToken });
  return auth;
}

// Microsoft Graph Setup
function getMicrosoftGraphClient(accessToken: string) {
  return Client.init({
    authProvider: (done) => {
      done(null, accessToken);
    }
  });
}

// Sync calendar events
app.post('/sync', async (req, res) => {
  try {
    const { data: accounts, error } = await supabase
      .from('email_accounts')
      .select('*')
      .eq('is_active', true);

    if (error) throw error;

    for (const account of accounts) {
      if (account.provider === 'google' && account.refresh_token) {
        await syncGoogleCalendar(account);
      } else if (account.provider === 'microsoft' && account.access_token) {
        await syncMicrosoftCalendar(account);
      }
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Error syncing calendars:', error);
    res.status(500).json({ error: 'Failed to sync calendars' });
  }
});

async function syncGoogleCalendar(account: any) {
  const auth = await getGoogleAuth(account.refresh_token);
  const calendar = google.calendar({ version: 'v3', auth });

  const timeMin = new Date();
  timeMin.setMonth(timeMin.getMonth() - 1);
  
  const timeMax = new Date();
  timeMax.setMonth(timeMax.getMonth() + 3);

  const response = await calendar.events.list({
    calendarId: 'primary',
    timeMin: timeMin.toISOString(),
    timeMax: timeMax.toISOString(),
    singleEvents: true,
    orderBy: 'startTime',
  });

  const events = response.data.items;
  
  // Upsert events to database
  for (const event of events) {
    await upsertCalendarEvent({
      source: 'google',
      sourceId: event.id,
      title: event.summary,
      description: event.description,
      location: event.location,
      start: event.start.dateTime || event.start.date,
      end: event.end.dateTime || event.end.date,
      allDay: !event.start.dateTime,
      attendees: event.attendees,
    });
  }
}

async function syncMicrosoftCalendar(account: any) {
  const client = getMicrosoftGraphClient(account.access_token);

  const timeMin = new Date();
  timeMin.setMonth(timeMin.getMonth() - 1);
  
  const timeMax = new Date();
  timeMax.setMonth(timeMax.getMonth() + 3);

  const response = await client
    .api('/me/calendar/events')
    .filter(`start/dateTime ge '${timeMin.toISOString()}' and end/dateTime le '${timeMax.toISOString()}'`)
    .get();

  const events = response.value;
  
  // Upsert events to database
  for (const event of events) {
    await upsertCalendarEvent({
      source: 'microsoft',
      sourceId: event.id,
      title: event.subject,
      description: event.bodyPreview,
      location: event.location?.displayName,
      start: event.start.dateTime,
      end: event.end.dateTime,
      allDay: event.isAllDay,
      attendees: event.attendees,
    });
  }
}

async function upsertCalendarEvent(event: any) {
  const { error } = await supabase
    .from('calendar_events')
    .upsert({
      source_id: event.sourceId,
      title: event.title,
      description: event.description,
      location: event.location,
      start: event.start,
      end: event.end,
      all_day: event.allDay,
      attendees: event.attendees,
    }, {
      onConflict: 'source,source_id'
    });

  if (error) throw error;
}

const PORT = process.env.CALENDAR_SERVICE_PORT || 3002;
app.listen(PORT, () => {
  console.log(`Calendar service running on port ${PORT}`);
});