import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';
import { handleCRMAction } from '../lib/aiAgent';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Get directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from root .env file
dotenv.config({ path: join(__dirname, '../../.env') });

// Initialize Supabase client
const supabase = createClient(
  process.env.VITE_SUPABASE_URL!,
  process.env.VITE_SUPABASE_ANON_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

const app = express();

// Enable CORS with proper configuration
app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  methods: ['GET', 'POST'],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Add types to express Request
declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Error:', err);
  res.status(500).json({ 
    error: err.message || 'An unexpected error occurred',
    details: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

// Auth middleware
async function authMiddleware(req: express.Request, res: express.Response, next: express.NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ error: 'No authorization header' });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error) {
      console.error('Auth error:', error);
      return res.status(401).json({ error: 'Invalid token' });
    }

    if (!user) {
      return res.status(401).json({ error: 'No user found' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    next(error);
  }
}

// Root endpoint
app.get('/', (req, res) => {
  res.json({ status: 'AI Agent is running' });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'AI Agent is running' });
});

// Process automation requests
app.post('/process', authMiddleware, async (req, res, next) => {
  try {
    const { type, data, eventDetails } = req.body;
    const user = req.user;

    // Validate request
    if (!type) {
      return res.status(400).json({ error: 'Automation type is required' });
    }

    if (!data && !eventDetails) {
      return res.status(400).json({ error: 'Either data or eventDetails must be provided' });
    }

    if (!user?.id) {
      return res.status(400).json({ error: 'User information is required' });
    }

    // Log request details in development
    if (process.env.NODE_ENV === 'development') {
      console.log('Processing automation request:', {
        type,
        data,
        eventDetails,
        userId: user.id
      });
    }

    try {
      // For calendar events, merge eventDetails into data
      const mergedData = type === 'create_calendar_event' ? { ...data, eventDetails } : data;
      
      const result = await handleCRMAction(type, mergedData, user);
      res.json(result);
    } catch (actionError: any) {
      console.error('Error handling CRM action:', actionError);
      res.status(500).json({ 
        error: actionError.message || 'Failed to process automation',
        details: process.env.NODE_ENV === 'development' ? actionError.stack : undefined
      });
    }
  } catch (error) {
    console.error('Error in process endpoint:', error);
    next(error);
  }
});

const PORT = process.env.AI_AGENT_PORT || 3003;

// Start server with error handling
const server = app.listen(PORT, () => {
  console.log(`AI agent running on port ${PORT}`);
}).on('error', (error: any) => {
  console.error('Failed to start server:', error);
  if (error.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use`);
  }
  process.exit(1);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  server.close(() => {
    process.exit(1);
  });
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});