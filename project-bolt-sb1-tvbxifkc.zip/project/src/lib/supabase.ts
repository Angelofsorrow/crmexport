import { createClient } from '@supabase/supabase-js';

// Get environment variables
const supabaseUrl = 'https://ikiqjuosbzpzhgojmwju.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlraXFqdW9zYnpwemhnb2ptd2p1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI0MDk0ODUsImV4cCI6MjA1Nzk4NTQ4NX0.DCp7BLUWqQAhpxXciWtYeKLO-BoDE60pe6VS_78EGzw';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase credentials');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
    flowType: 'pkce'
  }
});