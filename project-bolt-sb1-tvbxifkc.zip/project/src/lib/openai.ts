import OpenAI from 'openai';
import { supabase } from './supabase';

let openaiInstance: OpenAI | null = null;
let currentConfig: any = null;

async function getOpenAIConfig() {
  try {
    const { data: configs, error } = await supabase
      .from('openai_configs')
      .select('*')
      .eq('is_active', true)
      .limit(1);

    // Return first config or fallback to environment variable
    const config = configs?.[0] || {
      api_key: import.meta.env.VITE_OPENAI_API_KEY,
      model: 'gpt-3.5-turbo',
      temperature: 0.7,
      max_tokens: 500
    };

    return config;
  } catch (error) {
    console.error('Error fetching OpenAI config:', error);
    // Fallback to environment variable
    return {
      api_key: import.meta.env.VITE_OPENAI_API_KEY,
      model: 'gpt-3.5-turbo',
      temperature: 0.7,
      max_tokens: 500
    };
  }
}

export async function getOpenAIInstance() {
  try {
    const config = await getOpenAIConfig();
    
    // If no config found or no API key, return null
    if (!config?.api_key) {
      return null;
    }

    // If config changed, create new instance
    if (!openaiInstance || config.api_key !== currentConfig?.api_key) {
      openaiInstance = new OpenAI({
        apiKey: config.api_key,
        dangerouslyAllowBrowser: true
      });
      currentConfig = config;
    }

    return openaiInstance;
  } catch (error) {
    console.error('Error getting OpenAI instance:', error);
    return null;
  }
}

export async function generateEmailResponse(emailContent: string, context: string) {
  const openai = await getOpenAIInstance();
  if (!openai) {
    throw new Error('OpenAI not configured');
  }

  try {
    const completion = await openai.chat.completions.create({
      model: currentConfig?.model || "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a professional and friendly sales assistant. Generate an email response based on the context provided. Keep responses concise and focused.
          
          Context about the relationship: ${context}`
        },
        {
          role: "user",
          content: emailContent
        }
      ],
      temperature: currentConfig?.temperature || 0.7,
      max_tokens: currentConfig?.max_tokens || 500
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error('Error generating email response:', error);
    throw error;
  }
}

// Initialize and export the OpenAI instance
export const openai = await getOpenAIInstance();