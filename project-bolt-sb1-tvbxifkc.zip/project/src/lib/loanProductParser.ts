import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { z } from 'zod';

// Schema for loan product CSV/Excel file
const loanProductFileSchema = z.object({
  name: z.string().min(1),
  type: z.string().min(1),
  description: z.string().optional(),
  min_credit_score: z.number().min(300).max(850),
  max_ltv: z.number().min(0).max(100),
  min_down_payment: z.number().min(0),
  interest_rate_min: z.number().min(0),
  interest_rate_max: z.number().max(100),
  term_years: z.string(), // Will be parsed into array
  requirements: z.string(), // Will be parsed into array
  eligible_property_types: z.string(), // Will be parsed into array
  income_limits_single: z.number().optional(),
  income_limits_joint: z.number().optional(),
  income_limits_ami_percentage: z.number().optional(),
  dti_front: z.number().min(0).max(100),
  dti_back: z.number().min(0).max(100),
  credit_score_ranges: z.string() // Will be parsed into array of objects
});

export type LoanProductFile = z.infer<typeof loanProductFileSchema>;

export async function parseLoanProductFile(file: File): Promise<LoanProductFile[]> {
  const fileType = file.name.split('.').pop()?.toLowerCase();
  let data: any[];

  if (fileType === 'csv') {
    // Parse CSV file
    const csvText = await file.text();
    const result = Papa.parse(csvText, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true
    });
    data = result.data;
  } else if (fileType === 'xlsx' || fileType === 'xls') {
    // Parse Excel file
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer);
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    data = XLSX.utils.sheet_to_json(worksheet);
  } else {
    throw new Error('Unsupported file type. Please use CSV or Excel files.');
  }

  // Validate and transform each row
  return data.map((row, index) => {
    try {
      const validatedRow = loanProductFileSchema.parse(row);

      // Transform string arrays
      const termYears = validatedRow.term_years.split(',').map(t => parseInt(t.trim()));
      const requirements = validatedRow.requirements.split('|').map(r => r.trim());
      const propertyTypes = validatedRow.eligible_property_types.split(',').map(t => t.trim());
      
      // Parse credit score ranges
      const creditScoreRanges = validatedRow.credit_score_ranges.split('|').map(range => {
        const [min, max, adjustment] = range.split(',').map(n => parseFloat(n.trim()));
        return { min, max, rate_adjustment: adjustment };
      });

      // Build income limits object
      let incomeLimits = null;
      if (validatedRow.income_limits_ami_percentage) {
        incomeLimits = { percentage_ami: validatedRow.income_limits_ami_percentage };
      } else if (validatedRow.income_limits_single || validatedRow.income_limits_joint) {
        incomeLimits = {
          single: validatedRow.income_limits_single,
          joint: validatedRow.income_limits_joint
        };
      }

      // Return transformed row in final format
      return {
        name: validatedRow.name,
        type: validatedRow.type,
        description: validatedRow.description,
        min_credit_score: validatedRow.min_credit_score,
        max_ltv: validatedRow.max_ltv,
        min_down_payment: validatedRow.min_down_payment,
        interest_rate_range: {
          min: validatedRow.interest_rate_min,
          max: validatedRow.interest_rate_max
        },
        term_years: termYears,
        requirements: requirements,
        eligible_property_types: propertyTypes,
        income_limits: incomeLimits,
        dti_limits: {
          front: validatedRow.dti_front,
          back: validatedRow.dti_back
        },
        credit_score_ranges: creditScoreRanges
      };
    } catch (error) {
      throw new Error(`Error in row ${index + 1}: ${error.message}`);
    }
  });
}