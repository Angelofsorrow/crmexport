import { z } from 'zod';

// Add new type definition for AI request types
export type AIRequestType = 
  | 'email_draft'
  | 'meeting_summary' 
  | 'task_suggestion'
  | 'deal_analysis'
  | 'contact_research'
  | 'document_generation'
  | 'calendar_event';

export interface AIRequest {
  type: AIRequestType;
  data: any;
}

export interface AIResponse {
  content: string;
  action?: {
    type: string;
    data: any;
  };
}

// Loan application schema
export const loanApplicationSchema = z.object({
  loan_product_id: z.string().uuid(),
  property_id: z.string().uuid(),
  primary_borrower_id: z.string().uuid(),
  co_borrower_id: z.string().uuid().optional(),
  loan_amount: z.number().positive(),
  down_payment: z.number().positive(),
  interest_rate: z.number().min(0).max(100).optional(),
  term_years: z.number().int().positive(),
  estimated_monthly_payment: z.number().positive().optional(),
  application_date: z.string(),
  status: z.string().default('draft'),
  stage: z.string().default('initial_review'),
  notes: z.string().optional()
});

export type LoanApplication = z.infer<typeof loanApplicationSchema>;

// Whitelabel configuration schema
export const whitelabelConfigSchema = z.object({
  organization_id: z.string().uuid(),
  name: z.string().min(1),
  logo_url: z.string().url().optional().or(z.literal('')),
  favicon_url: z.string().url().optional().or(z.literal('')),
  primary_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
  secondary_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
  accent_color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
  font_family: z.string(),
  custom_css: z.string().optional().or(z.literal('')),
  email_template: z.string().optional().or(z.literal('')),
  custom_domain: z.string().optional().or(z.literal('')),
  support_email: z.string().email().optional().or(z.literal('')),
  support_phone: z.string().optional().or(z.literal('')),
  footer_text: z.string().optional().or(z.literal('')),
  terms_url: z.string().url().optional().or(z.literal('')),
  privacy_url: z.string().url().optional().or(z.literal('')),
  is_active: z.boolean()
});

export type WhitelabelConfig = z.infer<typeof whitelabelConfigSchema>;

// Other type definitions
export interface Organization {
  id: string;
  name: string;
  slug: string;
  domain?: string;
  created_at: string;
  updated_at: string;
  owner_id: string;
}

export interface LoanProduct {
  id: string;
  name: string;
  type: string;
  description?: string;
  min_credit_score: number;
  max_ltv: number;
  min_down_payment: number;
  interest_rate_range: {
    min: number;
    max: number;
  };
  term_years: number[];
  requirements: string[];
  eligible_property_types: string[];
  income_limits?: {
    single?: number;
    joint?: number;
    percentage_ami?: number;
  };
  dti_limits: {
    front: number;
    back: number;
  };
  credit_score_ranges: Array<{
    min: number;
    max: number;
    rate_adjustment: number;
  }>;
}

export interface Property {
  id: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  property_type: string;
  purchase_price?: number;
  estimated_value?: number;
  year_built?: number;
  bedrooms?: number;
  bathrooms?: number;
  square_feet?: number;
  lot_size?: number;
  occupancy_type?: string;
}

export interface Borrower {
  id?: string;
  contact_id: string;
  credit_score?: number;
  dti_ratio?: number;
  monthly_income?: number;
  monthly_debts?: number;
  employment_status?: string;
  employment_years?: number;
  bankruptcy_history?: boolean;
  foreclosure_history?: boolean;
  assets?: Record<string, any>;
  liabilities?: Record<string, any>;
  contact?: {
    first_name: string;
    last_name: string;
  };
}

export interface Contact {
  id: string;
  first_name: string;
  last_name: string;
  email?: string;
  phone?: string;
  company?: {
    name: string;
  };
  custom_fields?: Record<string, any>;
  tags?: string[];
}