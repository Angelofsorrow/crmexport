/*
  # Add Extended Contact Fields

  1. Changes
    - Add new fields for enhanced contact information
    - Add indexes for commonly queried fields
    - Update existing contacts table structure

  2. Fields Added
    - Opportunity tracking fields
    - Account identification fields
    - Personal preference fields
    - Loan-related fields
    - Agent information
    - Application status fields
    - Property details
    - Important dates
*/

-- Add new columns to contacts table
ALTER TABLE contacts
ADD COLUMN IF NOT EXISTS opportunity_id text,
ADD COLUMN IF NOT EXISTS account_id text,
ADD COLUMN IF NOT EXISTS preferred_name text,
ADD COLUMN IF NOT EXISTS preferred_language text DEFAULT 'English',
ADD COLUMN IF NOT EXISTS referred_by text,
ADD COLUMN IF NOT EXISTS contact_preference text DEFAULT 'email',
ADD COLUMN IF NOT EXISTS lead_source text,
ADD COLUMN IF NOT EXISTS rating text,
ADD COLUMN IF NOT EXISTS previous_funded_loan_referred_by text,
ADD COLUMN IF NOT EXISTS preferred_max_sales_price numeric,
ADD COLUMN IF NOT EXISTS preferred_max_cash_out_of_pocket numeric,
ADD COLUMN IF NOT EXISTS preferred_max_payment numeric,
ADD COLUMN IF NOT EXISTS down_payment_information text,
ADD COLUMN IF NOT EXISTS co_applicant_first_name text,
ADD COLUMN IF NOT EXISTS notes text,
ADD COLUMN IF NOT EXISTS agent_notes text,
ADD COLUMN IF NOT EXISTS buyers_agent_first_name text,
ADD COLUMN IF NOT EXISTS buyers_agent_last_name text,
ADD COLUMN IF NOT EXISTS blend_application_status text,
ADD COLUMN IF NOT EXISTS blend_application_reference_number text,
ADD COLUMN IF NOT EXISTS purchase_price numeric,
ADD COLUMN IF NOT EXISTS loan_amount numeric,
ADD COLUMN IF NOT EXISTS total_loan_amount numeric,
ADD COLUMN IF NOT EXISTS loan_term integer,
ADD COLUMN IF NOT EXISTS second_mortgage_amount numeric,
ADD COLUMN IF NOT EXISTS client_scenario text,
ADD COLUMN IF NOT EXISTS ltv numeric,
ADD COLUMN IF NOT EXISTS interest_rate numeric,
ADD COLUMN IF NOT EXISTS max_qualification_amount numeric,
ADD COLUMN IF NOT EXISTS max_qualification_payment numeric,
ADD COLUMN IF NOT EXISTS occupancy text,
ADD COLUMN IF NOT EXISTS available_cash_to_close numeric,
ADD COLUMN IF NOT EXISTS address text,
ADD COLUMN IF NOT EXISTS property_county text,
ADD COLUMN IF NOT EXISTS application_started_date date,
ADD COLUMN IF NOT EXISTS projected_closing_date date,
ADD COLUMN IF NOT EXISTS credit_report_date date,
ADD COLUMN IF NOT EXISTS credit_expiration_date date,
ADD COLUMN IF NOT EXISTS closing_date date,
ADD COLUMN IF NOT EXISTS app_docs_requested_date date,
ADD COLUMN IF NOT EXISTS app_docs_received_date date,
ADD COLUMN IF NOT EXISTS pre_approval_date date,
ADD COLUMN IF NOT EXISTS offer_accepted boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS stage text,
ADD COLUMN IF NOT EXISTS type_of_hold text,
ADD COLUMN IF NOT EXISTS pre_approval_type text,
ADD COLUMN IF NOT EXISTS loan_status text,
ADD COLUMN IF NOT EXISTS external_status text,
ADD COLUMN IF NOT EXISTS reason_lost text,
ADD COLUMN IF NOT EXISTS reason_for_not_qualifying text,
ADD COLUMN IF NOT EXISTS hold_follow_up_date date,
ADD COLUMN IF NOT EXISTS last_activity_date timestamptz,
ADD COLUMN IF NOT EXISTS prospect_source text;

-- Add indexes for commonly queried fields
CREATE INDEX IF NOT EXISTS idx_contacts_opportunity_id ON contacts(opportunity_id);
CREATE INDEX IF NOT EXISTS idx_contacts_account_id ON contacts(account_id);
CREATE INDEX IF NOT EXISTS idx_contacts_lead_source ON contacts(lead_source);
CREATE INDEX IF NOT EXISTS idx_contacts_stage ON contacts(stage);
CREATE INDEX IF NOT EXISTS idx_contacts_loan_status ON contacts(loan_status);
CREATE INDEX IF NOT EXISTS idx_contacts_last_activity_date ON contacts(last_activity_date);
CREATE INDEX IF NOT EXISTS idx_contacts_prospect_source ON contacts(prospect_source);

-- Add text search index for full-text search
CREATE INDEX IF NOT EXISTS idx_contacts_full_text ON contacts 
USING gin(
  to_tsvector('english',
    coalesce(first_name, '') || ' ' ||
    coalesce(last_name, '') || ' ' ||
    coalesce(email, '') || ' ' ||
    coalesce(phone, '') || ' ' ||
    coalesce(preferred_name, '') || ' ' ||
    coalesce(notes, '') || ' ' ||
    coalesce(agent_notes, '')
  )
);

-- Add composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_contacts_stage_loan_status ON contacts(stage, loan_status);
CREATE INDEX IF NOT EXISTS idx_contacts_lead_source_prospect_source ON contacts(lead_source, prospect_source);

COMMENT ON TABLE contacts IS 'Extended contact information for loan prospects and clients';

-- Add column comments
COMMENT ON COLUMN contacts.opportunity_id IS 'Unique identifier for the sales opportunity';
COMMENT ON COLUMN contacts.account_id IS 'Associated account identifier';
COMMENT ON COLUMN contacts.preferred_name IS 'Contact''s preferred name for communication';
COMMENT ON COLUMN contacts.preferred_language IS 'Preferred language for communication';
COMMENT ON COLUMN contacts.lead_source IS 'Source of the lead';
COMMENT ON COLUMN contacts.prospect_source IS 'Original source of the prospect';
COMMENT ON COLUMN contacts.stage IS 'Current stage in the sales/loan process';
COMMENT ON COLUMN contacts.loan_status IS 'Current status of the loan application';
COMMENT ON COLUMN contacts.last_activity_date IS 'Date of the most recent activity';