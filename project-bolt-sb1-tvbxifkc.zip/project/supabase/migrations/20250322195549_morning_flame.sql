/*
  # Fix AI Request Type Enum and Table

  1. Changes
    - Drop existing tables that reference the enum first
    - Drop and recreate enum types
    - Recreate tables and functions
    - Add proper indexes
*/

-- Drop existing tables and functions that might reference the enums
DROP TABLE IF EXISTS ai_interactions CASCADE;
DROP TABLE IF EXISTS ai_context CASCADE;

-- Drop and recreate enum types
DO $$ 
BEGIN
  DROP TYPE IF EXISTS ai_request_type CASCADE;
  DROP TYPE IF EXISTS ai_interaction_status CASCADE;

  CREATE TYPE ai_request_type AS ENUM (
    'email_draft',
    'meeting_summary',
    'task_suggestion',
    'deal_analysis',
    'contact_research',
    'document_generation',
    'calendar_event'
  );

  CREATE TYPE ai_interaction_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed'
  );
END $$;

-- Create ai_interactions table
CREATE TABLE ai_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  request_type ai_request_type NOT NULL,
  request_data jsonb NOT NULL,
  response_data jsonb,
  context jsonb,
  status ai_interaction_status DEFAULT 'pending',
  error_message text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  tokens_used integer DEFAULT 0,
  model_version text,
  execution_time numeric
);

-- Create ai_context table
CREATE TABLE ai_context (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  context_data jsonb NOT NULL,
  relevance_score numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  UNIQUE(user_id, entity_type, entity_id)
);

-- Update or create the generate_ai_response function
CREATE OR REPLACE FUNCTION generate_ai_response(
  p_request_type ai_request_type,
  p_request_data jsonb,
  p_context jsonb DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_response jsonb;
BEGIN
  -- Different handling based on request type
  CASE p_request_type
    WHEN 'email_draft' THEN
      v_response := jsonb_build_object(
        'type', 'email',
        'subject', p_request_data->>'subject',
        'content', generate_email_content(p_request_data, p_context)
      );
      
    WHEN 'meeting_summary' THEN
      v_response := jsonb_build_object(
        'type', 'summary',
        'content', generate_meeting_summary(p_request_data, p_context)
      );
      
    WHEN 'task_suggestion' THEN
      v_response := jsonb_build_object(
        'type', 'tasks',
        'suggestions', generate_task_suggestions(p_request_data, p_context)
      );
      
    WHEN 'deal_analysis' THEN
      v_response := jsonb_build_object(
        'type', 'analysis',
        'content', analyze_deal(p_request_data, p_context)
      );
      
    WHEN 'contact_research' THEN
      v_response := jsonb_build_object(
        'type', 'research',
        'content', research_contact(p_request_data, p_context)
      );
      
    WHEN 'document_generation' THEN
      v_response := jsonb_build_object(
        'type', 'document',
        'content', generate_document(p_request_data, p_context)
      );

    WHEN 'calendar_event' THEN
      v_response := jsonb_build_object(
        'type', 'calendar',
        'event', p_request_data->>'eventDetails',
        'content', 'Calendar event created successfully'
      );
      
    ELSE
      RAISE EXCEPTION 'Unsupported request type: %', p_request_type;
  END CASE;

  RETURN v_response;
END;
$$;

-- Enable RLS
ALTER TABLE ai_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_context ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their AI interactions"
  ON ai_interactions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can manage their AI context"
  ON ai_context
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_ai_interactions_user_id ON ai_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_request_type ON ai_interactions(request_type);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_status ON ai_interactions(status);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_created_at ON ai_interactions(created_at);

CREATE INDEX IF NOT EXISTS idx_ai_context_user_id ON ai_context(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_context_entity ON ai_context(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_ai_context_expires_at ON ai_context(expires_at);