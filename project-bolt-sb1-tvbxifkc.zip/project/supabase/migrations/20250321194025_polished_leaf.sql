/*
  # Fix Integrations RLS Policy

  1. Changes
    - Drop existing policy
    - Create new policy that properly handles NULL owner_id for new rows
    - Add proper USING and WITH CHECK clauses
*/

-- Drop existing policy
DROP POLICY IF EXISTS "Users can manage their integrations" ON integrations;

-- Create new policy that properly handles new integrations
CREATE POLICY "Users can manage their integrations"
  ON integrations
  FOR ALL
  TO authenticated
  USING (
    CASE
      WHEN owner_id IS NULL THEN true  -- Allow viewing system integrations
      ELSE owner_id = auth.uid()       -- Only view owned integrations
    END
  )
  WITH CHECK (
    CASE
      WHEN owner_id IS NULL THEN auth.uid() IS NOT NULL  -- Allow creating new integrations
      ELSE owner_id = auth.uid()                         -- Only modify owned integrations
    END
  );

-- Create index for better performance if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_integrations_owner_id ON integrations(owner_id);