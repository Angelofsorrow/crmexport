/*
  # Add voicemail support to campaign steps

  1. Changes
    - Add voicemail_url column to campaign_steps table to store uploaded voicemail file URLs
    - Add storage bucket for campaign files

  2. Security
    - Enable RLS on storage bucket
    - Add policy to allow authenticated users to manage their campaign files
*/

-- Add voicemail_url column
ALTER TABLE campaign_steps ADD COLUMN IF NOT EXISTS voicemail_url text;

-- Create storage bucket for campaign files
INSERT INTO storage.buckets (id, name, public)
VALUES ('campaign-files', 'campaign-files', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on the bucket
CREATE POLICY "Users can manage their own campaign files"
ON storage.objects FOR ALL
TO authenticated
USING (bucket_id = 'campaign-files' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'campaign-files' AND (storage.foldername(name))[1] = auth.uid()::text);