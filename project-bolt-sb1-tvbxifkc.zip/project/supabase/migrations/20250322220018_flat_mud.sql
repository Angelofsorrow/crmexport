/*
  # Add Review Management System

  1. New Tables
    - `reviews`: Stores customer reviews and ratings
    - `review_responses`: Stores responses to reviews
    
  2. Security
    - Enable RLS
    - Add policies for review management
*/

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id uuid REFERENCES contacts(id),
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  content text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  is_published boolean DEFAULT false,
  needs_approval boolean GENERATED ALWAYS AS (rating < 5) STORED,
  submitted_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Create review responses table
CREATE TABLE IF NOT EXISTS review_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id uuid REFERENCES reviews(id) ON DELETE CASCADE,
  content text NOT NULL,
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE review_responses ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view approved reviews"
  ON reviews
  FOR SELECT
  TO authenticated
  USING (
    status = 'approved' OR 
    owner_id = auth.uid() OR
    reviewed_by = auth.uid()
  );

CREATE POLICY "Users can create reviews"
  ON reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can manage their own reviews"
  ON reviews
  FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage review responses"
  ON review_responses
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create function to handle review submissions
CREATE OR REPLACE FUNCTION handle_review_submission()
RETURNS TRIGGER AS $$
BEGIN
  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    contact_id,
    owner_id,
    created_at
  ) VALUES (
    'review',
    CASE
      WHEN NEW.needs_approval THEN 'Review Needs Approval'
      ELSE 'Review Submitted'
    END,
    format('Review submitted by %s %s - Rating: %s/5', 
      (SELECT first_name FROM contacts WHERE id = NEW.contact_id),
      (SELECT last_name FROM contacts WHERE id = NEW.contact_id),
      NEW.rating
    ),
    NEW.contact_id,
    NEW.owner_id,
    now()
  );

  -- Auto-approve 5-star reviews
  IF NOT NEW.needs_approval THEN
    NEW.status := 'approved';
    NEW.is_published := true;
    NEW.reviewed_at := now();
    NEW.reviewed_by := NEW.owner_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for review submissions
CREATE TRIGGER review_submission_handler
  BEFORE INSERT ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION handle_review_submission();

-- Create function to handle review status changes
CREATE OR REPLACE FUNCTION handle_review_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status != OLD.status THEN
    -- Create activity record
    INSERT INTO activities (
      type,
      title,
      description,
      contact_id,
      owner_id,
      created_at
    ) VALUES (
      'review_status',
      format('Review %s', NEW.status),
      format('Review %s by %s. Rating: %s/5', 
        NEW.status,
        (SELECT email FROM auth.users WHERE id = NEW.reviewed_by),
        NEW.rating
      ),
      NEW.contact_id,
      NEW.reviewed_by,
      now()
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for review status changes
CREATE TRIGGER review_status_change_handler
  AFTER UPDATE OF status ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION handle_review_status_change();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_reviews_contact_id ON reviews(contact_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);
CREATE INDEX IF NOT EXISTS idx_reviews_status ON reviews(status);
CREATE INDEX IF NOT EXISTS idx_reviews_needs_approval ON reviews(needs_approval);
CREATE INDEX IF NOT EXISTS idx_reviews_submitted_at ON reviews(submitted_at);
CREATE INDEX IF NOT EXISTS idx_review_responses_review_id ON review_responses(review_id);