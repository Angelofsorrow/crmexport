/*
  # Fix Calendar Events RLS and Owner ID

  1. Changes
    - Drop existing policies
    - Create new policy that properly handles owner_id
    - Add default owner_id value for existing rows
    - Add proper indexes
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their calendar events" ON calendar_events;
  DROP POLICY IF EXISTS "Users can view calendar events" ON calendar_events;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Set owner_id for existing rows
UPDATE calendar_events 
SET owner_id = auth.uid()
WHERE owner_id IS NULL;

-- Make owner_id required for new rows
ALTER TABLE calendar_events 
ALTER COLUMN owner_id SET NOT NULL;

-- Create new policy
CREATE POLICY "Users can manage calendar events"
  ON calendar_events
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR
    contact_id IN (
      SELECT id FROM contacts WHERE owner_id = auth.uid()
    ) OR
    deal_id IN (
      SELECT id FROM deals WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    owner_id = auth.uid()
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_events_owner_id 
  ON calendar_events(owner_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_contact_id 
  ON calendar_events(contact_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_deal_id 
  ON calendar_events(deal_id);

-- Add trigger for updating timestamps
DO $$ 
BEGIN
  CREATE TRIGGER set_updated_at
    BEFORE UPDATE ON calendar_events
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;