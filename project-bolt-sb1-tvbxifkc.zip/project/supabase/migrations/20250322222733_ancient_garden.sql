/*
  # Fix Contact Lists RLS Policies

  1. Changes
    - Drop existing policies
    - Create new policies that properly handle owner_id
    - Allow creation of new lists by setting owner_id
    
  2. Security
    - Maintain data isolation between users
    - Allow proper list creation flow
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their contact lists" ON contact_lists;
  DROP POLICY IF EXISTS "Users can manage list members" ON contact_list_members;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for contact lists
CREATE POLICY "Users can manage contact lists"
  ON contact_lists
  FOR ALL
  TO authenticated
  USING (
    CASE 
      WHEN owner_id IS NULL THEN true  -- Allow creation of new lists
      ELSE owner_id = auth.uid()       -- Only allow access to owned lists
    END
  )
  WITH CHECK (
    CASE
      WHEN owner_id IS NULL THEN true  -- Allow creation of new lists
      ELSE owner_id = auth.uid()       -- Only allow modifications to owned lists
    END
  );

-- Create new policies for list members
CREATE POLICY "Users can manage list members"
  ON contact_list_members
  FOR ALL
  TO authenticated
  USING (
    list_id IN (
      SELECT id FROM contact_lists WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    list_id IN (
      SELECT id FROM contact_lists WHERE owner_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contact_lists_owner_id ON contact_lists(owner_id);
CREATE INDEX IF NOT EXISTS idx_contact_lists_type ON contact_lists(type);
CREATE INDEX IF NOT EXISTS idx_contact_list_members_list_id ON contact_list_members(list_id);
CREATE INDEX IF NOT EXISTS idx_contact_list_members_contact_id ON contact_list_members(contact_id);