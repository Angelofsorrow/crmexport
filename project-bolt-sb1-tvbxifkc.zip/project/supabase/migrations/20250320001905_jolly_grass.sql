/*
  # Clean up duplicate pipeline stages

  1. Changes
    - Remove duplicate stages
    - Reset order numbers
    - Keep only the most recently updated version of each stage
*/

-- Create a temporary table to store the stages we want to keep
CREATE TEMP TABLE stages_to_keep AS
WITH ranked_stages AS (
  SELECT 
    id,
    name,
    ROW_NUMBER() OVER (
      PARTITION BY name 
      ORDER BY updated_at DESC
    ) as rn
  FROM pipeline_stages
)
SELECT id 
FROM ranked_stages 
WHERE rn = 1;

-- Delete all stages that are duplicates (not in our keep list)
DELETE FROM pipeline_stages 
WHERE id NOT IN (SELECT id FROM stages_to_keep);

-- Reset order numbers to ensure they are sequential
WITH ordered_stages AS (
  SELECT 
    id,
    ROW_NUMBER() OVER (ORDER BY order_number) as new_order
  FROM pipeline_stages
)
UPDATE pipeline_stages
SET order_number = ordered_stages.new_order
FROM ordered_stages
WHERE pipeline_stages.id = ordered_stages.id;

-- Drop temporary table
DROP TABLE stages_to_keep;

-- Verify unique stages
DO $$ 
BEGIN
  IF EXISTS (
    SELECT name, COUNT(*)
    FROM pipeline_stages
    GROUP BY name
    HAVING COUNT(*) > 1
  ) THEN
    RAISE EXCEPTION 'Duplicate stages still exist after cleanup';
  END IF;
END $$;