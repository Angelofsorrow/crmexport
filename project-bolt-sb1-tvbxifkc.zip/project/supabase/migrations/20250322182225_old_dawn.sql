/*
  # Add Calendar AI Integration Triggers

  1. Changes
    - Add trigger for AI-initiated calendar events
    - Add function to process AI calendar requests
    - Add function to notify attendees
    - Add function to update AI context with event results
    
  2. Security
    - Enable RLS
    - Add proper error handling
*/

-- Create function to handle AI calendar requests
CREATE OR REPLACE FUNCTION process_ai_calendar_request()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_interaction_id uuid;
  v_activity_id uuid;
BEGIN
  -- Create AI interaction record
  INSERT INTO ai_interactions (
    user_id,
    request_type,
    request_data,
    status,
    created_at
  ) VALUES (
    NEW.owner_id,
    'meeting_summary',
    jsonb_build_object(
      'event_id', NEW.id,
      'title', NEW.title,
      'description', NEW.description,
      'start_time', NEW.start,
      'end_time', NEW."end",
      'location', NEW.location,
      'attendees', NEW.attendees,
      'source', NEW.source
    ),
    'completed',
    now()
  ) RETURNING id INTO v_interaction_id;

  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    due_date,
    contact_id,
    deal_id,
    owner_id,
    created_at
  ) VALUES (
    'ai_calendar_event',
    NEW.title,
    COALESCE(NEW.description, 'Event created by AI Assistant'),
    NEW.start,
    NEW.contact_id,
    NEW.deal_id,
    NEW.owner_id,
    now()
  ) RETURNING id INTO v_activity_id;

  -- Update AI context
  INSERT INTO ai_context (
    user_id,
    entity_type,
    entity_id,
    context_data,
    created_at
  ) VALUES (
    NEW.owner_id,
    'calendar_event',
    NEW.id,
    jsonb_build_object(
      'event_type', 'ai_calendar',
      'title', NEW.title,
      'description', NEW.description,
      'start_time', NEW.start,
      'end_time', NEW."end",
      'location', NEW.location,
      'attendees', NEW.attendees,
      'activity_id', v_activity_id
    ),
    now()
  ) ON CONFLICT (user_id, entity_type, entity_id) 
  DO UPDATE SET
    context_data = EXCLUDED.context_data,
    updated_at = now();

  -- Notify attendees
  IF NEW.attendees IS NOT NULL AND jsonb_array_length(NEW.attendees) > 0 THEN
    PERFORM notify_ai_event_attendees(NEW);
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'AI Calendar Event Processing',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create function to notify attendees of AI-created events
CREATE OR REPLACE FUNCTION notify_ai_event_attendees(event_record calendar_events)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  attendee jsonb;
  v_contact_id uuid;
BEGIN
  -- Loop through attendees array
  FOR attendee IN SELECT * FROM jsonb_array_elements(event_record.attendees)
  LOOP
    -- Try to find contact by email
    SELECT id INTO v_contact_id
    FROM contacts 
    WHERE email = (attendee->>'email')
    LIMIT 1;

    -- Create notification activity
    INSERT INTO activities (
      type,
      title,
      description,
      due_date,
      contact_id,
      owner_id,
      created_at
    ) VALUES (
      'ai_event_notification',
      'AI Calendar Invitation: ' || event_record.title,
      CASE 
        WHEN event_record.description IS NOT NULL 
        THEN event_record.description 
        ELSE 'You have been invited to an event by the AI Assistant'
      END,
      event_record.start,
      v_contact_id,
      event_record.owner_id,
      now()
    );

    -- Log notification attempt
    INSERT INTO physical_agent_logs (
      type,
      action,
      parameters
    ) VALUES (
      'calendar_notification',
      'send_invitation',
      jsonb_build_object(
        'event_id', event_record.id,
        'attendee', attendee,
        'contact_id', v_contact_id
      )
    );
  END LOOP;
END;
$$;

-- Create trigger for AI-initiated calendar events
CREATE TRIGGER ai_calendar_event_processor
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  WHEN (NEW.source = 'ai_agent')
  EXECUTE FUNCTION process_ai_calendar_request();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_events_source 
  ON calendar_events(source);

CREATE INDEX IF NOT EXISTS idx_ai_interactions_request_type 
  ON ai_interactions(request_type);

-- Add source column if it doesn't exist
DO $$ 
BEGIN
  ALTER TABLE calendar_events 
  ADD COLUMN IF NOT EXISTS source text DEFAULT 'manual';
EXCEPTION
  WHEN duplicate_column THEN NULL;
END $$;