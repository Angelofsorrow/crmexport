/*
  # Enhance Pipeline Stages

  1. Changes
    - Add new fields to pipeline_stages table
      - icon: Icon name from Lucide icons
      - probability: Default probability for deals in this stage
      - notification_template: Template for stage change notifications
      - required_fields: Fields that must be filled before moving to this stage
      - validation_rules: Rules to validate before allowing stage change
    - Update existing stages with enhanced configuration
    - Add more detailed tasks and automations

  2. Security
    - Maintain existing RLS policies
*/

-- Add new columns to pipeline_stages
ALTER TABLE pipeline_stages
ADD COLUMN IF NOT EXISTS icon text DEFAULT 'CircleDot',
ADD COLUMN IF NOT EXISTS probability integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS notification_template jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS required_fields text[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS validation_rules jsonb DEFAULT '{}';

-- Update existing stages with enhanced configuration
UPDATE pipeline_stages SET
  icon = 'Search',
  probability = 10,
  notification_template = '{
    "subject": "New Lead: {deal.title}",
    "body": "A new lead has been added to your pipeline.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nAmount: {deal.amount}"
  }',
  required_fields = ARRAY['title', 'company_id', 'amount'],
  validation_rules = '{
    "amount": {"min": 0},
    "probability": {"min": 0, "max": 100}
  }',
  tasks = ARRAY[
    'Research company background and financials',
    'Identify and map key decision makers',
    'Initial contact attempt via email or phone',
    'Connect on LinkedIn with key stakeholders',
    'Schedule initial discovery call'
  ],
  automations = ARRAY[
    'Send personalized welcome email',
    'Create follow-up task for 2 days',
    'Add contact to LinkedIn network',
    'Set up deal tracking in CRM',
    'Schedule initial team review'
  ]
WHERE name = 'Prospecting';

UPDATE pipeline_stages SET
  icon = 'ClipboardCheck',
  probability = 30,
  notification_template = '{
    "subject": "Deal Qualified: {deal.title}",
    "body": "A deal has been moved to qualification.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nAmount: {deal.amount}"
  }',
  required_fields = ARRAY['title', 'company_id', 'amount', 'close_date'],
  validation_rules = '{
    "amount": {"min": 0},
    "probability": {"min": 20, "max": 100},
    "close_date": {"required": true}
  }',
  tasks = ARRAY[
    'Complete needs assessment questionnaire',
    'Validate budget and timeline expectations',
    'Document pain points and success criteria',
    'Map decision-making process and stakeholders',
    'Identify potential roadblocks'
  ],
  automations = ARRAY[
    'Schedule discovery call with agenda',
    'Send qualification survey to stakeholders',
    'Create opportunity summary document',
    'Set up competitive analysis',
    'Schedule team qualification review'
  ]
WHERE name = 'Qualification';

UPDATE pipeline_stages SET
  icon = 'FileText',
  probability = 50,
  notification_template = '{
    "subject": "Proposal Stage: {deal.title}",
    "body": "A deal has moved to proposal stage.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nAmount: {deal.amount}"
  }',
  required_fields = ARRAY['title', 'company_id', 'amount', 'close_date', 'probability'],
  validation_rules = '{
    "amount": {"min": 0},
    "probability": {"min": 40, "max": 100},
    "close_date": {"required": true}
  }',
  tasks = ARRAY[
    'Draft detailed proposal document',
    'Complete internal pricing review',
    'Prepare presentation materials',
    'Get management approval on terms',
    'Schedule proposal presentation'
  ],
  automations = ARRAY[
    'Generate proposal from template',
    'Schedule internal review meeting',
    'Set up proposal presentation',
    'Create follow-up tasks',
    'Send calendar invites to stakeholders'
  ]
WHERE name = 'Proposal';

UPDATE pipeline_stages SET
  icon = 'FileSignature',
  probability = 70,
  notification_template = '{
    "subject": "Deal in Negotiation: {deal.title}",
    "body": "A deal has entered negotiation.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nAmount: {deal.amount}"
  }',
  required_fields = ARRAY['title', 'company_id', 'amount', 'close_date', 'probability'],
  validation_rules = '{
    "amount": {"min": 0},
    "probability": {"min": 60, "max": 100},
    "close_date": {"required": true}
  }',
  tasks = ARRAY[
    'Review and redline contract terms',
    'Document and address all objections',
    'Get final stakeholder approvals',
    'Negotiate final pricing and terms',
    'Prepare closing documents'
  ],
  automations = ARRAY[
    'Generate contract for review',
    'Schedule negotiation calls',
    'Set up automated reminders',
    'Create negotiation summary',
    'Alert legal team for review'
  ]
WHERE name = 'Negotiation';

UPDATE pipeline_stages SET
  icon = 'CheckCircle',
  probability = 100,
  notification_template = '{
    "subject": "Deal Won: {deal.title}",
    "body": "Congratulations! A deal has been won.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nAmount: {deal.amount}"
  }',
  required_fields = ARRAY['title', 'company_id', 'amount', 'close_date', 'probability'],
  validation_rules = '{
    "amount": {"min": 0},
    "probability": {"value": 100},
    "close_date": {"required": true}
  }',
  tasks = ARRAY[
    'Get signed final contract',
    'Schedule kickoff meeting',
    'Set up customer account',
    'Introduce implementation team',
    'Document win details'
  ],
  automations = ARRAY[
    'Generate welcome package',
    'Notify implementation team',
    'Schedule onboarding calls',
    'Set up success tracking',
    'Create implementation timeline'
  ]
WHERE name = 'Closed Won';

UPDATE pipeline_stages SET
  icon = 'XCircle',
  probability = 0,
  notification_template = '{
    "subject": "Deal Lost: {deal.title}",
    "body": "A deal has been lost.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nAmount: {deal.amount}"
  }',
  required_fields = ARRAY['title', 'company_id', 'amount', 'notes'],
  validation_rules = '{
    "amount": {"min": 0},
    "probability": {"value": 0},
    "notes": {"required": true}
  }',
  tasks = ARRAY[
    'Document detailed loss reasons',
    'Schedule team post-mortem',
    'Update CRM with feedback',
    'Archive deal documents',
    'Plan re-engagement strategy'
  ],
  automations = ARRAY[
    'Send loss analysis survey',
    'Schedule 6-month follow-up',
    'Archive deal materials',
    'Update forecasting data',
    'Notify account team'
  ]
WHERE name = 'Closed Lost';

-- Create index for icon field
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_icon ON pipeline_stages(icon);