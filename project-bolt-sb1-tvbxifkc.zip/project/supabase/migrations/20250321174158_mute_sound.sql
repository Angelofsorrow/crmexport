/*
  # Add Calendar Events Table

  1. New Table
    - `calendar_events`: Stores calendar events from various sources
      - Basic event information
      - Source tracking
      - Attendee management
      - Recurrence rules

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create calendar events table
CREATE TABLE IF NOT EXISTS calendar_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  location text,
  start timestamptz NOT NULL,
  "end" timestamptz NOT NULL,
  all_day boolean DEFAULT false,
  source text NOT NULL, -- 'google', 'microsoft', 'email'
  source_id text, -- Original ID from the source system
  recurrence_rule text, -- iCal RRULE format
  status text DEFAULT 'confirmed',
  attendees jsonb DEFAULT '[]',
  reminders jsonb DEFAULT '[]',
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  contact_id uuid REFERENCES contacts(id),
  deal_id uuid REFERENCES deals(id)
);

-- Enable RLS
ALTER TABLE calendar_events ENABLE ROW LEVEL SECURITY;

-- Add RLS policy
CREATE POLICY "Users can manage their calendar events"
  ON calendar_events
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_events_date_range 
  ON calendar_events (start, "end");

CREATE INDEX IF NOT EXISTS idx_calendar_events_source 
  ON calendar_events (source, source_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_owner 
  ON calendar_events (owner_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_contact 
  ON calendar_events (contact_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_deal 
  ON calendar_events (deal_id);