/*
  # Clean up pipeline stages and fix titles

  1. Changes
    - Remove duplicate stages
    - Update stage titles and descriptions
    - Ensure proper order numbers
    - Add missing icons and colors
*/

-- First, remove all duplicate stages
DELETE FROM pipeline_stages a USING pipeline_stages b
WHERE a.id > b.id 
AND a.name = b.name;

-- Update existing stages with proper titles and configuration
UPDATE pipeline_stages SET
  name = 'Lead Qualification',
  description = 'Initial qualification of lead potential',
  color = 'bg-purple-600',
  icon = 'Users',
  probability = 20,
  tasks = ARRAY[
    'Assess budget and timeline',
    'Identify pain points',
    'Confirm decision-making process',
    'Validate business need',
    'Research company background'
  ],
  automations = ARRAY[
    'Schedule discovery call',
    'Send qualification survey',
    'Create opportunity',
    'Set follow-up reminder',
    'Update lead score'
  ]
WHERE name = 'Qualification';

UPDATE pipeline_stages SET
  name = 'Proposal Development',
  description = 'Creating and presenting solution proposal',
  color = 'bg-yellow-600',
  icon = 'FileText',
  probability = 50,
  tasks = ARRAY[
    'Draft proposal document',
    'Internal pricing review',
    'Prepare presentation',
    'Get management approval',
    'Schedule presentation'
  ],
  automations = ARRAY[
    'Generate proposal document',
    'Set internal review deadline',
    'Schedule presentation',
    'Send calendar invites',
    'Create follow-up tasks'
  ]
WHERE name = 'Proposal';

UPDATE pipeline_stages SET
  name = 'Contract Negotiation',
  description = 'Final terms negotiation and closing',
  color = 'bg-orange-600',
  icon = 'FileSignature',
  probability = 75,
  tasks = ARRAY[
    'Review contract terms',
    'Address objections',
    'Get stakeholder approval',
    'Finalize pricing',
    'Prepare closing docs'
  ],
  automations = ARRAY[
    'Send contract for review',
    'Schedule negotiation call',
    'Set follow-up reminder',
    'Update forecast',
    'Alert legal team'
  ]
WHERE name = 'Negotiation';

UPDATE pipeline_stages SET
  name = 'Deal Won',
  description = 'Successfully closed deals',
  color = 'bg-green-600',
  icon = 'CheckCircle',
  probability = 100,
  tasks = ARRAY[
    'Send final contract',
    'Schedule kickoff meeting',
    'Set up account',
    'Introduce support team',
    'Document win details'
  ],
  automations = ARRAY[
    'Generate welcome packet',
    'Notify implementation team',
    'Schedule onboarding',
    'Create success plan',
    'Update revenue forecast'
  ]
WHERE name = 'Closed Won';

UPDATE pipeline_stages SET
  name = 'Deal Lost',
  description = 'Lost or abandoned opportunities',
  color = 'bg-red-600',
  icon = 'XCircle',
  probability = 0,
  tasks = ARRAY[
    'Document loss reasons',
    'Schedule post-mortem',
    'Update CRM',
    'Archive documents',
    'Plan re-engagement'
  ],
  automations = ARRAY[
    'Send feedback survey',
    'Schedule follow-up in 6 months',
    'Archive deal materials',
    'Update forecasting',
    'Notify account team'
  ]
WHERE name = 'Closed Lost';

-- Ensure proper order numbers
UPDATE pipeline_stages SET order_number = 1 WHERE name = 'Initial Contact';
UPDATE pipeline_stages SET order_number = 2 WHERE name = 'Lead Qualification';
UPDATE pipeline_stages SET order_number = 3 WHERE name = 'Discovery';
UPDATE pipeline_stages SET order_number = 4 WHERE name = 'Solution Design';
UPDATE pipeline_stages SET order_number = 5 WHERE name = 'Proposal Development';
UPDATE pipeline_stages SET order_number = 6 WHERE name = 'Evaluation';
UPDATE pipeline_stages SET order_number = 7 WHERE name = 'Contract Review';
UPDATE pipeline_stages SET order_number = 8 WHERE name = 'Contract Negotiation';
UPDATE pipeline_stages SET order_number = 9 WHERE name = 'Deal Won';
UPDATE pipeline_stages SET order_number = 10 WHERE name = 'Deal Lost';