/*
  # Storage setup for campaign files

  1. Changes
    - Create storage bucket for campaign files if it doesn't exist
    - Drop existing policies if they exist
    - Create new policies for file management
    - Fix UUID casting issue in policies

  2. Security
    - Enable row level security
    - Add policies for authenticated users to:
      - Upload files to their campaigns
      - Read campaign files
      - Delete their campaign files
*/

-- Create the storage bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES ('campaign-files', 'campaign-files')
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Drop existing policies if they exist
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can upload campaign files" ON storage.objects;
  DROP POLICY IF EXISTS "Users can read campaign files" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete their campaign files" ON storage.objects;
END $$;

-- Policy to allow authenticated users to upload files to their campaigns
CREATE POLICY "Users can upload campaign files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'campaign-files' AND
  (storage.foldername(name))[1] = 'voicemails' AND
  EXISTS (
    SELECT 1 FROM public.campaigns
    WHERE id::text = (storage.foldername(name))[2]
    AND owner_id = auth.uid()
  )
);

-- Policy to allow authenticated users to read campaign files
CREATE POLICY "Users can read campaign files"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'campaign-files' AND
  (storage.foldername(name))[1] = 'voicemails' AND
  EXISTS (
    SELECT 1 FROM public.campaigns
    WHERE id::text = (storage.foldername(name))[2]
    AND owner_id = auth.uid()
  )
);

-- Policy to allow authenticated users to delete their campaign files
CREATE POLICY "Users can delete their campaign files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'campaign-files' AND
  (storage.foldername(name))[1] = 'voicemails' AND
  EXISTS (
    SELECT 1 FROM public.campaigns
    WHERE id::text = (storage.foldername(name))[2]
    AND owner_id = auth.uid()
  )
);