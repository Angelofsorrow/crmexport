/*
  # Add Mortgage CRM Tables

  1. New Tables
    - `loan_products`: Available loan types and products
    - `properties`: Property information for mortgages
    - `borrowers`: Borrower details and financials
    - `income_sources`: Borrower income information
    - `loan_applications`: Core loan application data

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Loan Products table
CREATE TABLE IF NOT EXISTS loan_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  description text,
  min_credit_score integer,
  max_ltv numeric,
  min_down_payment numeric,
  interest_rate_range jsonb,
  term_years integer[],
  requirements text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Properties table
CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  zip_code text NOT NULL,
  property_type text NOT NULL,
  purchase_price numeric,
  estimated_value numeric,
  year_built integer,
  bedrooms integer,
  bathrooms numeric,
  square_feet numeric,
  lot_size numeric,
  occupancy_type text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Borrowers table
CREATE TABLE IF NOT EXISTS borrowers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_id uuid REFERENCES contacts(id),
  credit_score integer,
  dti_ratio numeric,
  monthly_income numeric,
  monthly_debts numeric,
  employment_status text,
  employment_years numeric,
  bankruptcy_history boolean DEFAULT false,
  foreclosure_history boolean DEFAULT false,
  assets jsonb,
  liabilities jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Income Sources table
CREATE TABLE IF NOT EXISTS income_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  borrower_id uuid REFERENCES borrowers(id) ON DELETE CASCADE,
  type text NOT NULL,
  employer_name text,
  monthly_amount numeric NOT NULL,
  start_date date,
  end_date date,
  verification_status text DEFAULT 'pending',
  verification_documents jsonb,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Loan Applications table
CREATE TABLE IF NOT EXISTS loan_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_number text UNIQUE NOT NULL,
  loan_product_id uuid REFERENCES loan_products(id),
  property_id uuid REFERENCES properties(id),
  primary_borrower_id uuid REFERENCES borrowers(id),
  co_borrower_id uuid REFERENCES borrowers(id),
  loan_amount numeric NOT NULL,
  down_payment numeric NOT NULL,
  interest_rate numeric,
  term_years integer,
  estimated_monthly_payment numeric,
  application_date date NOT NULL,
  status text DEFAULT 'draft',
  stage text DEFAULT 'initial_review',
  underwriting_status text,
  closing_date date,
  conditions jsonb DEFAULT '[]',
  required_documents jsonb DEFAULT '[]',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE loan_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE borrowers ENABLE ROW LEVEL SECURITY;
ALTER TABLE income_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_applications ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their own loan products" ON loan_products;
  DROP POLICY IF EXISTS "Users can manage their own properties" ON properties;
  DROP POLICY IF EXISTS "Users can manage their own borrowers" ON borrowers;
  DROP POLICY IF EXISTS "Users can manage their own income sources" ON income_sources;
  DROP POLICY IF EXISTS "Users can manage their own loan applications" ON loan_applications;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- RLS Policies
CREATE POLICY "Users can manage their own loan products"
  ON loan_products
  FOR ALL TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their own properties"
  ON properties
  FOR ALL TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their own borrowers"
  ON borrowers
  FOR ALL TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their own income sources"
  ON income_sources
  FOR ALL TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their own loan applications"
  ON loan_applications
  FOR ALL TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS loan_applications_loan_number_idx ON loan_applications(loan_number);
CREATE INDEX IF NOT EXISTS loan_applications_status_idx ON loan_applications(status);
CREATE INDEX IF NOT EXISTS loan_applications_stage_idx ON loan_applications(stage);
CREATE INDEX IF NOT EXISTS borrowers_contact_id_idx ON borrowers(contact_id);
CREATE INDEX IF NOT EXISTS income_sources_borrower_id_idx ON income_sources(borrower_id);