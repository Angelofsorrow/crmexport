/*
  # Add Custom Pipeline Stages

  1. Changes
    - Add new custom stages for different sales processes
    - Add icon and color options
    - Add more detailed tasks and automations
    - Add stage-specific validation rules
*/

-- Add new custom stages
INSERT INTO pipeline_stages (
  name, description, color, order_number, is_system,
  icon, probability, tasks, automations, is_closed, is_won,
  notification_template, required_fields, validation_rules
) VALUES
  (
    'Initial Contact',
    'First touchpoint with potential customer',
    'bg-sky-600',
    0,
    true,
    'PhoneCall',
    5,
    ARRAY[
      'Review lead source and background',
      'Prepare personalized outreach message',
      'Make first contact attempt',
      'Record initial response',
      'Schedule follow-up if needed'
    ],
    ARRAY[
      'Create contact record',
      'Send welcome email sequence',
      'Set reminder for follow-up',
      'Log contact attempt',
      'Update lead status'
    ],
    false,
    false,
    '{
      "subject": "New Lead Contact: {deal.title}",
      "body": "Initial contact made with new lead.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nContact: {deal.contact.name}"
    }',
    ARRAY['title', 'company_id', 'contact_id'],
    '{
      "contact_id": {"required": true},
      "probability": {"max": 10}
    }'
  ),
  (
    'Discovery',
    'Deep dive into customer needs',
    'bg-indigo-600',
    1.5,
    true,
    'Search',
    20,
    ARRAY[
      'Conduct discovery call',
      'Document business requirements',
      'Identify key pain points',
      'Map current processes',
      'Define success criteria'
    ],
    ARRAY[
      'Send discovery agenda',
      'Record call notes',
      'Create requirements document',
      'Schedule follow-up meeting',
      'Share discovery summary'
    ],
    false,
    false,
    '{
      "subject": "Discovery Phase: {deal.title}",
      "body": "Deal has entered discovery phase.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nNext Steps: {deal.next_steps}"
    }',
    ARRAY['title', 'company_id', 'amount', 'notes'],
    '{
      "notes": {"required": true, "min_length": 100},
      "probability": {"min": 15, "max": 25}
    }'
  ),
  (
    'Solution Design',
    'Creating custom solution proposal',
    'bg-violet-600',
    2.5,
    true,
    'PenTool',
    40,
    ARRAY[
      'Design solution architecture',
      'Create implementation plan',
      'Calculate ROI projections',
      'Prepare technical documentation',
      'Review with technical team'
    ],
    ARRAY[
      'Generate solution document',
      'Schedule technical review',
      'Create pricing model',
      'Set up solution presentation',
      'Prepare demo environment'
    ],
    false,
    false,
    '{
      "subject": "Solution Design: {deal.title}",
      "body": "Solution design phase initiated.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nSolution: {deal.solution_type}"
    }',
    ARRAY['title', 'company_id', 'amount', 'solution_type'],
    '{
      "amount": {"min": 1000},
      "probability": {"min": 35, "max": 45}
    }'
  ),
  (
    'Evaluation',
    'Customer testing and validation',
    'bg-fuchsia-600',
    3.5,
    true,
    'TestTube',
    60,
    ARRAY[
      'Set up evaluation environment',
      'Conduct product demonstration',
      'Gather feedback and requirements',
      'Address technical concerns',
      'Document evaluation results'
    ],
    ARRAY[
      'Create evaluation account',
      'Send access credentials',
      'Schedule training session',
      'Track usage metrics',
      'Collect feedback surveys'
    ],
    false,
    false,
    '{
      "subject": "Evaluation Started: {deal.title}",
      "body": "Customer evaluation phase begun.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nEvaluation Period: {deal.eval_period} days"
    }',
    ARRAY['title', 'company_id', 'amount', 'eval_period'],
    '{
      "eval_period": {"min": 7, "max": 30},
      "probability": {"min": 55, "max": 65}
    }'
  ),
  (
    'Contract Review',
    'Legal and compliance review',
    'bg-rose-600',
    4.5,
    true,
    'ScrollText',
    80,
    ARRAY[
      'Prepare contract draft',
      'Legal team review',
      'Negotiate terms',
      'Address legal concerns',
      'Finalize agreement'
    ],
    ARRAY[
      'Generate contract draft',
      'Route for legal review',
      'Track revision history',
      'Set approval reminders',
      'Prepare signature package'
    ],
    false,
    false,
    '{
      "subject": "Contract Review: {deal.title}",
      "body": "Contract under review.\n\nDeal: {deal.title}\nCompany: {deal.company.name}\nValue: {deal.amount}"
    }',
    ARRAY['title', 'company_id', 'amount', 'contract_version'],
    '{
      "contract_version": {"required": true},
      "probability": {"min": 75, "max": 85}
    }'
  );

-- Update order numbers of existing stages to accommodate new ones
UPDATE pipeline_stages SET order_number = 2 WHERE name = 'Qualification';
UPDATE pipeline_stages SET order_number = 4 WHERE name = 'Proposal';
UPDATE pipeline_stages SET order_number = 6 WHERE name = 'Negotiation';
UPDATE pipeline_stages SET order_number = 8 WHERE name = 'Closed Won';
UPDATE pipeline_stages SET order_number = 9 WHERE name = 'Closed Lost';

-- Add new columns for stage customization if they don't exist
ALTER TABLE pipeline_stages
ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS stage_rules jsonb DEFAULT '{}',
ADD COLUMN IF NOT EXISTS next_stages uuid[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS required_roles text[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS auto_actions jsonb DEFAULT '[]';

-- Create index for custom fields
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_custom_fields ON pipeline_stages USING gin(custom_fields);