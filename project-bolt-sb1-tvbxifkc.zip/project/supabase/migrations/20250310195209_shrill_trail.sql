/*
  # Add deal-contacts relationship

  1. New Tables
    - `deal_contacts` (junction table)
      - `id` (uuid, primary key)
      - `deal_id` (uuid, foreign key to deals)
      - `contact_id` (uuid, foreign key to contacts)
      - `role` (text) - e.g., 'decision_maker', 'influencer', etc.
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `deal_contacts` table
    - Add policy for authenticated users to manage their own deal contacts
*/

-- Create junction table for deals and contacts
CREATE TABLE IF NOT EXISTS deal_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  role text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(deal_id, contact_id)
);

-- Enable RLS
ALTER TABLE deal_contacts ENABLE ROW LEVEL SECURITY;

-- Add policy for authenticated users
CREATE POLICY "Users can manage their own deal contacts"
  ON deal_contacts
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM deals
      WHERE deals.id = deal_contacts.deal_id
      AND deals.owner_id = auth.uid()
    )
  );

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS deal_contacts_deal_id_idx ON deal_contacts(deal_id);
CREATE INDEX IF NOT EXISTS deal_contacts_contact_id_idx ON deal_contacts(contact_id);