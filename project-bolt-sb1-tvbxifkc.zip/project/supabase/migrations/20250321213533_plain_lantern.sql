/*
  # Fix Organization Member Policies

  1. Changes
    - Drop existing policies
    - Create new non-recursive policies for organization access
    - Fix default organization handling
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view organizations" ON organizations;
  DROP POLICY IF EXISTS "Users can manage organizations" ON organizations;
  DROP POLICY IF EXISTS "Users can view organization members" ON organization_members;
  DROP POLICY IF EXISTS "Organization owners can manage members" ON organization_members;
  DROP POLICY IF EXISTS "Allow access to default organization members" ON organization_members;
  DROP POLICY IF EXISTS "Users can view whitelabel configs" ON whitelabel_configs;
  DROP POLICY IF EXISTS "Organization owners can manage whitelabel configs" ON whitelabel_configs;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new non-recursive policies
CREATE POLICY "Users can view organizations"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (
    id = 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9' OR  -- Allow access to default org
    owner_id = auth.uid() OR                         -- Allow access to owned orgs
    id IN (                                          -- Allow access to member orgs
      SELECT organization_id 
      FROM organization_members 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can manage organizations"
  ON organizations
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Default organization access"
  ON organization_members
  FOR SELECT
  TO authenticated
  USING (organization_id = 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9');

CREATE POLICY "Users can view their organization memberships"
  ON organization_members
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Organization owners can manage members"
  ON organization_members
  FOR ALL
  TO authenticated
  USING (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Default whitelabel config access"
  ON whitelabel_configs
  FOR SELECT
  TO authenticated
  USING (organization_id = 'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9');

CREATE POLICY "Users can view their organization whitelabel configs"
  ON whitelabel_configs
  FOR SELECT
  TO authenticated
  USING (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Organization owners can manage whitelabel configs"
  ON whitelabel_configs
  FOR ALL
  TO authenticated
  USING (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT id FROM organizations WHERE owner_id = auth.uid()
    )
  );

-- Ensure default organization exists
INSERT INTO organizations (
  id,
  name,
  slug,
  domain
) VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'Default Organization',
  'default',
  'localhost'
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  slug = EXCLUDED.slug,
  domain = EXCLUDED.domain;

-- Ensure default whitelabel config exists
INSERT INTO whitelabel_configs (
  organization_id,
  name,
  primary_color,
  secondary_color,
  accent_color,
  font_family,
  is_active
) VALUES (
  'c0d1f8c9-3f44-4b1c-8b9e-d2c4d7c3f8a9',
  'Default Configuration',
  '#4F46E5',
  '#818CF8',
  '#6366F1',
  'Inter',
  true
) ON CONFLICT (organization_id) DO UPDATE SET
  name = EXCLUDED.name,
  primary_color = EXCLUDED.primary_color,
  secondary_color = EXCLUDED.secondary_color,
  accent_color = EXCLUDED.accent_color,
  font_family = EXCLUDED.font_family,
  is_active = EXCLUDED.is_active;