/*
  # Add Pipeline Stages Management

  1. New Tables
    - `pipeline_stages`
      - Stores customizable pipeline stages
      - Allows users to define their own stages
      - Includes order, color, and automation settings

  2. Changes
    - Add foreign key to deals table
    - Migrate existing stage data
    - Add RLS policies
*/

-- Create pipeline stages table
CREATE TABLE IF NOT EXISTS pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  color text NOT NULL DEFAULT 'bg-gray-600',
  order_number integer NOT NULL,
  owner_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tasks text[] DEFAULT '{}',
  automations text[] DEFAULT '{}',
  is_system boolean DEFAULT false,
  is_closed boolean DEFAULT false,
  is_won boolean DEFAULT false
);

-- Enable RLS
ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their pipeline stages" ON pipeline_stages;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Add RLS policy
CREATE POLICY "Users can manage their pipeline stages"
  ON pipeline_stages
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid() OR is_system = true)
  WITH CHECK (owner_id = auth.uid());

-- Add stage_id to deals table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'deals' AND column_name = 'stage_id'
  ) THEN
    ALTER TABLE deals ADD COLUMN stage_id uuid REFERENCES pipeline_stages(id);
  END IF;
END $$;

-- Insert default system stages
INSERT INTO pipeline_stages (
  name, description, color, order_number, is_system,
  tasks, automations, is_closed, is_won
) VALUES
  (
    'Prospecting',
    'Initial contact and lead qualification',
    'bg-blue-600',
    1,
    true,
    ARRAY[
      'Research company background',
      'Identify key decision makers',
      'Initial contact attempt'
    ],
    ARRAY[
      'Send welcome email',
      'Create follow-up task',
      'LinkedIn connection request'
    ],
    false,
    false
  ),
  (
    'Qualification',
    'Assessing needs and budget',
    'bg-purple-600',
    2,
    true,
    ARRAY[
      'Assess budget and timeline',
      'Identify pain points',
      'Confirm decision-making process'
    ],
    ARRAY[
      'Schedule discovery call',
      'Send qualification survey',
      'Create opportunity'
    ],
    false,
    false
  ),
  (
    'Proposal',
    'Proposal preparation and presentation',
    'bg-yellow-600',
    3,
    true,
    ARRAY[
      'Draft proposal document',
      'Internal pricing review',
      'Prepare presentation'
    ],
    ARRAY[
      'Generate proposal document',
      'Set internal review deadline',
      'Schedule presentation'
    ],
    false,
    false
  ),
  (
    'Negotiation',
    'Contract negotiation and review',
    'bg-orange-600',
    4,
    true,
    ARRAY[
      'Review contract terms',
      'Address objections',
      'Get stakeholder approval'
    ],
    ARRAY[
      'Send contract for review',
      'Schedule negotiation call',
      'Set follow-up reminder'
    ],
    false,
    false
  ),
  (
    'Closed Won',
    'Deal successfully closed',
    'bg-green-600',
    5,
    true,
    ARRAY[
      'Send final contract',
      'Schedule kickoff meeting',
      'Set up account'
    ],
    ARRAY[
      'Generate welcome packet',
      'Notify implementation team',
      'Schedule onboarding'
    ],
    true,
    true
  ),
  (
    'Closed Lost',
    'Deal lost or abandoned',
    'bg-red-600',
    6,
    true,
    ARRAY[
      'Document loss reasons',
      'Schedule post-mortem',
      'Update CRM'
    ],
    ARRAY[
      'Send feedback survey',
      'Schedule follow-up in 6 months',
      'Archive documents'
    ],
    true,
    false
  ) ON CONFLICT DO NOTHING;

-- Migrate existing deals to use stage_id
DO $$ 
DECLARE 
  target_stage_id uuid;
BEGIN
  -- Update prospecting deals
  SELECT id INTO target_stage_id FROM pipeline_stages WHERE name = 'Prospecting';
  IF target_stage_id IS NOT NULL THEN
    UPDATE deals SET stage_id = target_stage_id WHERE stage = 'prospecting';
  END IF;

  -- Update qualification deals
  SELECT id INTO target_stage_id FROM pipeline_stages WHERE name = 'Qualification';
  IF target_stage_id IS NOT NULL THEN
    UPDATE deals SET stage_id = target_stage_id WHERE stage = 'qualification';
  END IF;

  -- Update proposal deals
  SELECT id INTO target_stage_id FROM pipeline_stages WHERE name = 'Proposal';
  IF target_stage_id IS NOT NULL THEN
    UPDATE deals SET stage_id = target_stage_id WHERE stage = 'proposal';
  END IF;

  -- Update negotiation deals
  SELECT id INTO target_stage_id FROM pipeline_stages WHERE name = 'Negotiation';
  IF target_stage_id IS NOT NULL THEN
    UPDATE deals SET stage_id = target_stage_id WHERE stage = 'negotiation';
  END IF;

  -- Update closed won deals
  SELECT id INTO target_stage_id FROM pipeline_stages WHERE name = 'Closed Won';
  IF target_stage_id IS NOT NULL THEN
    UPDATE deals SET stage_id = target_stage_id WHERE stage = 'closed_won';
  END IF;

  -- Update closed lost deals
  SELECT id INTO target_stage_id FROM pipeline_stages WHERE name = 'Closed Lost';
  IF target_stage_id IS NOT NULL THEN
    UPDATE deals SET stage_id = target_stage_id WHERE stage = 'closed_lost';
  END IF;
END $$;