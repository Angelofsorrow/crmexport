/*
  # Add Calendar Event Triggers and Functions

  1. New Functions
    - `process_calendar_event`: Handles calendar event creation and updates
    - `notify_event_attendees`: Sends notifications to event attendees
    - `sync_calendar_event`: Syncs events with external calendars
    - `log_calendar_activity`: Logs calendar-related activities

  2. Triggers
    - `calendar_event_processor`: Processes events after insert/update
    - `calendar_event_logger`: Logs calendar activities
    - `calendar_sync_trigger`: Triggers external calendar sync
*/

-- Create function to process calendar events
CREATE OR REPLACE FUNCTION process_calendar_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_record record;
  v_activity_id uuid;
BEGIN
  -- Get user information
  SELECT * INTO v_user_record 
  FROM auth.users 
  WHERE id = NEW.owner_id;

  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    due_date,
    contact_id,
    deal_id,
    owner_id,
    created_at
  ) VALUES (
    'calendar_event',
    NEW.title,
    NEW.description,
    NEW.start,
    NEW.contact_id,
    NEW.deal_id,
    NEW.owner_id,
    now()
  ) RETURNING id INTO v_activity_id;

  -- Log AI interaction for event processing
  INSERT INTO ai_interactions (
    user_id,
    request_type,
    request_data,
    status,
    created_at
  ) VALUES (
    NEW.owner_id,
    'calendar_event',
    jsonb_build_object(
      'event_id', NEW.id,
      'title', NEW.title,
      'start', NEW.start,
      'end', NEW."end",
      'attendees', NEW.attendees
    ),
    'completed',
    now()
  );

  -- Update AI context
  INSERT INTO ai_context (
    user_id,
    entity_type,
    entity_id,
    context_data,
    created_at
  ) VALUES (
    NEW.owner_id,
    'calendar_event',
    NEW.id,
    jsonb_build_object(
      'event_type', 'calendar',
      'title', NEW.title,
      'description', NEW.description,
      'start_time', NEW.start,
      'end_time', NEW."end",
      'location', NEW.location,
      'attendees', NEW.attendees
    ),
    now()
  ) ON CONFLICT (user_id, entity_type, entity_id) 
  DO UPDATE SET
    context_data = EXCLUDED.context_data,
    updated_at = now();

  -- Notify attendees if present
  IF NEW.attendees IS NOT NULL AND jsonb_array_length(NEW.attendees) > 0 THEN
    PERFORM notify_event_attendees(NEW);
  END IF;

  RETURN NEW;
END;
$$;

-- Create function to notify event attendees
CREATE OR REPLACE FUNCTION notify_event_attendees(event_record calendar_events)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  attendee jsonb;
BEGIN
  -- Loop through attendees array
  FOR attendee IN SELECT * FROM jsonb_array_elements(event_record.attendees)
  LOOP
    -- Create notification record
    INSERT INTO activities (
      type,
      title,
      description,
      due_date,
      contact_id,
      owner_id,
      created_at
    ) VALUES (
      'event_notification',
      'Calendar Invitation: ' || event_record.title,
      CASE 
        WHEN event_record.description IS NOT NULL 
        THEN event_record.description 
        ELSE 'You have been invited to an event'
      END,
      event_record.start,
      -- Try to find contact by email
      (
        SELECT id 
        FROM contacts 
        WHERE email = (attendee->>'email')
        LIMIT 1
      ),
      event_record.owner_id,
      now()
    );
  END LOOP;
END;
$$;

-- Create function to sync calendar events
CREATE OR REPLACE FUNCTION sync_calendar_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_email_account_record record;
BEGIN
  -- Get user's email accounts
  FOR v_email_account_record IN 
    SELECT * FROM email_accounts 
    WHERE owner_id = NEW.owner_id 
    AND is_active = true
  LOOP
    -- Log sync attempt
    INSERT INTO activities (
      type,
      title,
      description,
      owner_id,
      created_at
    ) VALUES (
      'calendar_sync',
      'Calendar Sync Attempted',
      'Attempting to sync event: ' || NEW.title,
      NEW.owner_id,
      now()
    );
  END LOOP;

  RETURN NEW;
END;
$$;

-- Create function to log calendar activities
CREATE OR REPLACE FUNCTION log_calendar_activity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'calendar_log',
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'Event Created'
      WHEN TG_OP = 'UPDATE' THEN 'Event Updated'
      WHEN TG_OP = 'DELETE' THEN 'Event Deleted'
      ELSE 'Event Modified'
    END,
    jsonb_build_object(
      'event_id', NEW.id,
      'title', NEW.title,
      'operation', TG_OP,
      'timestamp', now()
    )::text,
    NEW.owner_id,
    now()
  );

  RETURN NEW;
END;
$$;

-- Create calendar event triggers
CREATE TRIGGER calendar_event_processor
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION process_calendar_event();

CREATE TRIGGER calendar_event_logger
  AFTER INSERT OR UPDATE OR DELETE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION log_calendar_activity();

CREATE TRIGGER calendar_sync_trigger
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION sync_calendar_event();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_events_date_range 
  ON calendar_events (start, "end");

CREATE INDEX IF NOT EXISTS idx_calendar_events_owner_id 
  ON calendar_events (owner_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_contact_id 
  ON calendar_events (contact_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_deal_id 
  ON calendar_events (deal_id);