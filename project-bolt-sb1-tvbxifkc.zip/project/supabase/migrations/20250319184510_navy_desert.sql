/*
  # Initial CRM Schema Setup

  1. Tables
    - companies (base table)
    - contacts (references companies)
    - documents (references companies)
    - deals (references companies)
    - campaigns (references contacts)
    - campaign_steps (references campaigns)
    - campaign_contacts (references campaigns and contacts)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create companies table
CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  industry text,
  website text,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  status text DEFAULT 'lead',
  annual_revenue numeric,
  employee_count integer
);

-- Enable RLS on companies
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;

-- Add policy for companies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'companies' 
    AND policyname = 'Users can manage their own companies'
  ) THEN
    CREATE POLICY "Users can manage their own companies"
      ON companies
      FOR ALL
      TO authenticated
      USING (owner_id = auth.uid())
      WITH CHECK (owner_id = auth.uid());
  END IF;
END $$;

-- Create contacts table
CREATE TABLE IF NOT EXISTS contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text,
  phone text,
  job_title text,
  company_id uuid REFERENCES companies(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  last_contacted timestamptz
);

-- Enable RLS on contacts
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;

-- Add policy for contacts if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'contacts' 
    AND policyname = 'Users can manage their own contacts'
  ) THEN
    CREATE POLICY "Users can manage their own contacts"
      ON contacts
      FOR ALL
      TO authenticated
      USING (owner_id = auth.uid())
      WITH CHECK (owner_id = auth.uid());
  END IF;
END $$;

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL,
  size integer,
  company_id uuid REFERENCES companies(id),
  uploaded_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS on documents
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Add policy for documents
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'documents' 
    AND policyname = 'Users can manage their own documents'
  ) THEN
    CREATE POLICY "Users can manage their own documents"
      ON documents
      FOR ALL
      TO authenticated
      USING (owner_id = auth.uid())
      WITH CHECK (owner_id = auth.uid());
  END IF;
END $$;

-- Create deals table
CREATE TABLE IF NOT EXISTS deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  company_id uuid REFERENCES companies(id),
  amount numeric NOT NULL,
  stage text DEFAULT 'prospecting',
  status text DEFAULT 'open',
  close_date date,
  probability integer DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS on deals
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;

-- Add policy for deals
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'deals' 
    AND policyname = 'Users can manage their own deals'
  ) THEN
    CREATE POLICY "Users can manage their own deals"
      ON deals
      FOR ALL
      TO authenticated
      USING (owner_id = auth.uid())
      WITH CHECK (owner_id = auth.uid());
  END IF;
END $$;

-- Create campaigns table
CREATE TABLE IF NOT EXISTS campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'draft',
  owner_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create campaign steps table
CREATE TABLE IF NOT EXISTS campaign_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaigns(id) ON DELETE CASCADE,
  type text NOT NULL,
  delay_hours integer DEFAULT 0,
  subject text,
  content text NOT NULL,
  order_number integer NOT NULL,
  voicemail_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create campaign contacts table
CREATE TABLE IF NOT EXISTS campaign_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaigns(id) ON DELETE CASCADE,
  contact_id uuid REFERENCES contacts(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  current_step integer DEFAULT 0,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(campaign_id, contact_id)
);

-- Enable RLS
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_contacts ENABLE ROW LEVEL SECURITY;

-- Create policies for campaigns
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'campaigns' 
    AND policyname = 'Users can manage their own campaigns'
  ) THEN
    CREATE POLICY "Users can manage their own campaigns"
      ON campaigns
      FOR ALL
      TO authenticated
      USING (owner_id = auth.uid())
      WITH CHECK (owner_id = auth.uid());
  END IF;
END $$;

-- Create policies for campaign steps
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'campaign_steps' 
    AND policyname = 'Users can manage steps for their campaigns'
  ) THEN
    CREATE POLICY "Users can manage steps for their campaigns"
      ON campaign_steps
      FOR ALL
      TO authenticated
      USING (campaign_id IN (
        SELECT id FROM campaigns WHERE owner_id = auth.uid()
      ))
      WITH CHECK (campaign_id IN (
        SELECT id FROM campaigns WHERE owner_id = auth.uid()
      ));
  END IF;
END $$;

-- Create policies for campaign contacts
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'campaign_contacts' 
    AND policyname = 'Users can manage contacts for their campaigns'
  ) THEN
    CREATE POLICY "Users can manage contacts for their campaigns"
      ON campaign_contacts
      FOR ALL
      TO authenticated
      USING (campaign_id IN (
        SELECT id FROM campaigns WHERE owner_id = auth.uid()
      ))
      WITH CHECK (campaign_id IN (
        SELECT id FROM campaigns WHERE owner_id = auth.uid()
      ));
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS campaign_steps_campaign_id_idx ON campaign_steps(campaign_id);
CREATE INDEX IF NOT EXISTS campaign_steps_order_number_idx ON campaign_steps(order_number);
CREATE INDEX IF NOT EXISTS campaign_contacts_campaign_id_idx ON campaign_contacts(campaign_id);
CREATE INDEX IF NOT EXISTS campaign_contacts_contact_id_idx ON campaign_contacts(contact_id);