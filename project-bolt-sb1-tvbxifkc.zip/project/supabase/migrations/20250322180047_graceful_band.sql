/*
  # Add AI Assistant Functions and Triggers

  1. Functions
    - process_ai_request: Main function to handle AI requests
    - generate_ai_response: Generate responses using stored context
    - update_ai_context: Update context based on user interactions
    - log_ai_interaction: Log all AI interactions for analysis
    
  2. Triggers
    - ai_request_logger: Log all AI requests
    - ai_context_updater: Update context on relevant table changes
    - ai_response_handler: Handle response generation
*/

-- Create AI request types enum
CREATE TYPE ai_request_type AS ENUM (
  'email_draft',
  'meeting_summary',
  'task_suggestion',
  'deal_analysis',
  'contact_research',
  'document_generation'
);

-- Create AI interaction status enum
CREATE TYPE ai_interaction_status AS ENUM (
  'pending',
  'processing',
  'completed',
  'failed'
);

-- Create table for storing AI interactions
CREATE TABLE IF NOT EXISTS ai_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  request_type ai_request_type NOT NULL,
  request_data jsonb NOT NULL,
  response_data jsonb,
  context jsonb,
  status ai_interaction_status DEFAULT 'pending',
  error_message text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  tokens_used integer DEFAULT 0,
  model_version text,
  execution_time numeric
);

-- Create table for storing AI context
CREATE TABLE IF NOT EXISTS ai_context (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  context_data jsonb NOT NULL,
  relevance_score numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  UNIQUE(user_id, entity_type, entity_id)
);

-- Enable RLS
ALTER TABLE ai_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_context ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Users can view their AI interactions"
  ON ai_interactions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can manage their AI context"
  ON ai_context
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Create function to process AI requests
CREATE OR REPLACE FUNCTION process_ai_request(
  p_user_id uuid,
  p_request_type ai_request_type,
  p_request_data jsonb,
  p_context jsonb DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_interaction_id uuid;
  v_response jsonb;
  v_start_time timestamptz;
  v_end_time timestamptz;
BEGIN
  -- Start timing
  v_start_time := clock_timestamp();

  -- Create interaction record
  INSERT INTO ai_interactions (
    user_id,
    request_type,
    request_data,
    context,
    status
  )
  VALUES (
    p_user_id,
    p_request_type,
    p_request_data,
    p_context,
    'processing'
  )
  RETURNING id INTO v_interaction_id;

  -- Generate response based on request type
  v_response := generate_ai_response(
    p_request_type,
    p_request_data,
    p_context
  );

  -- Calculate execution time
  v_end_time := clock_timestamp();

  -- Update interaction record
  UPDATE ai_interactions
  SET
    response_data = v_response,
    status = 'completed',
    completed_at = v_end_time,
    execution_time = EXTRACT(EPOCH FROM (v_end_time - v_start_time))
  WHERE id = v_interaction_id;

  -- Update context
  PERFORM update_ai_context(
    p_user_id,
    p_request_data->>'entity_type',
    (p_request_data->>'entity_id')::uuid,
    v_response
  );

  RETURN v_response;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error and update interaction record
    UPDATE ai_interactions
    SET
      status = 'failed',
      error_message = SQLERRM,
      completed_at = clock_timestamp()
    WHERE id = v_interaction_id;
    
    RAISE;
END;
$$;

-- Create function to generate AI responses
CREATE OR REPLACE FUNCTION generate_ai_response(
  p_request_type ai_request_type,
  p_request_data jsonb,
  p_context jsonb DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_response jsonb;
BEGIN
  -- Different handling based on request type
  CASE p_request_type
    WHEN 'email_draft' THEN
      v_response := jsonb_build_object(
        'type', 'email',
        'subject', p_request_data->>'subject',
        'content', generate_email_content(p_request_data, p_context)
      );
      
    WHEN 'meeting_summary' THEN
      v_response := jsonb_build_object(
        'type', 'summary',
        'content', generate_meeting_summary(p_request_data, p_context)
      );
      
    WHEN 'task_suggestion' THEN
      v_response := jsonb_build_object(
        'type', 'tasks',
        'suggestions', generate_task_suggestions(p_request_data, p_context)
      );
      
    WHEN 'deal_analysis' THEN
      v_response := jsonb_build_object(
        'type', 'analysis',
        'content', analyze_deal(p_request_data, p_context)
      );
      
    WHEN 'contact_research' THEN
      v_response := jsonb_build_object(
        'type', 'research',
        'content', research_contact(p_request_data, p_context)
      );
      
    WHEN 'document_generation' THEN
      v_response := jsonb_build_object(
        'type', 'document',
        'content', generate_document(p_request_data, p_context)
      );
      
    ELSE
      RAISE EXCEPTION 'Unsupported request type: %', p_request_type;
  END CASE;

  RETURN v_response;
END;
$$;

-- Create function to update AI context
CREATE OR REPLACE FUNCTION update_ai_context(
  p_user_id uuid,
  p_entity_type text,
  p_entity_id uuid,
  p_new_data jsonb
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO ai_context (
    user_id,
    entity_type,
    entity_id,
    context_data,
    relevance_score,
    expires_at
  )
  VALUES (
    p_user_id,
    p_entity_type,
    p_entity_id,
    p_new_data,
    1.0,
    now() + interval '30 days'
  )
  ON CONFLICT (user_id, entity_type, entity_id)
  DO UPDATE SET
    context_data = ai_context.context_data || p_new_data,
    relevance_score = 1.0,
    updated_at = now(),
    expires_at = now() + interval '30 days';
END;
$$;

-- Create function to log AI interactions
CREATE OR REPLACE FUNCTION log_ai_interaction()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Log the interaction details
  INSERT INTO sensor_logs (
    sensor_data,
    reasoning
  ) VALUES (
    jsonb_build_object(
      'interaction_id', NEW.id,
      'user_id', NEW.user_id,
      'request_type', NEW.request_type,
      'status', NEW.status,
      'execution_time', NEW.execution_time
    ),
    CASE
      WHEN NEW.status = 'completed' THEN 'Successful AI interaction'
      WHEN NEW.status = 'failed' THEN 'Failed AI interaction: ' || NEW.error_message
      ELSE 'AI interaction status: ' || NEW.status::text
    END
  );
  
  RETURN NEW;
END;
$$;

-- Create trigger for logging AI interactions
CREATE TRIGGER ai_interaction_logger
  AFTER INSERT OR UPDATE ON ai_interactions
  FOR EACH ROW
  EXECUTE FUNCTION log_ai_interaction();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_ai_interactions_user_id ON ai_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_request_type ON ai_interactions(request_type);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_status ON ai_interactions(status);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_created_at ON ai_interactions(created_at);

CREATE INDEX IF NOT EXISTS idx_ai_context_user_id ON ai_context(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_context_entity ON ai_context(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_ai_context_expires_at ON ai_context(expires_at);

-- Helper functions for specific AI tasks
CREATE OR REPLACE FUNCTION generate_email_content(p_data jsonb, p_context jsonb)
RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  -- Implementation would integrate with OpenAI API
  -- This is a placeholder that would be replaced with actual API call
  RETURN 'Generated email content based on context';
END;
$$;

CREATE OR REPLACE FUNCTION generate_meeting_summary(p_data jsonb, p_context jsonb)
RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN 'Generated meeting summary based on context';
END;
$$;

CREATE OR REPLACE FUNCTION generate_task_suggestions(p_data jsonb, p_context jsonb)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN '["Suggested task 1", "Suggested task 2"]'::jsonb;
END;
$$;

CREATE OR REPLACE FUNCTION analyze_deal(p_data jsonb, p_context jsonb)
RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN 'Generated deal analysis based on context';
END;
$$;

CREATE OR REPLACE FUNCTION research_contact(p_data jsonb, p_context jsonb)
RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN 'Generated contact research based on context';
END;
$$;

CREATE OR REPLACE FUNCTION generate_document(p_data jsonb, p_context jsonb)
RETURNS text
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN 'Generated document content based on context';
END;
$$;