/*
  # Add Action Triggers and Functions

  1. Changes
    - Add trigger for email account creation
    - Add trigger for task creation
    - Add trigger for activity logging
    - Add trigger for AI interactions
    
  2. Security
    - Maintain RLS policies
    - Add proper error handling
*/

-- Create function to log activities
CREATE OR REPLACE FUNCTION log_activity()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    TG_ARGV[0],
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'Created ' || TG_ARGV[0]
      WHEN TG_OP = 'UPDATE' THEN 'Updated ' || TG_ARGV[0]
      WHEN TG_OP = 'DELETE' THEN 'Deleted ' || TG_ARGV[0]
      ELSE 'Modified ' || TG_ARGV[0]
    END,
    jsonb_build_object(
      'table', TG_TABLE_NAME,
      'operation', TG_OP,
      'record_id', COALESCE(NEW.id, OLD.id),
      'timestamp', now()
    )::text,
    COALESCE(NEW.owner_id, OLD.owner_id),
    now()
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to log task activities specifically
CREATE OR REPLACE FUNCTION log_task_activity()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    -- For DELETE operations, use OLD.type
    IF OLD.type = 'task' THEN
      INSERT INTO activities (
        type,
        title,
        description,
        owner_id,
        created_at
      ) VALUES (
        'task_log',
        'Task Deleted',
        format('Task "%s" was deleted', OLD.title),
        OLD.owner_id,
        now()
      );
    END IF;
    RETURN OLD;
  ELSE
    -- For INSERT/UPDATE operations, use NEW.type
    IF NEW.type = 'task' THEN
      INSERT INTO activities (
        type,
        title,
        description,
        owner_id,
        created_at
      ) VALUES (
        'task_log',
        CASE 
          WHEN TG_OP = 'INSERT' THEN 'Task Created'
          ELSE 'Task Updated'
        END,
        format('Task "%s" was %s', NEW.title, lower(TG_OP)),
        NEW.owner_id,
        now()
      );
    END IF;
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Create function to ensure user has an email account
CREATE OR REPLACE FUNCTION ensure_user_email_account()
RETURNS TRIGGER AS $$
BEGIN
  -- Create default email account for new user
  INSERT INTO email_accounts (
    email,
    display_name,
    imap_host,
    imap_port,
    smtp_host,
    smtp_port,
    username,
    password,
    is_active,
    owner_id,
    provider
  ) VALUES (
    NEW.email,
    split_part(NEW.email, '@', 1),
    'localhost',
    993,
    'localhost',
    587,
    NEW.email,
    'default-password',
    true,
    NEW.id,
    'system'
  ) ON CONFLICT (email, owner_id) DO NOTHING;

  -- Log the email account creation
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'email_account_created',
    'Email Account Created',
    'Default email account created for user',
    NEW.id,
    now()
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to process AI calendar requests
CREATE OR REPLACE FUNCTION process_ai_calendar_request()
RETURNS TRIGGER AS $$
DECLARE
  v_interaction_id uuid;
BEGIN
  -- Create AI interaction record
  INSERT INTO ai_interactions (
    user_id,
    request_type,
    request_data,
    status,
    created_at
  ) VALUES (
    NEW.owner_id,
    'calendar_event',
    jsonb_build_object(
      'event_id', NEW.id,
      'title', NEW.title,
      'description', NEW.description,
      'start_time', NEW.start,
      'end_time', NEW."end",
      'location', NEW.location,
      'attendees', NEW.attendees
    ),
    'completed',
    now()
  ) RETURNING id INTO v_interaction_id;

  -- Log the interaction
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'ai_calendar_event',
    'AI Calendar Event Created',
    format('AI created calendar event: %s', NEW.title),
    NEW.owner_id,
    now()
  );

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO activities (
      type,
      title,
      description,
      owner_id,
      created_at
    ) VALUES (
      'error',
      'AI Calendar Event Error',
      format('Error creating calendar event: %s', SQLERRM),
      NEW.owner_id,
      now()
    );
    
    RAISE;
END;
$$ LANGUAGE plpgsql;

-- Create function to create contact from email
CREATE OR REPLACE FUNCTION create_contact_from_email()
RETURNS TRIGGER AS $$
DECLARE
  v_contact_id uuid;
  v_first_name text;
  v_last_name text;
  v_email text;
BEGIN
  -- Extract email from request data for calendar events
  IF NEW.request_type = 'calendar_event' THEN
    -- Loop through attendees array if it exists
    IF NEW.request_data->>'eventDetails' IS NOT NULL AND 
       (NEW.request_data->'eventDetails'->'attendees') IS NOT NULL THEN
      
      FOR i IN 0..jsonb_array_length(NEW.request_data->'eventDetails'->'attendees') - 1 LOOP
        v_email := NEW.request_data->'eventDetails'->'attendees'->i->>'email';
        
        -- Skip if no email
        IF v_email IS NULL THEN
          CONTINUE;
        END IF;

        -- Check if contact exists
        IF NOT EXISTS (
          SELECT 1 FROM contacts WHERE email = v_email
        ) THEN
          -- Parse name if provided
          IF NEW.request_data->'eventDetails'->'attendees'->i->>'name' IS NOT NULL THEN
            v_first_name := split_part(NEW.request_data->'eventDetails'->'attendees'->i->>'name', ' ', 1);
            v_last_name := substring(NEW.request_data->'eventDetails'->'attendees'->i->>'name' from position(' ' in NEW.request_data->'eventDetails'->'attendees'->i->>'name') + 1);
          ELSE
            -- Use email prefix as first name
            v_first_name := split_part(v_email, '@', 1);
            v_last_name := '';
          END IF;

          -- Create new contact
          INSERT INTO contacts (
            first_name,
            last_name,
            email,
            owner_id,
            created_at,
            updated_at
          ) VALUES (
            v_first_name,
            v_last_name,
            v_email,
            NEW.user_id,
            now(),
            now()
          ) RETURNING id INTO v_contact_id;

          -- Log contact creation
          INSERT INTO activities (
            type,
            title,
            description,
            owner_id,
            contact_id,
            created_at
          ) VALUES (
            'contact_created',
            'Contact Created by AI Assistant',
            format('Created contact for %s (%s)', 
              CASE 
                WHEN v_last_name = '' THEN v_first_name
                ELSE v_first_name || ' ' || v_last_name
              END,
              v_email
            ),
            NEW.user_id,
            v_contact_id,
            now()
          );
        END IF;
      END LOOP;
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to create contact from calendar event
CREATE OR REPLACE FUNCTION create_contact_from_calendar_event()
RETURNS TRIGGER AS $$
DECLARE
  v_contact_id uuid;
  v_first_name text;
  v_last_name text;
  v_email text;
  attendee jsonb;
BEGIN
  -- Process attendees array
  IF NEW.attendees IS NOT NULL AND jsonb_array_length(NEW.attendees) > 0 THEN
    FOR attendee IN SELECT * FROM jsonb_array_elements(NEW.attendees)
    LOOP
      v_email := attendee->>'email';
      
      -- Skip if no email
      IF v_email IS NULL THEN
        CONTINUE;
      END IF;

      -- Check if contact exists
      IF NOT EXISTS (
        SELECT 1 FROM contacts WHERE email = v_email
      ) THEN
        -- Parse name if provided
        IF attendee->>'name' IS NOT NULL THEN
          v_first_name := split_part(attendee->>'name', ' ', 1);
          v_last_name := substring(attendee->>'name' from position(' ' in attendee->>'name') + 1);
        ELSE
          -- Use email prefix as first name
          v_first_name := split_part(v_email, '@', 1);
          v_last_name := '';
        END IF;

        -- Create new contact
        INSERT INTO contacts (
          first_name,
          last_name,
          email,
          owner_id,
          created_at,
          updated_at
        ) VALUES (
          v_first_name,
          v_last_name,
          v_email,
          NEW.owner_id,
          now(),
          now()
        ) RETURNING id INTO v_contact_id;

        -- Log contact creation
        INSERT INTO activities (
          type,
          title,
          description,
          owner_id,
          contact_id,
          created_at
        ) VALUES (
          'contact_created',
          'Contact Created from Calendar Event',
          format('Created contact for %s (%s)', 
            CASE 
              WHEN v_last_name = '' THEN v_first_name
              ELSE v_first_name || ' ' || v_last_name
            END,
            v_email
          ),
          NEW.owner_id,
          v_contact_id,
          now()
        );
      END IF;
    END LOOP;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for email accounts
DROP TRIGGER IF EXISTS on_auth_user_created_email ON auth.users;
CREATE TRIGGER on_auth_user_created_email
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION ensure_user_email_account();

-- Create triggers for activities
DROP TRIGGER IF EXISTS log_email_account_activity ON email_accounts;
CREATE TRIGGER log_email_account_activity
  AFTER INSERT OR UPDATE OR DELETE ON email_accounts
  FOR EACH ROW
  EXECUTE FUNCTION log_activity('email_account');

-- Create separate triggers for task activities
DROP TRIGGER IF EXISTS log_task_insert ON activities;
CREATE TRIGGER log_task_insert
  AFTER INSERT ON activities
  FOR EACH ROW
  WHEN (NEW.type = 'task')
  EXECUTE FUNCTION log_task_activity();

DROP TRIGGER IF EXISTS log_task_update ON activities;
CREATE TRIGGER log_task_update
  AFTER UPDATE ON activities
  FOR EACH ROW
  WHEN (NEW.type = 'task')
  EXECUTE FUNCTION log_task_activity();

DROP TRIGGER IF EXISTS log_task_delete ON activities;
CREATE TRIGGER log_task_delete
  AFTER DELETE ON activities
  FOR EACH ROW
  WHEN (OLD.type = 'task')
  EXECUTE FUNCTION log_task_activity();

-- Create triggers for AI interactions
DROP TRIGGER IF EXISTS ai_contact_creator ON ai_interactions;
CREATE TRIGGER ai_contact_creator
  AFTER INSERT ON ai_interactions
  FOR EACH ROW
  EXECUTE FUNCTION create_contact_from_email();

-- Create triggers for calendar events
DROP TRIGGER IF EXISTS calendar_event_contact_creator ON calendar_events;
CREATE TRIGGER calendar_event_contact_creator
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION create_contact_from_calendar_event();

DROP TRIGGER IF EXISTS ai_calendar_event_processor ON calendar_events;
CREATE TRIGGER ai_calendar_event_processor
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  WHEN (NEW.source = 'ai_agent')
  EXECUTE FUNCTION process_ai_calendar_request();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(type);
CREATE INDEX IF NOT EXISTS idx_activities_owner_id ON activities(owner_id);
CREATE INDEX IF NOT EXISTS idx_activities_created_at ON activities(created_at);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_request_type ON ai_interactions(request_type);
CREATE INDEX IF NOT EXISTS idx_calendar_events_source ON calendar_events(source);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);