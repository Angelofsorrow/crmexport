-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their custom fields" ON custom_fields;
  DROP POLICY IF EXISTS "Users can manage their custom field values" ON custom_field_values;
  DROP POLICY IF EXISTS "Users can manage their tags" ON tags;
  DROP POLICY IF EXISTS "Users can manage their entity tags" ON entity_tags;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create custom fields table
CREATE TABLE IF NOT EXISTS custom_fields (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  label text NOT NULL,
  type text NOT NULL,
  entity_type text NOT NULL,
  options jsonb,
  default_value text,
  is_required boolean DEFAULT false,
  is_searchable boolean DEFAULT false,
  validation_rules jsonb,
  display_order integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  UNIQUE(name, entity_type, owner_id)
);

-- Create custom field values table
CREATE TABLE IF NOT EXISTS custom_field_values (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  field_id uuid REFERENCES custom_fields(id) ON DELETE CASCADE,
  entity_id uuid NOT NULL,
  value text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(field_id, entity_id)
);

-- Create tags table
CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  color text NOT NULL DEFAULT 'bg-gray-100',
  entity_type text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  UNIQUE(name, entity_type, owner_id)
);

-- Create entity tags junction table
CREATE TABLE IF NOT EXISTS entity_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tag_id uuid REFERENCES tags(id) ON DELETE CASCADE,
  entity_id uuid NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(tag_id, entity_id)
);

-- Enable RLS
ALTER TABLE custom_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_field_values ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE entity_tags ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Users can manage their custom fields"
  ON custom_fields
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their custom field values"
  ON custom_field_values
  FOR ALL
  TO authenticated
  USING (
    field_id IN (
      SELECT id FROM custom_fields WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    field_id IN (
      SELECT id FROM custom_fields WHERE owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can manage their tags"
  ON tags
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their entity tags"
  ON entity_tags
  FOR ALL
  TO authenticated
  USING (
    tag_id IN (
      SELECT id FROM tags WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    tag_id IN (
      SELECT id FROM tags WHERE owner_id = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_custom_fields_entity_type ON custom_fields(entity_type);
CREATE INDEX IF NOT EXISTS idx_custom_fields_owner_id ON custom_fields(owner_id);
CREATE INDEX IF NOT EXISTS idx_custom_field_values_field_id ON custom_field_values(field_id);
CREATE INDEX IF NOT EXISTS idx_custom_field_values_entity_id ON custom_field_values(entity_id);
CREATE INDEX IF NOT EXISTS idx_tags_entity_type ON tags(entity_type);
CREATE INDEX IF NOT EXISTS idx_tags_owner_id ON tags(owner_id);
CREATE INDEX IF NOT EXISTS idx_entity_tags_tag_id ON entity_tags(tag_id);
CREATE INDEX IF NOT EXISTS idx_entity_tags_entity_id ON entity_tags(entity_id);

-- Insert some default tags
INSERT INTO tags (name, color, entity_type, owner_id) VALUES
  ('Hot Lead', 'bg-red-100', 'contact', NULL),
  ('Warm Lead', 'bg-yellow-100', 'contact', NULL),
  ('Cold Lead', 'bg-blue-100', 'contact', NULL),
  ('VIP', 'bg-purple-100', 'contact', NULL),
  ('Follow Up', 'bg-green-100', 'contact', NULL),
  ('High Priority', 'bg-red-100', 'deal', NULL),
  ('Needs Attention', 'bg-yellow-100', 'deal', NULL),
  ('Complex Deal', 'bg-purple-100', 'deal', NULL),
  ('Quick Close', 'bg-green-100', 'deal', NULL),
  ('Competitive', 'bg-blue-100', 'deal', NULL);

-- Insert some default custom fields
INSERT INTO custom_fields (
  name, label, type, entity_type, options, default_value,
  is_required, is_searchable, validation_rules, display_order, owner_id
) VALUES
  (
    'linkedin_url',
    'LinkedIn URL',
    'url',
    'contact',
    NULL,
    NULL,
    false,
    true,
    '{"pattern": "^https://www\\.linkedin\\.com/.*$"}',
    1,
    NULL
  ),
  (
    'industry',
    'Industry',
    'select',
    'contact',
    '["Technology", "Healthcare", "Finance", "Real Estate", "Manufacturing", "Retail", "Other"]',
    NULL,
    false,
    true,
    NULL,
    2,
    NULL
  ),
  (
    'deal_source',
    'Deal Source',
    'select',
    'deal',
    '["Referral", "Website", "Cold Call", "Event", "Partner", "Other"]',
    NULL,
    true,
    true,
    NULL,
    1,
    NULL
  ),
  (
    'next_steps',
    'Next Steps',
    'textarea',
    'deal',
    NULL,
    NULL,
    false,
    false,
    NULL,
    2,
    NULL
  ),
  (
    'decision_maker',
    'Decision Maker',
    'text',
    'deal',
    NULL,
    NULL,
    true,
    true,
    NULL,
    3,
    NULL
  );