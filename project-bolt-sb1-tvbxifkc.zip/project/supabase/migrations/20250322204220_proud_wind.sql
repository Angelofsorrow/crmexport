/*
  # Update AI Assistant Contact Creation Triggers

  1. Changes
    - Add trigger for creating contacts from AI interactions
    - Add function to handle contact creation
    - Update calendar event processing to handle new contacts
    
  2. Security
    - Maintain existing RLS policies
    - Add proper error handling
*/

-- Create function to handle contact creation
CREATE OR REPLACE FUNCTION create_contact_from_email()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_contact_id uuid;
  v_first_name text;
  v_last_name text;
  v_email text;
BEGIN
  -- Extract email from request data for calendar events
  IF NEW.request_type = 'calendar_event' THEN
    -- Loop through attendees array if it exists
    IF NEW.request_data->>'eventDetails' IS NOT NULL AND 
       (NEW.request_data->'eventDetails'->'attendees') IS NOT NULL THEN
      
      FOR i IN 0..jsonb_array_length(NEW.request_data->'eventDetails'->'attendees') - 1 LOOP
        v_email := NEW.request_data->'eventDetails'->'attendees'->i->>'email';
        
        -- Skip if no email
        IF v_email IS NULL THEN
          CONTINUE;
        END IF;

        -- Check if contact exists
        IF NOT EXISTS (
          SELECT 1 FROM contacts WHERE email = v_email
        ) THEN
          -- Parse name if provided
          IF NEW.request_data->'eventDetails'->'attendees'->i->>'name' IS NOT NULL THEN
            v_first_name := split_part(NEW.request_data->'eventDetails'->'attendees'->i->>'name', ' ', 1);
            v_last_name := substring(NEW.request_data->'eventDetails'->'attendees'->i->>'name' from position(' ' in NEW.request_data->'eventDetails'->'attendees'->i->>'name') + 1);
          ELSE
            -- Use email prefix as first name
            v_first_name := split_part(v_email, '@', 1);
            v_last_name := '';
          END IF;

          -- Create new contact
          INSERT INTO contacts (
            first_name,
            last_name,
            email,
            owner_id,
            created_at,
            updated_at
          ) VALUES (
            v_first_name,
            v_last_name,
            v_email,
            NEW.user_id,
            now(),
            now()
          ) RETURNING id INTO v_contact_id;

          -- Log contact creation
          INSERT INTO activities (
            type,
            title,
            description,
            owner_id,
            contact_id,
            created_at
          ) VALUES (
            'contact_created',
            'Contact Created by AI Assistant',
            format('Created contact for %s (%s)', 
              CASE 
                WHEN v_last_name = '' THEN v_first_name
                ELSE v_first_name || ' ' || v_last_name
              END,
              v_email
            ),
            NEW.user_id,
            v_contact_id,
            now()
          );
        END IF;
      END LOOP;
    END IF;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'Contact Creation from AI Request',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Create trigger for contact creation
CREATE TRIGGER ai_contact_creator
  AFTER INSERT ON ai_interactions
  FOR EACH ROW
  EXECUTE FUNCTION create_contact_from_email();

-- Update calendar event processor to handle new contacts
CREATE OR REPLACE FUNCTION process_calendar_event()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_activity_id uuid;
  v_contact_id uuid;
  v_email text;
BEGIN
  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    due_date,
    contact_id,
    deal_id,
    owner_id,
    created_at
  ) VALUES (
    'calendar_event',
    NEW.title,
    COALESCE(NEW.description, 'Calendar event'),
    NEW.start,
    NEW.contact_id,
    NEW.deal_id,
    NEW.owner_id,
    now()
  ) RETURNING id INTO v_activity_id;

  -- Process attendees
  IF NEW.attendees IS NOT NULL AND jsonb_array_length(NEW.attendees) > 0 THEN
    FOR i IN 0..jsonb_array_length(NEW.attendees) - 1 LOOP
      v_email := NEW.attendees->i->>'email';
      
      -- Try to find existing contact
      SELECT id INTO v_contact_id
      FROM contacts
      WHERE email = v_email
      LIMIT 1;

      -- Create notification
      INSERT INTO activities (
        type,
        title,
        description,
        due_date,
        contact_id,
        owner_id,
        created_at
      ) VALUES (
        'event_notification',
        'Calendar Invitation: ' || NEW.title,
        COALESCE(NEW.description, 'You have been invited to an event'),
        NEW.start,
        v_contact_id,
        NEW.owner_id,
        now()
      );
    END LOOP;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error
    INSERT INTO physical_agent_errors (
      context,
      error,
      stack
    ) VALUES (
      'Calendar Event Processing',
      SQLERRM,
      current_setting('proc.context')
    );
    
    RAISE;
END;
$$;

-- Recreate calendar event triggers
DROP TRIGGER IF EXISTS calendar_event_processor ON calendar_events;
CREATE TRIGGER calendar_event_processor
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION process_calendar_event();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX IF NOT EXISTS idx_contacts_owner_id ON contacts(owner_id);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_request_type ON ai_interactions(request_type);