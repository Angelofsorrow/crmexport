/*
  # Fix API Keys RLS Policy

  1. Changes
    - Drop existing policy
    - Create new policy that properly handles new key creation
    - Add owner_id check for both USING and WITH CHECK clauses
*/

-- Drop existing policy
DROP POLICY IF EXISTS "Users can manage their API keys" ON api_keys;

-- Create new policy that properly handles key creation
CREATE POLICY "Users can manage their API keys"
  ON api_keys
  FOR ALL
  TO authenticated
  USING (
    CASE 
      WHEN owner_id IS NULL THEN true  -- Allow creation of new keys
      ELSE owner_id = auth.uid()       -- Only allow access to owned keys
    END
  )
  WITH CHECK (
    CASE
      WHEN owner_id IS NULL THEN true  -- Allow creation of new keys
      ELSE owner_id = auth.uid()       -- Only allow modifications to owned keys
    END
  );

-- Create index for better performance if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_api_keys_owner_id ON api_keys(owner_id);