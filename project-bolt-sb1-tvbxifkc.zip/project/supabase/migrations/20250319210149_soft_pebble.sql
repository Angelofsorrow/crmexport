-- Add contact_id to deals table
ALTER TABLE deals 
ADD COLUMN IF NOT EXISTS contact_id uuid REFERENCES contacts(id) ON DELETE SET NULL;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_deals_contact_id ON deals(contact_id);

-- Update existing deals to use the primary contact from deal_contacts
DO $$
DECLARE
  deal_record RECORD;
BEGIN
  FOR deal_record IN SELECT d.id FROM deals d
  LOOP
    UPDATE deals d
    SET contact_id = (
      SELECT dc.contact_id 
      FROM deal_contacts dc 
      WHERE dc.deal_id = deal_record.id 
      LIMIT 1
    )
    WHERE d.id = deal_record.id;
  END LOOP;
END $$;

-- Add RLS policy for deals based on contact_id
CREATE POLICY "Users can manage deals through contacts"
  ON deals
  FOR ALL
  TO authenticated
  USING (
    owner_id = auth.uid() OR
    contact_id IN (
      SELECT id FROM contacts WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    owner_id = auth.uid() OR
    contact_id IN (
      SELECT id FROM contacts WHERE owner_id = auth.uid()
    )
  );