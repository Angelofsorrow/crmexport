/*
  # Add Inbox System Tables

  1. New Tables
    - `email_accounts`: Email account configurations
    - `messages`: Unified message storage for emails, texts, and calls
    - `message_threads`: Group related messages
    - `message_attachments`: Store message attachments
    
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their email accounts" ON email_accounts;
  DROP POLICY IF EXISTS "Users can manage their messages" ON messages;
  DROP POLICY IF EXISTS "Users can manage their message threads" ON message_threads;
  DROP POLICY IF EXISTS "Users can manage their message attachments" ON message_attachments;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create email accounts table if it doesn't exist
CREATE TABLE IF NOT EXISTS email_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  display_name text,
  imap_host text NOT NULL,
  imap_port integer NOT NULL,
  smtp_host text NOT NULL,
  smtp_port integer NOT NULL,
  username text NOT NULL,
  password text NOT NULL,
  is_active boolean DEFAULT true,
  last_sync_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id),
  UNIQUE(email, owner_id)
);

-- Create messages table if it doesn't exist
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('email', 'text', 'call')),
  direction text NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  status text NOT NULL DEFAULT 'received',
  subject text,
  body text,
  from_email text,
  from_name text,
  from_phone text,
  to_email text[],
  to_phone text,
  cc_email text[],
  bcc_email text[],
  thread_id uuid,
  message_id text,
  in_reply_to text,
  reference_ids text[],
  sent_at timestamptz,
  received_at timestamptz DEFAULT now(),
  read_at timestamptz,
  contact_id uuid REFERENCES contacts(id),
  deal_id uuid REFERENCES deals(id),
  email_account_id uuid REFERENCES email_accounts(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Create message threads table if it doesn't exist
CREATE TABLE IF NOT EXISTS message_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject text,
  snippet text,
  last_message_at timestamptz,
  message_count integer DEFAULT 1,
  unread_count integer DEFAULT 0,
  participants jsonb,
  labels text[],
  contact_id uuid REFERENCES contacts(id),
  deal_id uuid REFERENCES deals(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Create message attachments table if it doesn't exist
CREATE TABLE IF NOT EXISTS message_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid REFERENCES messages(id) ON DELETE CASCADE,
  filename text NOT NULL,
  content_type text NOT NULL,
  size integer NOT NULL,
  storage_path text NOT NULL,
  created_at timestamptz DEFAULT now(),
  owner_id uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE email_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_attachments ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Users can manage their email accounts"
  ON email_accounts
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their messages"
  ON messages
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their message threads"
  ON message_threads
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

CREATE POLICY "Users can manage their message attachments"
  ON message_attachments
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_messages_thread_id ON messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_messages_contact_id ON messages(contact_id);
CREATE INDEX IF NOT EXISTS idx_messages_deal_id ON messages(deal_id);
CREATE INDEX IF NOT EXISTS idx_messages_email_account_id ON messages(email_account_id);
CREATE INDEX IF NOT EXISTS idx_messages_received_at ON messages(received_at);
CREATE INDEX IF NOT EXISTS idx_messages_type ON messages(type);
CREATE INDEX IF NOT EXISTS idx_message_threads_last_message_at ON message_threads(last_message_at);
CREATE INDEX IF NOT EXISTS idx_message_threads_contact_id ON message_threads(contact_id);
CREATE INDEX IF NOT EXISTS idx_message_threads_deal_id ON message_threads(deal_id);