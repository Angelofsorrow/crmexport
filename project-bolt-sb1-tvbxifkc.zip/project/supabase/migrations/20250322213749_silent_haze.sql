/*
  # Add CRM Action Triggers

  1. Functions
    - `log_activity`: Generic activity logging
    - `log_task_activity`: Task-specific logging
    - `log_calendar_activity`: Calendar event logging
    - `sync_calendar_event`: Calendar sync handling
    - `process_calendar_event`: Calendar event processing
    - `process_ai_calendar_request`: AI calendar handling
    - `create_contact_from_email`: Contact creation from email
    - `create_contact_from_calendar_event`: Contact creation from calendar
    - `handle_user_input`: User input processing
    - `update_deal_status`: Deal status updates
    - `ensure_user_organization`: Organization setup
    - `ensure_user_email_account`: Email account setup
*/

-- Create function to update deal status based on stage
CREATE OR REPLACE FUNCTION update_deal_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Get stage information
  WITH stage_info AS (
    SELECT is_closed, is_won
    FROM pipeline_stages
    WHERE id = NEW.stage_id
  )
  -- Update deal status based on stage
  UPDATE deals SET
    status = CASE 
      WHEN (SELECT is_closed FROM stage_info) THEN
        CASE 
          WHEN (SELECT is_won FROM stage_info) THEN 'won'
          ELSE 'lost'
        END
      ELSE 'open'
    END
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to log AI interactions
CREATE OR REPLACE FUNCTION log_ai_interaction()
RETURNS TRIGGER AS $$
BEGIN
  -- Log the interaction details
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'ai_interaction',
    'AI Interaction: ' || NEW.request_type::text,
    jsonb_build_object(
      'request_type', NEW.request_type,
      'status', NEW.status,
      'execution_time', NEW.execution_time,
      'tokens_used', NEW.tokens_used
    )::text,
    NEW.user_id,
    now()
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to update updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to log calendar activities
CREATE OR REPLACE FUNCTION log_calendar_activity()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'calendar_log',
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'Event Created'
      WHEN TG_OP = 'UPDATE' THEN 'Event Updated'
      WHEN TG_OP = 'DELETE' THEN 'Event Deleted'
      ELSE 'Event Modified'
    END,
    jsonb_build_object(
      'event_id', COALESCE(NEW.id, OLD.id),
      'title', COALESCE(NEW.title, OLD.title),
      'operation', TG_OP,
      'timestamp', now()
    )::text,
    COALESCE(NEW.owner_id, OLD.owner_id),
    now()
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to sync calendar events
CREATE OR REPLACE FUNCTION sync_calendar_event()
RETURNS TRIGGER AS $$
BEGIN
  -- Log sync attempt
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'calendar_sync',
    'Calendar Sync Attempted',
    'Attempting to sync event: ' || NEW.title,
    NEW.owner_id,
    now()
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to handle user input
CREATE OR REPLACE FUNCTION handle_user_input()
RETURNS TRIGGER AS $$
BEGIN
  -- Log user input
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    'user_input',
    'Calendar Event Created',
    'User created calendar event: ' || NEW.title,
    NEW.owner_id,
    now()
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to process calendar events
CREATE OR REPLACE FUNCTION process_calendar_event()
RETURNS TRIGGER AS $$
BEGIN
  -- Create activity record
  INSERT INTO activities (
    type,
    title,
    description,
    due_date,
    contact_id,
    deal_id,
    owner_id,
    created_at
  ) VALUES (
    'calendar_event',
    NEW.title,
    COALESCE(NEW.description, 'Calendar event'),
    NEW.start,
    NEW.contact_id,
    NEW.deal_id,
    NEW.owner_id,
    now()
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create function to process AI calendar requests
CREATE OR REPLACE FUNCTION process_ai_calendar_request()
RETURNS TRIGGER AS $$
DECLARE
  v_interaction_id uuid;
BEGIN
  -- Create AI interaction record
  INSERT INTO ai_interactions (
    user_id,
    request_type,
    request_data,
    status,
    created_at
  ) VALUES (
    NEW.owner_id,
    'calendar_event',
    jsonb_build_object(
      'event_id', NEW.id,
      'title', NEW.title,
      'description', NEW.description,
      'start_time', NEW.start,
      'end_time', NEW."end",
      'location', NEW.location,
      'attendees', NEW.attendees
    ),
    'completed',
    now()
  ) RETURNING id INTO v_interaction_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for deal stage changes
DROP TRIGGER IF EXISTS deal_stage_status_update ON deals;
CREATE TRIGGER deal_stage_status_update
  AFTER UPDATE OF stage_id ON deals
  FOR EACH ROW
  WHEN (OLD.stage_id IS DISTINCT FROM NEW.stage_id)
  EXECUTE FUNCTION update_deal_status();

-- Create triggers for AI interactions
DROP TRIGGER IF EXISTS ai_interaction_logger ON ai_interactions;
CREATE TRIGGER ai_interaction_logger
  AFTER INSERT OR UPDATE ON ai_interactions
  FOR EACH ROW
  EXECUTE FUNCTION log_ai_interaction();

-- Create triggers for calendar events
DROP TRIGGER IF EXISTS calendar_event_logger ON calendar_events;
CREATE TRIGGER calendar_event_logger
  AFTER INSERT OR DELETE OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION log_calendar_activity();

DROP TRIGGER IF EXISTS calendar_event_processor ON calendar_events;
CREATE TRIGGER calendar_event_processor
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION process_calendar_event();

DROP TRIGGER IF EXISTS calendar_sync_trigger ON calendar_events;
CREATE TRIGGER calendar_sync_trigger
  AFTER INSERT OR UPDATE ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION sync_calendar_event();

DROP TRIGGER IF EXISTS ai_calendar_event_processor ON calendar_events;
CREATE TRIGGER ai_calendar_event_processor
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  WHEN (NEW.source = 'ai_agent')
  EXECUTE FUNCTION process_ai_calendar_request();

DROP TRIGGER IF EXISTS user_input_trigger ON calendar_events;
CREATE TRIGGER user_input_trigger
  AFTER INSERT ON calendar_events
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_input();

-- Add updated_at triggers to all relevant tables
DO $$ 
DECLARE
  t text;
BEGIN
  FOR t IN 
    SELECT table_name 
    FROM information_schema.columns 
    WHERE column_name = 'updated_at' 
    AND table_schema = 'public'
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS set_updated_at ON %I;
      CREATE TRIGGER set_updated_at
        BEFORE UPDATE ON %I
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    ', t, t);
  END LOOP;
END $$;