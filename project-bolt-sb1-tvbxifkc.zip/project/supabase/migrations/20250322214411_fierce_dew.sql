-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view their AI interactions" ON ai_interactions;
  DROP POLICY IF EXISTS "Users can manage their AI interactions" ON ai_interactions;
  DROP POLICY IF EXISTS "Default AI interaction access" ON ai_interactions;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policy that allows public access for AI interactions
CREATE POLICY "Default AI interaction access"
  ON ai_interactions
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_ai_interactions_user_id ON ai_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_request_type ON ai_interactions(request_type);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_status ON ai_interactions(status);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_created_at ON ai_interactions(created_at);