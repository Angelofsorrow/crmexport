-- Clear existing loan products to avoid duplicates
TRUNCATE loan_products CASCADE;

-- Insert loan products with complete data
INSERT INTO loan_products (
  name, type, description, min_credit_score, max_ltv,
  min_down_payment, interest_rate_range, term_years, requirements,
  eligible_property_types, income_limits, dti_limits, credit_score_ranges
) VALUES
  (
    'Conventional 97',
    'Conventional',
    'Standard conventional loan with 3% down payment option',
    620,
    97,
    3,
    '{"min": 5.5, "max": 7.5}',
    ARRAY[15, 20, 30],
    ARRAY[
      'Minimum credit score of 620',
      'Debt-to-income ratio below 45%',
      'First-time homebuyer program',
      'Primary residence only',
      'Private mortgage insurance required if LTV > 80%'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    '{"single": 150000, "joint": 250000}',
    '{"front": 28, "back": 36}',
    '[
      {"min": 740, "max": 850, "rate_adjustment": -0.5},
      {"min": 720, "max": 739, "rate_adjustment": -0.25},
      {"min": 700, "max": 719, "rate_adjustment": 0},
      {"min": 680, "max": 699, "rate_adjustment": 0.25},
      {"min": 660, "max": 679, "rate_adjustment": 0.5},
      {"min": 640, "max": 659, "rate_adjustment": 0.75},
      {"min": 620, "max": 639, "rate_adjustment": 1}
    ]'
  ),
  (
    'Conventional 95',
    'Conventional',
    'Traditional conventional loan with 5% down payment',
    620,
    95,
    5,
    '{"min": 5.25, "max": 7.25}',
    ARRAY[15, 20, 30],
    ARRAY[
      'Minimum credit score of 620',
      'Debt-to-income ratio below 45%',
      'Available for all borrowers',
      'Private mortgage insurance required if LTV > 80%'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    '{"single": 150000, "joint": 250000}',
    '{"front": 28, "back": 36}',
    '[
      {"min": 740, "max": 850, "rate_adjustment": -0.5},
      {"min": 720, "max": 739, "rate_adjustment": -0.25},
      {"min": 700, "max": 719, "rate_adjustment": 0},
      {"min": 680, "max": 699, "rate_adjustment": 0.25},
      {"min": 660, "max": 679, "rate_adjustment": 0.5},
      {"min": 640, "max": 659, "rate_adjustment": 0.75},
      {"min": 620, "max": 639, "rate_adjustment": 1}
    ]'
  ),
  (
    'FHA Standard',
    'FHA',
    'Government-backed FHA loan with low down payment',
    580,
    96.5,
    3.5,
    '{"min": 5.75, "max": 7.75}',
    ARRAY[15, 30],
    ARRAY[
      'Minimum credit score of 580',
      'Debt-to-income ratio below 50%',
      'Primary residence only',
      'Upfront and annual mortgage insurance required',
      'Property must meet FHA standards'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    NULL,
    '{"front": 31, "back": 43}',
    '[
      {"min": 580, "max": 850, "rate_adjustment": 0},
      {"min": 500, "max": 579, "rate_adjustment": 0.5}
    ]'
  ),
  (
    'FHA 203(k)',
    'FHA',
    'Renovation and repair loan program',
    580,
    96.5,
    3.5,
    '{"min": 6, "max": 8}',
    ARRAY[15, 30],
    ARRAY[
      'Minimum credit score of 580',
      'Property must need at least $5,000 in repairs',
      'Maximum repair costs subject to limits',
      'Contractor requirements apply'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    NULL,
    '{"front": 31, "back": 43}',
    '[
      {"min": 580, "max": 850, "rate_adjustment": 0},
      {"min": 500, "max": 579, "rate_adjustment": 0.5}
    ]'
  ),
  (
    'VA Standard',
    'VA',
    'Veterans Affairs guaranteed loan with no down payment',
    580,
    100,
    0,
    '{"min": 5.5, "max": 7.5}',
    ARRAY[15, 30],
    ARRAY[
      'Must be eligible service member, veteran, or surviving spouse',
      'Valid Certificate of Eligibility required',
      'No private mortgage insurance required',
      'VA funding fee may apply',
      'Property must meet VA standards'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    NULL,
    '{"front": 41, "back": 41}',
    '[
      {"min": 580, "max": 850, "rate_adjustment": 0}
    ]'
  ),
  (
    'VA IRRRL',
    'VA',
    'Interest Rate Reduction Refinance Loan',
    580,
    100,
    0,
    '{"min": 5.25, "max": 7.25}',
    ARRAY[15, 30],
    ARRAY[
      'Must have existing VA loan',
      'No credit score requirement',
      'No appraisal required',
      'Reduced funding fee',
      'Must result in lower interest rate'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    NULL,
    '{"front": 41, "back": 41}',
    '[
      {"min": 580, "max": 850, "rate_adjustment": 0}
    ]'
  ),
  (
    'USDA Standard',
    'USDA',
    'Rural development loan with no down payment',
    640,
    100,
    0,
    '{"min": 5.75, "max": 7.75}',
    ARRAY[30],
    ARRAY[
      'Property must be in eligible rural area',
      'Income limits apply',
      'No down payment required',
      'Upfront and annual guarantee fees',
      'Primary residence only'
    ],
    ARRAY['Single Family'],
    '{"percentage_ami": 115}',
    '{"front": 29, "back": 41}',
    '[
      {"min": 640, "max": 850, "rate_adjustment": 0}
    ]'
  ),
  (
    'Jumbo Standard',
    'Jumbo',
    'High-balance loan for luxury properties',
    700,
    89.99,
    10.01,
    '{"min": 6, "max": 8}',
    ARRAY[15, 30],
    ARRAY[
      'Loan amount exceeds conforming limits',
      'Minimum credit score of 700',
      'Significant cash reserves required',
      'Debt-to-income ratio below 43%',
      'Full documentation required'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse', 'Multi Family'],
    NULL,
    '{"front": 36, "back": 43}',
    '[
      {"min": 740, "max": 850, "rate_adjustment": -0.25},
      {"min": 720, "max": 739, "rate_adjustment": 0},
      {"min": 700, "max": 719, "rate_adjustment": 0.25}
    ]'
  ),
  (
    'Jumbo High LTV',
    'Jumbo',
    'High-balance loan with lower down payment',
    720,
    95,
    5,
    '{"min": 6.25, "max": 8.25}',
    ARRAY[30],
    ARRAY[
      'Loan amount exceeds conforming limits',
      'Minimum credit score of 720',
      'Private mortgage insurance required',
      'Significant cash reserves required',
      'Full documentation required'
    ],
    ARRAY['Single Family', 'Condo', 'Townhouse'],
    NULL,
    '{"front": 36, "back": 43}',
    '[
      {"min": 740, "max": 850, "rate_adjustment": -0.25},
      {"min": 720, "max": 739, "rate_adjustment": 0}
    ]'
  );