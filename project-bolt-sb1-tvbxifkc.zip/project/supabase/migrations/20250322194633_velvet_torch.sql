/*
  # Fix Calendar Events RLS Policy

  1. Changes
    - Drop all existing calendar event policies
    - Create new policy that allows AI agent to create events
    - Add proper indexes for performance
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage calendar events" ON calendar_events;
  DROP POLICY IF EXISTS "Users can manage their calendar events" ON calendar_events;
  DROP POLICY IF EXISTS "Users can insert calendar events" ON calendar_events;
  DROP POLICY IF EXISTS "Users can view calendar events" ON calendar_events;
  DROP POLICY IF EXISTS "Users can update their calendar events" ON calendar_events;
  DROP POLICY IF EXISTS "Users can delete their calendar events" ON calendar_events;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policy that allows AI agent events
CREATE POLICY "Users can manage calendar events"
  ON calendar_events
  FOR ALL
  TO authenticated
  USING (
    source = 'ai_agent' OR  -- Allow AI agent events
    owner_id = auth.uid() OR  -- Allow user's own events
    contact_id IN (
      SELECT contacts.id
      FROM contacts
      WHERE contacts.owner_id = auth.uid()
    ) OR 
    deal_id IN (
      SELECT deals.id
      FROM deals
      WHERE deals.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    source = 'ai_agent' OR  -- Allow AI agent to create events
    owner_id = auth.uid()   -- Allow users to create their own events
  );

-- Add source column if it doesn't exist
DO $$ 
BEGIN
  ALTER TABLE calendar_events 
  ADD COLUMN IF NOT EXISTS source text DEFAULT 'manual';
EXCEPTION
  WHEN duplicate_column THEN NULL;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_events_source
  ON calendar_events(source);

CREATE INDEX IF NOT EXISTS idx_calendar_events_owner_id 
  ON calendar_events(owner_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_contact_id 
  ON calendar_events(contact_id);

CREATE INDEX IF NOT EXISTS idx_calendar_events_deal_id 
  ON calendar_events(deal_id);

-- Add trigger for updating timestamps
DO $$ 
BEGIN
  CREATE TRIGGER set_updated_at
    BEFORE UPDATE ON calendar_events
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;