/*
  # Configure Storage Buckets and Policies

  1. Changes
    - Create storage buckets for documents, profile photos, and campaign files
    - Set up RLS policies for each bucket
    - Fix policy naming conflicts
*/

-- Create storage buckets if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id IN ('documents', 'profile-photos', 'campaign-files')
  ) THEN
    INSERT INTO storage.buckets (id, name, public)
    VALUES 
      ('documents', 'documents', false),
      ('profile-photos', 'profile-photos', false),
      ('campaign-files', 'campaign-files', false);
  END IF;
END $$;

-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Documents upload policy" ON storage.objects;
  DROP POLICY IF EXISTS "Documents download policy" ON storage.objects;
  DROP POLICY IF EXISTS "Documents delete policy" ON storage.objects;
  DROP POLICY IF EXISTS "Profile photos policy" ON storage.objects;
  DROP POLICY IF EXISTS "Campaign files policy" ON storage.objects;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new storage policies
CREATE POLICY "Documents upload policy"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'documents' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Documents download policy"
  ON storage.objects FOR SELECT TO authenticated
  USING (
    bucket_id = 'documents' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Documents delete policy"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'documents' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Profile photos policy"
  ON storage.objects
  FOR ALL TO authenticated
  USING (
    bucket_id = 'profile-photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  )
  WITH CHECK (
    bucket_id = 'profile-photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Campaign files policy"
  ON storage.objects
  FOR ALL TO authenticated
  USING (
    bucket_id = 'campaign-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  )
  WITH CHECK (
    bucket_id = 'campaign-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );