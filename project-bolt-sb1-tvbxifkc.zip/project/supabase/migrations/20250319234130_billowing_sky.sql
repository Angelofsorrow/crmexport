/*
  # Fix Custom Fields RLS Policies

  1. Changes
    - Drop existing policies
    - Create new policies that handle NULL owner_id for system defaults
    - Update related tables' policies
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can manage their custom fields" ON custom_fields;
  DROP POLICY IF EXISTS "Users can manage their custom field values" ON custom_field_values;
  DROP POLICY IF EXISTS "Users can manage their tags" ON tags;
  DROP POLICY IF EXISTS "Users can manage their entity tags" ON entity_tags;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Add policies for custom fields
CREATE POLICY "Users can manage custom fields"
  ON custom_fields
  FOR ALL
  TO authenticated
  USING (
    owner_id IS NULL OR  -- Allow access to system defaults
    owner_id = auth.uid()
  )
  WITH CHECK (
    owner_id IS NULL OR  -- Allow creation of system defaults
    owner_id = auth.uid()
  );

-- Add policies for custom field values
CREATE POLICY "Users can manage custom field values"
  ON custom_field_values
  FOR ALL
  TO authenticated
  USING (
    field_id IN (
      SELECT id FROM custom_fields 
      WHERE owner_id IS NULL OR owner_id = auth.uid()
    )
  )
  WITH CHECK (
    field_id IN (
      SELECT id FROM custom_fields 
      WHERE owner_id IS NULL OR owner_id = auth.uid()
    )
  );

-- Add policies for tags
CREATE POLICY "Users can manage tags"
  ON tags
  FOR ALL
  TO authenticated
  USING (
    owner_id IS NULL OR  -- Allow access to system defaults
    owner_id = auth.uid()
  )
  WITH CHECK (
    owner_id IS NULL OR  -- Allow creation of system defaults
    owner_id = auth.uid()
  );

-- Add policies for entity tags
CREATE POLICY "Users can manage entity tags"
  ON entity_tags
  FOR ALL
  TO authenticated
  USING (
    tag_id IN (
      SELECT id FROM tags 
      WHERE owner_id IS NULL OR owner_id = auth.uid()
    )
  )
  WITH CHECK (
    tag_id IN (
      SELECT id FROM tags 
      WHERE owner_id IS NULL OR owner_id = auth.uid()
    )
  );