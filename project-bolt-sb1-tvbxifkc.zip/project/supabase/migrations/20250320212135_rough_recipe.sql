-- Add provider and OAuth fields to email_accounts table
ALTER TABLE email_accounts
ADD COLUMN IF NOT EXISTS provider text,
ADD COLUMN IF NOT EXISTS access_token text,
ADD COLUMN IF NOT EXISTS refresh_token text,
ADD COLUMN IF NOT EXISTS token_expires_at timestamptz;

-- Add indexes for provider and token fields
CREATE INDEX IF NOT EXISTS idx_email_accounts_provider ON email_accounts(provider);
CREATE INDEX IF NOT EXISTS idx_email_accounts_token_expires ON email_accounts(token_expires_at);