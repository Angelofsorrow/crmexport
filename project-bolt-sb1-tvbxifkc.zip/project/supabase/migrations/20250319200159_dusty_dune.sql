-- Create deal_contacts junction table
CREATE TABLE IF NOT EXISTS deal_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid REFERENCES deals(id) ON DELETE CASCADE,
  contact_id uuid REFERENCES contacts(id) ON DELETE CASCADE,
  role text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(deal_id, contact_id)
);

-- Enable RLS
ALTER TABLE deal_contacts ENABLE ROW LEVEL SECURITY;

-- Add policy for deal contacts
CREATE POLICY "Users can manage their deal contacts"
  ON deal_contacts
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM deals
      WHERE deals.id = deal_contacts.deal_id
      AND deals.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM deals
      WHERE deals.id = deal_contacts.deal_id
      AND deals.owner_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS deal_contacts_deal_id_idx ON deal_contacts(deal_id);
CREATE INDEX IF NOT EXISTS deal_contacts_contact_id_idx ON deal_contacts(contact_id);