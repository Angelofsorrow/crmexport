/*
  # Fix Whitelabel Configuration Policies

  1. Changes
    - Drop existing whitelabel policies
    - Create new simplified policies
    - Fix auth.uid() function call
    - Add proper indexes
*/

-- Drop existing whitelabel policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view whitelabel configs" ON whitelabel_configs;
  DROP POLICY IF EXISTS "Organization owners can manage whitelabel configs" ON whitelabel_configs;
  DROP POLICY IF EXISTS "Default whitelabel config access" ON whitelabel_configs;
  DROP POLICY IF EXISTS "Users can view their organization whitelabel configs" ON whitelabel_configs;
  DROP POLICY IF EXISTS "Allow access to default whitelabel config" ON whitelabel_configs;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new simplified policies for whitelabel configs
CREATE POLICY "Default whitelabel config access"
  ON whitelabel_configs
  FOR SELECT
  TO public
  USING (user_id = auth.uid());

CREATE POLICY "Users can view whitelabel configs"
  ON whitelabel_configs
  FOR SELECT
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id 
      FROM organization_members 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Organization owners can manage whitelabel configs"
  ON whitelabel_configs
  FOR ALL
  TO authenticated
  USING (
    organization_id IN (
      SELECT id 
      FROM organizations 
      WHERE owner_id = auth.uid()
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT id 
      FROM organizations 
      WHERE owner_id = auth.uid()
    )
  );

-- Add user_id column if it doesn't exist
ALTER TABLE whitelabel_configs 
ADD COLUMN IF NOT EXISTS user_id uuid DEFAULT gen_random_uuid();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_whitelabel_configs_organization_id 
  ON whitelabel_configs(organization_id);

CREATE INDEX IF NOT EXISTS idx_whitelabel_configs_is_active 
  ON whitelabel_configs(is_active);

-- Add trigger for updating timestamps
DO $$ 
BEGIN
  CREATE TRIGGER set_updated_at
    BEFORE UPDATE ON whitelabel_configs
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;