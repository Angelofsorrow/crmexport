-- Create function to log activities without arguments
CREATE OR REPLACE FUNCTION log_activity()
RETURNS TRIGGER AS $$
DECLARE
  activity_type text;
BEGIN
  -- Determine activity type from table name
  activity_type := TG_TABLE_NAME;
  
  INSERT INTO activities (
    type,
    title,
    description,
    owner_id,
    created_at
  ) VALUES (
    activity_type,
    CASE 
      WHEN TG_OP = 'INSERT' THEN 'Created ' || activity_type
      WHEN TG_OP = 'UPDATE' THEN 'Updated ' || activity_type
      WHEN TG_OP = 'DELETE' THEN 'Deleted ' || activity_type
      ELSE 'Modified ' || activity_type
    END,
    jsonb_build_object(
      'table', TG_TABLE_NAME,
      'operation', TG_OP,
      'record_id', COALESCE(NEW.id, OLD.id),
      'timestamp', now()
    )::text,
    COALESCE(NEW.owner_id, OLD.owner_id),
    now()
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers first
DO $$ 
BEGIN
  DROP TRIGGER IF EXISTS log_company_activity ON companies;
  DROP TRIGGER IF EXISTS log_contact_activity ON contacts;
  DROP TRIGGER IF EXISTS log_deal_activity ON deals;
  DROP TRIGGER IF EXISTS log_document_activity ON documents;
  DROP TRIGGER IF EXISTS log_campaign_activity ON campaigns;
  DROP TRIGGER IF EXISTS log_loan_application_activity ON loan_applications;
  DROP TRIGGER IF EXISTS log_organization_activity ON organizations;
  DROP TRIGGER IF EXISTS log_pipeline_stage_activity ON pipeline_stages;
  DROP TRIGGER IF EXISTS log_custom_field_activity ON custom_fields;
  DROP TRIGGER IF EXISTS log_tag_activity ON tags;
  DROP TRIGGER IF EXISTS log_email_account_activity ON email_accounts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create activity logging triggers for all major tables
CREATE TRIGGER log_company_activity
  AFTER INSERT OR UPDATE OR DELETE ON companies
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_contact_activity
  AFTER INSERT OR UPDATE OR DELETE ON contacts
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_deal_activity
  AFTER INSERT OR UPDATE OR DELETE ON deals
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_document_activity
  AFTER INSERT OR UPDATE OR DELETE ON documents
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_campaign_activity
  AFTER INSERT OR UPDATE OR DELETE ON campaigns
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_loan_application_activity
  AFTER INSERT OR UPDATE OR DELETE ON loan_applications
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_organization_activity
  AFTER INSERT OR UPDATE OR DELETE ON organizations
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_pipeline_stage_activity
  AFTER INSERT OR UPDATE OR DELETE ON pipeline_stages
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_custom_field_activity
  AFTER INSERT OR UPDATE OR DELETE ON custom_fields
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

CREATE TRIGGER log_tag_activity
  AFTER INSERT OR UPDATE OR DELETE ON tags
  FOR EACH ROW
  EXECUTE FUNCTION log_activity();

-- Create function to update updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers to all relevant tables
DO $$ 
DECLARE
  t text;
BEGIN
  FOR t IN 
    SELECT table_name 
    FROM information_schema.columns 
    WHERE column_name = 'updated_at' 
    AND table_schema = 'public'
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS set_updated_at ON %I;
      CREATE TRIGGER set_updated_at
        BEFORE UPDATE ON %I
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    ', t, t);
  END LOOP;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(type);
CREATE INDEX IF NOT EXISTS idx_activities_owner_id ON activities(owner_id);
CREATE INDEX IF NOT EXISTS idx_activities_created_at ON activities(created_at);