/*
  # Add Pipeline Stages

  1. New Tables
    - `pipeline_stages`
      - Core stage information
      - Tasks and automations for each stage
      - System flag for default stages
      - Closed/Won flags for deal status

  2. Changes
    - Add stage_id to deals table
    - Migrate existing deals to new stage system
    
  3. Security
    - Enable RLS
    - Add policy for stage management
*/

-- Create pipeline stages table
CREATE TABLE IF NOT EXISTS pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  color text NOT NULL DEFAULT 'bg-gray-600',
  order_number integer NOT NULL,
  owner_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tasks text[] DEFAULT '{}',
  automations text[] DEFAULT '{}',
  is_system boolean DEFAULT false,
  is_closed boolean DEFAULT false,
  is_won boolean DEFAULT false
);

-- Enable RLS
ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Users can manage their pipeline stages" ON pipeline_stages;

-- Add RLS policy
CREATE POLICY "Users can manage their pipeline stages"
  ON pipeline_stages
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid() OR is_system = true)
  WITH CHECK (owner_id = auth.uid());

-- Add stage_id to deals table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'deals' AND column_name = 'stage_id'
  ) THEN
    ALTER TABLE deals ADD COLUMN stage_id uuid REFERENCES pipeline_stages(id);
  END IF;
END $$;

-- Insert default system stages and store their IDs
DO $$
DECLARE
  v_stage_id uuid;
BEGIN
  -- Insert Prospecting stage
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Prospecting',
    'Initial contact and lead qualification',
    'bg-blue-600',
    1,
    true,
    ARRAY[
      'Research company background',
      'Identify key decision makers',
      'Initial contact attempt'
    ],
    ARRAY[
      'Send welcome email',
      'Create follow-up task',
      'LinkedIn connection request'
    ],
    false,
    false
  ) RETURNING id INTO v_stage_id;
  
  UPDATE deals d SET stage_id = v_stage_id WHERE d.stage = 'prospecting';

  -- Insert Qualification stage
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Qualification',
    'Assessing needs and budget',
    'bg-purple-600',
    2,
    true,
    ARRAY[
      'Assess budget and timeline',
      'Identify pain points',
      'Confirm decision-making process'
    ],
    ARRAY[
      'Schedule discovery call',
      'Send qualification survey',
      'Create opportunity'
    ],
    false,
    false
  ) RETURNING id INTO v_stage_id;
  
  UPDATE deals d SET stage_id = v_stage_id WHERE d.stage = 'qualification';

  -- Insert Proposal stage
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Proposal',
    'Proposal preparation and presentation',
    'bg-yellow-600',
    3,
    true,
    ARRAY[
      'Draft proposal document',
      'Internal pricing review',
      'Prepare presentation'
    ],
    ARRAY[
      'Generate proposal document',
      'Set internal review deadline',
      'Schedule presentation'
    ],
    false,
    false
  ) RETURNING id INTO v_stage_id;
  
  UPDATE deals d SET stage_id = v_stage_id WHERE d.stage = 'proposal';

  -- Insert Negotiation stage
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Negotiation',
    'Contract negotiation and review',
    'bg-orange-600',
    4,
    true,
    ARRAY[
      'Review contract terms',
      'Address objections',
      'Get stakeholder approval'
    ],
    ARRAY[
      'Send contract for review',
      'Schedule negotiation call',
      'Set follow-up reminder'
    ],
    false,
    false
  ) RETURNING id INTO v_stage_id;
  
  UPDATE deals d SET stage_id = v_stage_id WHERE d.stage = 'negotiation';

  -- Insert Closed Won stage
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Closed Won',
    'Deal successfully closed',
    'bg-green-600',
    5,
    true,
    ARRAY[
      'Send final contract',
      'Schedule kickoff meeting',
      'Set up account'
    ],
    ARRAY[
      'Generate welcome packet',
      'Notify implementation team',
      'Schedule onboarding'
    ],
    true,
    true
  ) RETURNING id INTO v_stage_id;
  
  UPDATE deals d SET stage_id = v_stage_id WHERE d.stage = 'closed_won';

  -- Insert Closed Lost stage
  INSERT INTO pipeline_stages (
    name, description, color, order_number, is_system,
    tasks, automations, is_closed, is_won
  ) VALUES (
    'Closed Lost',
    'Deal lost or abandoned',
    'bg-red-600',
    6,
    true,
    ARRAY[
      'Document loss reasons',
      'Schedule post-mortem',
      'Update CRM'
    ],
    ARRAY[
      'Send feedback survey',
      'Schedule follow-up in 6 months',
      'Archive documents'
    ],
    true,
    false
  ) RETURNING id INTO v_stage_id;
  
  UPDATE deals d SET stage_id = v_stage_id WHERE d.stage = 'closed_lost';
END $$;