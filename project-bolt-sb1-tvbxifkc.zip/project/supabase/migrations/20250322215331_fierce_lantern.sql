/*
  # Add Review Request System

  1. Changes
    - Create review request tag
    - Add function to log review requests
    - Add trigger for review request tracking
    - Add performance indexes
*/

-- Create review request tag if it doesn't exist
INSERT INTO tags (
  name,
  color,
  entity_type,
  owner_id
) VALUES (
  'Review Requested',
  'bg-yellow-100',
  'contact',
  NULL
) ON CONFLICT (name, entity_type, owner_id) DO NOTHING;

-- Create function to handle review request activities
CREATE OR REPLACE FUNCTION log_review_request()
RETURNS TRIGGER AS $$
DECLARE
  v_contact_record RECORD;
BEGIN
  -- Get contact information
  SELECT first_name, last_name, email 
  INTO v_contact_record 
  FROM contacts 
  WHERE id = NEW.entity_id;

  -- Log the review request
  INSERT INTO activities (
    type,
    title,
    description,
    contact_id,
    owner_id,
    created_at
  ) VALUES (
    'review_request',
    'Review Request Sent',
    format('Review request sent to %s %s (%s)', 
      v_contact_record.first_name,
      v_contact_record.last_name,
      v_contact_record.email
    ),
    NEW.entity_id,
    auth.uid(),
    now()
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for review requests
CREATE TRIGGER log_review_request_activity
  AFTER INSERT ON entity_tags
  FOR EACH ROW
  EXECUTE FUNCTION log_review_request();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_entity_tags_tag_id ON entity_tags(tag_id);
CREATE INDEX IF NOT EXISTS idx_entity_tags_entity_id ON entity_tags(entity_id);
CREATE INDEX IF NOT EXISTS idx_activities_review_requests ON activities(type) WHERE type = 'review_request';